namespace java com.kidmate.kmservice
include "kidmate.thrift"
service ChildService {
	# 登录
	kidmate.TKmUser login(1:string mac, 2:string sign, 3:i64 timestamp, 4:string qrcode, 5: string version, 6:i32 source, 7:string phonename) throws (1:kidmate.TKmException e),
	#登录ios儿童端
	kidmate.TKmUser loginIos(1:string mac, 2:string sign, 3:i64 timestamp, 4:string qrcode, 5: string version, 6:i32 source, 7:string phonename) throws (1:kidmate.TKmException e),
	# 查看已经存在的appid
	list<kidmate.TKmAppInfo> checkExistApp(1:kidmate.TKmUser user, 2:list<string> packageList) throws (1:kidmate.TKmException e),
	# 添加app
	list<kidmate.TKmAppInfo> addAppInfo(1: kidmate.TKmUser user, 2:list<kidmate.TKmAppInfoUpload> appInfoUploadList) throws (1:kidmate.TKmException e),
	
	# 获取所有绑定的app
	list<kidmate.TKmAppInfo> getAllBindApp(1:kidmate.TKmUser user),
	# 绑定app
	list<kidmate.TKmAppInfo> bindApp(1:kidmate.TKmUser user, 2:list<i64> appIdList),
	
	# 卸载
	bool unInstallApp(1: kidmate.TKmUser user, 2:i64 appid) throws (1:kidmate.TKmException e),
	# 更新app使用情况
	bool updateAppUsage(1: kidmate.TKmUser user, 2:i64 appid ,3:i64 wifiid, 4:i64 positionid) throws (1:kidmate.TKmException e),
	# 更新历史数据
	bool updateHistoryAppUsage(1: kidmate.TKmUser user, 2:list<kidmate.TKmAppUsage> appUsageList) throws (1:kidmate.TKmException e),
	# 更新位置
	i64 updatePosition(1: kidmate.TKmUser user, 2: kidmate.TKmPosition position) throws (1:kidmate.TKmException e),
	# 更新wifi
	i64 updateWifi(1: kidmate.TKmUser user, 2: kidmate.TKmWifi wifi) throws (1:kidmate.TKmException e),
	# 获取所有规则
	list<kidmate.TKmControlRuleInfo> getAllControlRuleInfo(1: kidmate.TKmUser user);
	# 更新立即锁屏状态  status 1:默认，2：正在锁屏货完成锁屏；
	void updateLockStatus(1: kidmate.TKmUser user, 3:string status) throws (1:kidmate.TKmException e),
	# 上传截屏
	void uploadSnapshot(1: kidmate.TKmUser user, 2: kidmate.TKmSnapshot  snapshot) throws (1:kidmate.TKmException e),
	# 下载app时，更新已有的app的状态
	bool installApp(1: kidmate.TKmUser user, 2:i64 appid) throws (1:kidmate.TKmException e),
	# 判断ios儿童端是否被删除
	bool isIosExist(1: kidmate.TKmUser user) throws (1:kidmate.TKmException e),
}