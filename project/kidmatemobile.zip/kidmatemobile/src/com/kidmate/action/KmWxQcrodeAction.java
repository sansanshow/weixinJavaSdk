package com.kidmate.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

import com.kidmate.model.KmSchoolmaster;
import com.kidmate.model.KmSchoolmasterDAO;
import com.kidmate.model.KmWxInfo;
import com.kidmate.model.KmWxInfoDAO;
import com.kidmate.wx.controller.WeiXinAction;
import com.kidmate.wx.pojo.AccessToken;
import com.kidmate.wx.pojo.ReturnValue;
import com.kidmate.wx.service.ICoreService;
import com.kidmate.wx.service.IWxConfigService;
import com.kidmate.wx.utils.WeixinConfig;
import com.kidmate.wx.utils.WeixinUtil;


@Controller
@RequestMapping(value="/shareCode")
public class KmWxQcrodeAction {
	private static Logger logger = LoggerFactory
			.getLogger(KmWxQcrodeAction.class);
	@Resource(name="ShardedJedisPool")
	private ShardedJedisPool shardedJedisPool;
	//@Resource(name="CoreServiceImpl")
	//private ICoreService coreServiceImpl;
	private String QR_CODE_URL = "https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=TOKEN";
	private static final String WX_ACCESSTOKEN = "wx_accesstoken";
	@Resource(name="KmWxInfoDAO")
	private KmWxInfoDAO kmWxInfoDAO;
	@Resource(name="KmSchoolmasterDAO")
	private KmSchoolmasterDAO kmSchoolmasterDAO;
	
	
	@RequestMapping(value="/qrcod.do")
	@ResponseBody
	public void getSourceQrcod(HttpServletRequest request,
			HttpServletResponse response,String callback) throws IOException{
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String schoolName=request.getParameter("schoolName");
		String userName=request.getParameter("userName");
		String phoneNum=request.getParameter("phoneNum");
		List<KmSchoolmaster> kmShcools=kmSchoolmasterDAO.findByProperty("phonenumber", phoneNum);
		KmSchoolmaster kmShcool=null;
		if(kmShcools!=null && kmShcools.size()>0){
			kmShcool=kmShcools.get(0);
			kmShcool.setName(userName);
			kmShcool.setSchoolname(schoolName);
			kmShcool.setStatus("1");
			kmSchoolmasterDAO.attachDirty(kmShcool);
		}else{
			kmShcool=new KmSchoolmaster();
			kmShcool.setName(userName);
			kmShcool.setSchoolname(schoolName);
			kmShcool.setStatus("1");
			kmShcool.setPhonenumber(phoneNum);
			kmShcool.setCreatetime(new Date());
			kmSchoolmasterDAO.save(kmShcool);
		}
		//System.out.println("id======"+id);
		//PrintWriter out = response.getWriter();
		//ReturnValue ret_obj = new ReturnValue(); 
		//ret_obj.setStatus(200);
		String sceneId="campus"+String.valueOf(kmShcool.getId());
		logger.info("sceneid:" + sceneId);
		if(!StringUtils.isEmpty(sceneId)){
			JSONObject image =getPersistentQrcode(sceneId);
			//System.out.println("image");
			if (null != image) {
				String ticket=image.getString("ticket");
				String result =  "{'urlTicket':'"+ticket+"'}";
				 //加上返回参数
			    result=callback+"("+result+")";
				System.out.println(result.toString());
				response.getWriter().print(result);
				//out.print(result);
				
			}
		}
		
	}


	/**
	 * 获取持久二维码
	 * 
	 * @param sceneId
	 * @return
	 */
	private JSONObject getPersistentQrcode(String sceneId) {
		Map<String, Object> param = new HashMap<String, Object>();
		Map<String, Object> action_info = new HashMap<String, Object>();
		Map<String, Object> scene = new HashMap<String, Object>();
		// {"action_name": "QR_LIMIT_STR_SCENE", "action_info": {"scene": {"scene_str": "123"}}}
		param.put("action_name", "QR_LIMIT_STR_SCENE");
		scene.put("scene_str", sceneId);
		action_info.put("scene", scene);
		param.put("action_info", action_info);
		System.out.println("param:" + JSONObject.fromObject(param).toString());
		logger.info("getAccessToken()" + getAccessToken().getToken());
		JSONObject ticket = getTicket(JSONObject.fromObject(param).toString(), getAccessToken().getToken());
		System.out.println("=----getPersistentQrcode---");
		System.out.println(ticket.toString());
		return ticket;
	}

	/**
	 * 获取Ticket
	 * @param param
	 * @param accessToken
	 * @return
	 */
	private JSONObject getTicket(String param, String accessToken) {
		// 拼装创建菜单的url
		String url = QR_CODE_URL.replace("TOKEN", accessToken);
		// // 将菜单对象转换成json字符串
		// String jsonMenu = JSONObject.fromObject(menu).toString();
		// 调用接口创建菜单
		JSONObject jsonObject = WeixinUtil.httpRequest(url, "POST", param);
		if (null != jsonObject) {
			if(!jsonObject.containsKey("errcode")){
				return jsonObject;
			}
		}

		return jsonObject;
	}
	
	public AccessToken getAccessToken() {
		AccessToken accessToken = null;
		ShardedJedis shardedJedis = shardedJedisPool.getResource();
		if(shardedJedis.hexists(WX_ACCESSTOKEN, "Token") && shardedJedis.hexists(WX_ACCESSTOKEN, "updatetime")){
			String token = shardedJedis.hget(WX_ACCESSTOKEN, "Token");
			long updatetime = Long.parseLong(shardedJedis.hget(WX_ACCESSTOKEN, "updatetime"));
			if((System.currentTimeMillis() - updatetime) < 7000 * 1000){
				System.out.println("--getAccessToken-shardedJedis--");
				accessToken =new AccessToken();
				accessToken.setToken(token);
				accessToken.setExpiresIn((int)((System.currentTimeMillis() - updatetime)/1000));
				shardedJedisPool.returnResource(shardedJedis);
				return accessToken;
			}
		}
		KmWxInfo instance = new KmWxInfo();
		instance.setAppid("wxd63248a75b932894"); //cs:wx365c10c5232278d3
		instance.setType(1);
		
		List<KmWxInfo> tokens = kmWxInfoDAO.findByExample(instance);
		if(tokens!=null&&tokens.size()>0){
			System.err.println("accessToken==1");
			instance = tokens.get(0);
			if((System.currentTimeMillis() - tokens.get(0).getUpdatetime().getTime()) < 7000 * 1000){
				System.err.println("accessToken==1-1");
//				accessToken =new AccessToken();
//				accessToken.setToken(tokens.get(0).getContent());
//				accessToken.setExpiresIn((int)((System.currentTimeMillis() - tokens.get(0).getUpdatetime().getTime())/1000));
//				return accessToken;
			}else{
				System.err.println("accessToken==1-2");
				accessToken=WeixinUtil.getAccessToken("wxd63248a75b932894", "0d1cebc086ff5ca5a60f8dc4d2fea35a");//  cs:wx365c10c5232278d3
				instance.setContent(accessToken.getToken());
				instance.setUpdatetime(new Date(System.currentTimeMillis()));
				kmWxInfoDAO.attachDirty(instance);
			}
		} else {
			System.err.println("accessToken==2");
			accessToken=WeixinUtil.getAccessToken("wxd63248a75b932894", "0d1cebc086ff5ca5a60f8dc4d2fea35a");// cs:eac1dd18813e6f8df303bae40692509b
			instance.setContent(accessToken.getToken());
			instance.setUpdatetime(new Date(System.currentTimeMillis()));
			instance.setCreatetime(new Date(System.currentTimeMillis()));
			kmWxInfoDAO.attachDirty(instance);
		}
		accessToken =new AccessToken();
		accessToken.setToken(instance.getContent());
		accessToken.setExpiresIn((int)((System.currentTimeMillis() - instance.getUpdatetime().getTime())/1000));
		shardedJedis.hset(WX_ACCESSTOKEN, "Token", instance.getContent());
		shardedJedis.hset(WX_ACCESSTOKEN, "updatetime", String.valueOf(instance.getUpdatetime().getTime()));
		shardedJedisPool.returnResource(shardedJedis);
		return accessToken;
//		System.err.println("accessToken==2");
//		accessToken=WeixinUtil.getAccessToken(config.getAppid(), config.getAppsecret());
//		if(tokens != null && tokens.size() > 0){
//			instance = tokens.get(0);
//		}else {
//			instance.setCreatetime(new Date(System.currentTimeMillis()));
//		}
//		instance.setContent(accessToken.getToken());
//		instance.setUpdatetime(new Date(System.currentTimeMillis()));
//		kmWxInfoDAO.save(instance);
//		System.out.println(accessToken);
//		return accessToken;
	}
	
}
