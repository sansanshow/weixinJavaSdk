package com.kidmate.action;

import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import oracle.net.TNSAddress.Description;

import org.apache.commons.digester.rss.Channel;
import org.apache.commons.digester.rss.Item;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;


import com.kidmate.model.KmRss;
import com.kidmate.model.KmRssChan;
import com.kidmate.model.KmRssChannel;
import com.kidmate.model.KmRssChannelDao;
import com.kidmate.model.KmRssDao;
import com.kidmate.tools.Config;



//@Controller
//@RequestMapping(value="/kmRss")
public class KmRssAction {
    
    private KmRssChannelDao  kmRssChannelDao;
    private Config config;
	private KmRssDao  kmRssDao;
	//@RequestMapping(value="/rss/{title}")
	public String gorss(@PathVariable("title") String title,
			HttpServletRequest request, HttpServletResponse response
			) {
		String filtPath=null;
		String fileName=null;
		// stepSize, page
		List<KmRssChannel> krcannel=kmRssChannelDao.findBytitle(title);
		List<KmRss> kmrsses=new ArrayList<KmRss>();
		Channel newChannel = new Channel();
		if(krcannel!=null&&krcannel.size()>0){
			newChannel.setCopyright("(c)Real Gagnon 2007");
			newChannel.setDescription(krcannel.get(0).getDescription());
			newChannel.setLink(krcannel.get(0).getLink());
			newChannel.setLanguage("zh-cn");
			newChannel.setPubDate(krcannel.get(0).getCreatetime().toString());
			kmrsses = kmRssDao.findByProperty("channelId", krcannel.get(0).getId());
			fileName=krcannel.get(0).getId()+"feed.xml";
		}
//	    List<KmRss> kmrsses = kmRssDao.findAll();
//		List<KmRssChan> krces = new ArrayList<KmRssChan>();
		
		for (KmRss kmrc : kmrsses) {
			Item item = new Item();
			item.setTitle(kmrc.getTitle());
			item.setLink(kmrc.getLink());
			
	        item.setDescription(kmrc.getDescription().toString());
			newChannel.setPubDate(kmrc.getPubdate().toString());
			newChannel.addItem(item);
	
		}
		try {
			if(fileName!=null){
				filtPath= config.getImagePath()+"/"+fileName;
				FileOutputStream fout = new FileOutputStream(filtPath);
				newChannel.render(fout);
				fout.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("----------"+config.getImageUrl()+fileName);
		return config.getImageUrl()+fileName;
	}

	
	public KmRssChannelDao getKmRssChannelDao() {
		return kmRssChannelDao;
	}
	public void setKmRssChannelDao(KmRssChannelDao kmRssChannelDao) {
		this.kmRssChannelDao = kmRssChannelDao;
	}
	
	public KmRssDao getKmRssDao() {
		return kmRssDao;
	}
	public void setKmRssDao(KmRssDao kmRssDao) {
		this.kmRssDao = kmRssDao;
	}


	public Config getConfig() {
		return config;
	}


	public void setConfig(Config config) {
		this.config = config;
	}
 
}
