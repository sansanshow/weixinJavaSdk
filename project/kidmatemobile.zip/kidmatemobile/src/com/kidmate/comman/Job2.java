package com.kidmate.comman;

import java.util.Date;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.kidmate.service.ICreditService;
import com.kidmate.service.impl.CreditServiceImpl;

public class Job2 {
	    @Autowired
		@Qualifier("CreditServiceImpl")
	   private CreditServiceImpl   creditServiceImpl;
		public  void doJob2() {  
		System.out.println("不继承QuartzJobBean方式-调度进行中..."+new Date().toLocaleString());  
		
			System.out.println("--------更新积分");
			creditServiceImpl.quartzCredit();
			System.out.println("-------更新完毕");
		
		}
	
		
	 
}
