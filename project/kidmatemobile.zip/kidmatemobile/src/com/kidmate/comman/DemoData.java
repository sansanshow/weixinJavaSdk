package com.kidmate.comman;



import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.kidmate.kmservice.TKmAppInfo;
import com.kidmate.kmservice.TKmAppUsage;
import com.kidmate.kmservice.TKmAppUsageStatistics;
import com.kidmate.kmservice.TKmChild;
import com.kidmate.kmservice.TKmControlRuleInfo;
import com.kidmate.kmservice.TKmEquipment;
import com.kidmate.kmservice.TKmSnapshot;
import com.kidmate.kmservice.TKmTimeStatistics;
import com.kidmate.kmservice.TKmUser;
import com.kidmate.model.KmAppUsage;
import com.kidmate.model.KmSnapshot;

public class DemoData {

	/**
	 * @param args
	 */
	//最近app使用时间；
	private static long[] appUsage ={60000*40, 60000*30, 60000*20, 60000*10, 60000*20, 60000*26, 60000*30};
	//孩子的数据图表  第一位为同龄孩子，第二位为孩子数据， 60000
	private static long[][] ChildTime ={{60000*20,60000*2},{60000*28,60000*10},{60000*20,60000*25},{60000*45,60000*10},{60000*35,60000*13},{60000*40,60000*25}};
	//所有的app
	private static long[] appid ={6000,5697,5696,5695,5694,5683,5682,5679,5665,5601,5593,5538,5535,5510,5977,5983};
	private static String[]  controlname={"","学习时间","睡觉时间"};
	//截屏图片链接
	private static String[] snaphotLink={"","",""};
	
	public static List<TKmAppInfo> getAppInfoByIDs(){
		
		
		return null;
	}
	
	//返回所有的app  id   //1代表获取在控制的app，2表示获取不在控制控制的app,0代表获取所有的app
	public static List<Long> getEquipmentApp(int j){
		List<Long> app=new ArrayList<Long>();
		int start,end;
		if(j==0){
			start=0;
			end=appid.length;
		}else if(j==1){
			start=0;
			end=3;
		}else{
			start=3;
			end=appid.length;
		}
		for(int i=start;i<end;i++){
			app.add(appid[i]);
		}
		return app;
	}
	
	//返回孩子
	public static List<TKmChild> getChildList(){
		TKmChild tk=new TKmChild();
		tk.setId(2142l);
		tk.setName("Baby1");
	    tk.setBirth(946656000000L);
		tk.setGender(true);
		List<TKmChild> tc=new ArrayList<TKmChild>();
		tc.add(tk);
		return tc;
		
	}
	
	//返回家长下的孩子的所有设备
	public static List<TKmEquipment> getAllEquipment(){
		List<TKmEquipment> te = new ArrayList<TKmEquipment>();
		TKmEquipment t=new TKmEquipment();
		t.setAliasName("HUAWEI 4C");
		t.setMac("test11111");
		t.setId(2105L);
		t.setChildId(2142l);
		t.setLasttime(System.currentTimeMillis()-60000*1);
		te.add(t);
		return te;
	}
	
	public static List<TKmTimeStatistics> getChildTimeStatistics(){
		List<TKmTimeStatistics> tKmTimeStatisticsList = new ArrayList<TKmTimeStatistics>();
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(System.currentTimeMillis());
		cal.add(Calendar.DAY_OF_MONTH, 0-5);
		for(int i=0;i<5;i++){
			Date d = cal.getTime();
			TKmTimeStatistics tKmTimeStatistics = new TKmTimeStatistics();  //5492160  0  0  0   60*60*1000
			tKmTimeStatistics.setTime(d.getTime());
			tKmTimeStatistics.setAvgDuration(ChildTime[i][0]);	
			tKmTimeStatistics.setSelfDuration(ChildTime[i][1]);
//			tKmTimeStatistics.setAvgDuration(300000*(i+2));	
//			tKmTimeStatistics.setSelfDuration(300000*(i+1)-30000*(i+3));
			tKmTimeStatisticsList.add(tKmTimeStatistics);
			 cal.add(Calendar.DAY_OF_MONTH, 1);
		}
		
		
		return tKmTimeStatisticsList;
	}
	
	//获取孩子app使用情况
	public static List<TKmAppUsageStatistics> getChildAppUsageStatistics(int days){
		List<TKmAppUsageStatistics> tKmAppUsageStatisticsList = new ArrayList<TKmAppUsageStatistics>();
		 //long[][] l ={{5516,1478847},{5498,1478847},{5537,47979},{5543,47979},{5516,1478847},{5568,6078}};
		for(int i=0;i<5;i++){                       
			TKmAppUsageStatistics tKmAppUsageStatistics = new TKmAppUsageStatistics();
			int k=0;
			if(days==7){
				k=2;
			}
			tKmAppUsageStatistics.setAppid(appid[i+k]);
		    tKmAppUsageStatistics.setDuration(appUsage[i]);
            tKmAppUsageStatisticsList.add(tKmAppUsageStatistics);
		}
		return tKmAppUsageStatisticsList;
	}
	
	//最后使用app的时间    5516  60180  9352  1470993143000  2446
	 public static TKmAppUsage getTheLatestAppUsage(){
		 TKmAppUsage t=new TKmAppUsage();
		 int i=(int)(Math.random()*10);
		 t.setAppid(appid[i]);
		 t.setDuration(60180);
		 t.setId(9352);
		 t.setTime(System.currentTimeMillis());
		// t.setTime(System.currentTimeMillis()-1000*60*i);
		 return t;
	 }
	 
	 
	 //获取所有规则
	 public static List<TKmControlRuleInfo> getAllControlRuleInfo(){
		 List<TKmControlRuleInfo> tKmControlRuleInfoList = new ArrayList<TKmControlRuleInfo>();
		 for(int i=1;i<3;i++){
			 TKmControlRuleInfo tKmControlRuleInfo = new TKmControlRuleInfo();
			    tKmControlRuleInfo.setId(2500+i);
				tKmControlRuleInfo.setParentId(2000);
				tKmControlRuleInfo.setAppId(0);
				tKmControlRuleInfo.setChildId(2142);
				tKmControlRuleInfo.setEquipmentId(2105);
				tKmControlRuleInfo.setDur(0);
				tKmControlRuleInfo.setEndTime(66600000);
				tKmControlRuleInfo.setStartTime(57600000);
				tKmControlRuleInfo.setOn(1==i);//"1".equals(String.valueOf(i))
				tKmControlRuleInfo.setExceptapp(null);
				tKmControlRuleInfo.setRepeatType(i*20);
				tKmControlRuleInfo.setCreattime(System.currentTimeMillis());
				
				tKmControlRuleInfo.setControlname(controlname[i]);
				tKmControlRuleInfoList.add(tKmControlRuleInfo);
		 }
			
			System.out.print("---DemoData=="+tKmControlRuleInfoList.get(0).on);
			return tKmControlRuleInfoList;
		 
	 }
	 
	 //获取设备今日使用情况
	 public static List<TKmAppUsage> getchildtoday(){
		 List<TKmAppUsage> tKmAppUsageList = new ArrayList<TKmAppUsage>();
			for (int i=0;i<10;i++) {
				TKmAppUsage tKmAppUsage = new TKmAppUsage();
				tKmAppUsage.setAppid(appid[i]);
			    tKmAppUsage.setDuration(60000*(int)(Math.random()*10));
				tKmAppUsage.setTime(System.currentTimeMillis());
				tKmAppUsageList.add(tKmAppUsage);
			}
			return tKmAppUsageList;
	 }
	 
	
	public static List<TKmSnapshot> getSnapshots(){
		List<TKmSnapshot> tkmsnaps=new  ArrayList<TKmSnapshot>();
	    for(int i=3000;i<3000+snaphotLink.length;i++){
			TKmSnapshot tKmSnapshot=new TKmSnapshot();
			tKmSnapshot.setId(i);
			tKmSnapshot.setUrl(snaphotLink[i-3000]);
			tKmSnapshot.setTime(System.currentTimeMillis());
			tkmsnaps.add(tKmSnapshot);
		}
		return tkmsnaps;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(System.currentTimeMillis());
		cal.add(Calendar.DAY_OF_MONTH, 0-6);
       System.out.println("1".equals(1));
	}

}
