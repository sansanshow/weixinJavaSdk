package com.kidmate.thread;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;


import com.kidmate.tools.Config;

import com.taobao.api.ApiException;
import com.taobao.api.BaseTaobaoRequest;
import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.domain.CustMsg;
import com.taobao.api.domain.ImMsg;
import com.taobao.api.domain.Userinfos;
import com.taobao.api.request.OpenimCustmsgPushRequest;
import com.taobao.api.request.OpenimImmsgPushRequest;
import com.taobao.api.request.OpenimUsersAddRequest;
import com.taobao.api.request.UserGetRequest;
import com.taobao.api.response.OpenimCustmsgPushResponse;
import com.taobao.api.response.OpenimImmsgPushResponse;
import com.taobao.api.response.OpenimUsersAddResponse;
import com.taobao.api.response.UserGetResponse;

public class MessageSendRunnable implements Runnable{
	class MessageInfo {
		boolean isToSelf;
		String fromid;
		List<String> toidList;
		String content;
		String summary;
		String extend; //JSON
	}
	private static Logger logger = Logger.getLogger(MessageSendRunnable.class);
	private LinkedList<MessageInfo> list = new LinkedList<MessageInfo>(); 
	public void addMessageInfo(MessageInfo messageInfo) {
		synchronized (list) {
			list.add(messageInfo);
			list.notify();
		}
	}
	public void addMessage(boolean isToSelfApp,String fromid, List<String> toIdList, String content,String summary, String extend) {
		MessageInfo messageInfo = new MessageInfo(); 
		messageInfo.isToSelf = isToSelfApp;
		messageInfo.fromid = fromid;
		messageInfo.toidList = toIdList;
		messageInfo.content = content;
		messageInfo.summary = summary;
		messageInfo.extend = extend; //JSON
		synchronized (list) {
			list.add(messageInfo);
			list.notify();
		}
	}

	public void addMessage(boolean isToSelfApp,String fromid,  String toId, String content,String summary, String extend) {
		MessageInfo messageInfo = new MessageInfo(); 
		messageInfo.isToSelf = isToSelfApp;
		messageInfo.fromid = fromid;
		List<String> toIdList = new ArrayList<String>();
		toIdList.add(toId);
		messageInfo.toidList = toIdList;
		messageInfo.content = content;
		messageInfo.summary = summary;
		messageInfo.extend = extend; //JSON
		synchronized (list) {
			list.add(messageInfo);
			list.notify();
		}
	}
	
	private Config config;
	private boolean isParentClient;
	
	@Override
	public void run() {
		logger.info("------------MessageSendRunnable start-----------------");
		// TODO Auto-generated method stub
		String selfKey = null;
		String selfSec = null;
		String otherKey = null;
		if (isParentClient) {
			selfKey = config.getParentAppkey();
			selfSec = config.getParentAppSec();
			otherKey = config.getChildAppKey();
		} else {
			selfKey = config.getChildAppKey();
			selfSec = config.getChildAppSec();
			otherKey = config.getParentAppkey();
		}
		while (true) {
			try {
				TaobaoClient client = new DefaultTaobaoClient(config.getTaoBaoServerUrl(), selfKey, selfSec);
				while (true) {
					MessageInfo messageInfo = null;
					synchronized (list) {
						if (list.size()!=0) {
							messageInfo = list.pollLast();
						}
						else {
							try {
								logger.info("------------MessageSendRunnable wait-----------------");
								list.wait();
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}
					}
					if (messageInfo!=null && messageInfo.toidList!=null && messageInfo.toidList.size()>0) {
						if (messageInfo.summary!=null) {
							OpenimCustmsgPushRequest req = new OpenimCustmsgPushRequest();
							CustMsg custMsg = new CustMsg();
							custMsg.setFromUser(messageInfo.fromid);
							if (!messageInfo.isToSelf) {
								custMsg.setToAppkey(otherKey);
							}
							custMsg.setToUsers(messageInfo.toidList);
							custMsg.setSummary(messageInfo.summary);
							custMsg.setData(messageInfo.content);
							custMsg.setAps("{\"alert\":\"" + messageInfo.summary +"\"}");
							if (messageInfo.extend!=null && messageInfo.extend.length()!=0)
								custMsg.setApnsParam(messageInfo.extend);
							req.setCustmsg(custMsg);
							OpenimCustmsgPushResponse rsp = client.execute(req);
							logger.info(rsp.getBody());
						} else {
							OpenimImmsgPushRequest req = new OpenimImmsgPushRequest();
							ImMsg imMsg = new ImMsg();
							imMsg.setFromUser(messageInfo.fromid);
							imMsg.setToUsers(messageInfo.toidList);
							imMsg.setMsgType(0L);
							imMsg.setContext(messageInfo.content);
							if (!messageInfo.isToSelf) {
								imMsg.setToAppkey(otherKey);
							}
							req.setImmsg(imMsg);
							OpenimImmsgPushResponse rsp = client.execute(req);
							logger.info(rsp.getBody());
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String args[]) throws ApiException {
		TaobaoClient client = new DefaultTaobaoClient("http://gw.api.taobao.com/router/rest", "23300999", "cfc6a51b36d3bc54ddd8f403dd29d4d7");
		
		 OpenimUsersAddRequest req = new OpenimUsersAddRequest();
		List<Userinfos> list117620 = new ArrayList<Userinfos>();
		Userinfos obj117620 = new Userinfos();
		obj117620.setNick("系统用户");
		obj117620.setUserid("1000");
		obj117620.setPassword("xxxxdasdddfassasdfadfsxx");
		obj117620.setIconUrl("http://d.lanrentuku.com/down/png/0906/Vista-desktop/Vista-desktop-07.png");
		list117620.add(obj117620);
		req.setUserinfos(list117620);
		OpenimUsersAddResponse rsp = client.execute(req);
		System.out.print(rsp.getBody());
		//logger.info(rsp.getBody()); */
		
		
		
	       // User user = response.getUser();  
//		List<String> toList = new ArrayList<String>();
//		toList.add("4398047314924"); //john
////		toList.add("4398047322583"); // me
////		toList.add("4398047334897"); // qiu
//		
//		
////		OpenimImmsgPushRequest req = new OpenimImmsgPushRequest();
////		ImMsg imMsg = new ImMsg();
////		imMsg.setFromUser("999");
////		imMsg.setToUsers(toList);
////		imMsg.setMsgType(0L);
////		imMsg.setContext("Are you ready!");
////		//imMsg.setMediaAttr("{\"type\":\"amr\",\"playtime\":6}");
////		req.setImmsg(imMsg);
////		OpenimImmsgPushResponse rsp = client.execute(req);
//		
//		OpenimCustmsgPushRequest req = new OpenimCustmsgPushRequest();
//		CustMsg custMsg = new CustMsg();
//		custMsg.setFromUser("1000");
//		custMsg.setToUsers(toList);
//		custMsg.setSummary("DADFFASDF");
//		custMsg.setData("{\"DFF\":\"--------\"}");
//		custMsg.setAps("{\"alert\":\"----------------\"}");
//		custMsg.setApnsParam("---");
//		req.setCustmsg(custMsg);
////		OpenimCustmsgPushResponse rsp = client.execute(req);
////		logger.info(rsp.getBody());
//		
//		TaobaoClient client1 = new DefaultTaobaoClient("http://gw.api.taobao.com/router/rest", "23301260", "5ffba5b8844fb74914cedb0ff5d1fa1c");
//		custMsg.setFromUser("4398047403257");
//		custMsg.setToAppkey("23300999");
//		req.setCustmsg(custMsg);
//		OpenimCustmsgPushResponse rsp = client.execute(req);
//		logger.info(rsp.getBody());
		
	}



	public Config getConfig() {
		return config;
	}

	public void setConfig(Config config) {
		this.config = config;
	}
	public boolean isParentClient() {
		return isParentClient;
	}
	public void setParentClient(boolean isParentClient) {
		this.isParentClient = isParentClient;
	}
}
