package com.kidmate.thread;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.thrift.TException;

import com.kidmate.kmservice.TKmAppUsage;
import com.kidmate.service.impl.AppUsageServiceImpl;
import com.kidmate.tools.Constants;
import com.kidmate.tools.RedisUtil;
import com.kidmate.tools.SerializeUtil;



import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;
import redis.clients.jedis.exceptions.JedisConnectionException;
import redis.clients.jedis.exceptions.JedisDataException;
import redis.clients.jedis.exceptions.JedisException;

public class AppUsageRunnable implements Runnable{
	
	private ShardedJedisPool shardedJredisPool;
	private AppUsageServiceImpl appUsageServiceImpl;

	public static class AppUsage implements Serializable{
		private long equipmentid;
		private long appid;
		private long wifiid;
		private long positionid;
		private String ip;
		private long time;
		public AppUsage(long equipmentid, long appid, long wifiid, long positionid, String ip, long time) {
			this.equipmentid = equipmentid;
			this.appid = appid;
			this.wifiid = wifiid;
			this.positionid = positionid;
			this.ip = ip;
			this.time = time;
		}
		public TKmAppUsage getTKmAppUsage() {
			TKmAppUsage tKmAppUsage= new TKmAppUsage();
			tKmAppUsage.setAppid(appid);
			tKmAppUsage.setWifiid(wifiid);
			tKmAppUsage.setPositionid(positionid);
			tKmAppUsage.setTime(time);
			return tKmAppUsage;
		}
		public String getIp() {
			return ip;
		}
		public long getEquipmentid() {
			return equipmentid;
		}
	}
	
	private static Logger logger = Logger.getLogger(AppUsageRunnable.class);
	public AppUsageRunnable() {
		System.out.println("BillOperateRunnable Instance:" + this);
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		logger.info("------------BillOperateRunnable start-----------------");
	
		while (true) {
			ShardedJedis shardedJedis = null;
			boolean broken = false;
			try {
				shardedJedis =  shardedJredisPool.getResource();
				while (true) {
					byte[] b = shardedJedis.rpop(Constants.APP_USEAGE.getBytes());
					if (b!=null) {
						AppUsage appUsage = SerializeUtil.unserialize(b);
						if (appUsage!=null) {
							appUsageServiceImpl.addAppUsage(appUsage.getEquipmentid(), appUsage.getTKmAppUsage(), appUsage.getIp(), null);
						}
					} else {
						synchronized(this) {
							logger.info("------------BillOperateRunnable wait-----------------");
							AppUsageRunnable.this.wait();
						}
					}
				}
				} catch (Exception e) {
					//broken=handleJedisException(e);
					logger.error(e.getMessage());
			} finally {
				// closeResource(shardedJedis, broken);
				if(shardedJedis!=null)
				shardedJredisPool.returnResource(shardedJedis);
			}
		}
	}

	public ShardedJedisPool getShardedJredisPool() {
		return shardedJredisPool;
	}

	public void setShardedJredisPool(ShardedJedisPool shardedJredisPool) {
		this.shardedJredisPool = shardedJredisPool;
	}

	public AppUsageServiceImpl getAppUsageServiceImpl() {
		return appUsageServiceImpl;
	}

	public void setAppUsageServiceImpl(AppUsageServiceImpl appUsageServiceImpl) {
		this.appUsageServiceImpl = appUsageServiceImpl;
	}

	
	
	/**
	 * Handle jedisException, write log and return whether the connection is broken.
	 */
	protected boolean handleJedisException(Exception e) {
	    if (e instanceof JedisConnectionException) {
	        System.out.println("Redis connection  lost.");
	    } else if (e instanceof JedisDataException) {
	        if ((e.getMessage() != null) && (e.getMessage().indexOf("READONLY") != -1)) {
	            System.out.println("Redis connection are read-only slave.");
	        } else {
	            // dataException, isBroken=false
	        	logger.info("dataException--------zz"+e);
	            return true;
	        }
	    } else {
	    	 logger.info("Jedis exception happen------------.", e);
	    }
	    return true;
	}
	/**
	 * Return jedis connection to the pool, call different return methods depends on the conectionBroken status.
	 */
	protected void closeResource(ShardedJedis jedis, boolean conectionBroken) {
	    try {
	        if (conectionBroken) {
	        	shardedJredisPool.returnBrokenResource(jedis);
	        } else {
	        	shardedJredisPool.returnResource(jedis);
	        }
	    } catch (Exception e) {
	        logger.info("return back jedis failed, will fore close the jedis.", e);
	        jedis=null;
	    }
	}
	
	 
}
