package com.kidmate.tools;

public class StringUtils {

	/*
	 * 截取rss链接
	 */
	public static String subUrl(String dec){
		 int index=dec.indexOf("img");
		 if(index==-1){
			 return null;
		 }
		 String desc=dec.substring(index);
		 int index1=desc.indexOf("src=");
		 int index2=desc.indexOf(">");
		 return desc.substring(index1+5, index2-1);
		
	}
	

	/*
	 * 截取rss描述
	 */
	public static String subDescrip(String dec){
		 int index=dec.indexOf("img");
		 if(index==-1){
			 return dec;
		 }
		 String desc=dec.substring(index);
		
		 int index2=desc.indexOf(">");
		 return desc.substring(index2,desc.length());
		
	}
}
