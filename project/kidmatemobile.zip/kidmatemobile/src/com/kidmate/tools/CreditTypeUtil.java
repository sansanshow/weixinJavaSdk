package com.kidmate.tools;

public class CreditTypeUtil {
    private final long typeId=1;//点击类型
    
    public static long getScoredBytype(long creditType){
    	long score=0;
    	switch((int)creditType){
    	case 1:score=10;break;
    	     
    	}
		return score;
    	
    }
}
