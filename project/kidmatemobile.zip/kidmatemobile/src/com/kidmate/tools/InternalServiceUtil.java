package com.kidmate.tools;

import org.apache.commons.pool2.impl.GenericObjectPool;
import com.kidmate.kmservice.InternalService.Iface;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

public class InternalServiceUtil {
	
	private Iface internalService;
	private GenericObjectPool<Iface> genericObjectPool;
	
	public Iface borrowInternal() {
		// TODO Auto-generated method stub
		if (internalService!=null) {
			return internalService;
		} else if (genericObjectPool!=null) {
			try {
				return genericObjectPool.borrowObject();
			} catch (Exception e) {
				return null;
			}
		}
		return null;
	}

	public void returnInternal(Iface iface) {
		if (internalService!=iface && genericObjectPool!=null) {
			genericObjectPool.returnObject(iface);
		}
	}

	public Iface getInternalService() {
		return internalService;
	}


	public void setInternalService(Iface internalService) {
		this.internalService = internalService;
	}


	public GenericObjectPool<Iface> getGenericObjectPool() {
		return genericObjectPool;
	}


	public void setGenericObjectPool(GenericObjectPool<Iface> genericObjectPool) {
		this.genericObjectPool = genericObjectPool;
	}
}
