package com.kidmate.tools;

import com.kidmate.kmservice.TKmException;
import com.kidmate.kmservice.TKmExceptionType;

public class ExceptionUtil {
	public static void throwDefaultKmException(String reason) throws TKmException {
		TKmException tKmException = new TKmException();
		tKmException.setWhatOp(TKmExceptionType.DEFAULT);
		tKmException.setWhy(reason);
		throw tKmException;
	}
	
	public static void throwUnauthorizedKmException() throws TKmException {
		TKmException tKmException = new TKmException();
		tKmException.setWhatOp(TKmExceptionType.UNAUTHORIZED);
		tKmException.setWhy("未经授权！");
		throw tKmException;
	}
	
	public static void throwUnloginKmException() throws TKmException {
		TKmException tKmException = new TKmException();
		tKmException.setWhatOp(TKmExceptionType.UNLOGIN);
		tKmException.setWhy("未登录或者登陆过期!");
		throw tKmException;
	}
}
