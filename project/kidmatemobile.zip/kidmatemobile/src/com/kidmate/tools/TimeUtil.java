package com.kidmate.tools;

import java.util.Calendar;
import java.util.Date;

public class TimeUtil {
   
	public static Date getToday(){
		Calendar cal=Calendar.getInstance();
		cal.setTimeInMillis(System.currentTimeMillis());
		cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        Date time=cal.getTime();
        return time;
	}
}
