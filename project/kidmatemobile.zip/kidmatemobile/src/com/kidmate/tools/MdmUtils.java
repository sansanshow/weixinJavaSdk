package com.kidmate.tools;
import sun.misc.BASE64Decoder;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.Namespace;
import org.jdom2.Document;
import org.jdom2.input.SAXBuilder;
import org.xml.sax.InputSource;


import com.alipay.sign.Base64;
import com.kidmate.kmservice.TKmAppInfoUpload;
import com.kidmate.model.KmEquipment;



/**
 * 和IOS的MDM相关的工具方法
 * @author jiang.li
 *
 */
public class MdmUtils {

    /**定义pList中的相关key常量**/
    public static final String MessageType = "MessageType";
    public static final String Topic = "Topic";
    public static final String UDID = "UDID";
    public static final String PushMagic = "PushMagic";
    public static final String UnlockToken = "UnlockToken";
    public static final String Token = "Token";
    public static final String Identifier="cn.kidzz";//限制程序使用的文件的唯一标识
    
    /**定义checkIn两种请求路径**/
    public static final String Authenticate = "Authenticate";
    public static final String TokenUpdate = "TokenUpdate";
    public static final String CheckOut = "CheckOut";
    public static final String Repay = "Repay";
    



    /**定义pList字符串解析正则式**/
    public static final String DATA = "\\<data>(.*?)\\</data>";
    public static final String STRING = "\\<string>(.*?)\\</string>";
    public static final String KEY = "\\<key>(.*?)\\</key>";
    public static final String DICT = "\\<dict>(.*?)\\</dict>";
    public static final String ARRAY = "\\<array>(.*?)\\</array>";


    /**定义命令类型**/
    public static final String Lock = "DeviceLock";
    public static final String Erase = "EraseDevice";
    public static final String Info = "DeviceInformation";
    public static final String Apps = "InstalledApplicationList";
    public static final String Clear = "ClearPasscode";
    public static final String Online = "Online";
    public static final String Provisioning = "ProvisioningProfileList";  //获取所有安装的证书
    public static final String ManagedApp="ManagedApplicationList";//管理app应用
    public static final String Sett="Settings";//设置的信息
    public static final String Security="SecurityInfo";//安全的信息
    public static final String Restriction="RestrictionsList";//限制列表
    public static final String InstallProfile="InstallProfile";//安装限制规则的配置文件
    public static final String UnInstallProfile="UnInstallProfile";//安装取消限制的配置文件。
    public static final String RemoveProfile="RemoveProfile";//删除文件
    
    /**MDM请求服务器端状态**/
    public static final String Idle = "Idle";
    public static final String Acknowledged = "Acknowledged";
    public static final String CommandFormatError = "CommandFormatError";
    public static final String Error = "Error";
    public static final String NotNow = "NotNow";
    public static final String QueryResponses = "QueryResponses";
    public static final String InstalledApplicationList = "InstalledApplicationList";
    public static final String ProfileList = "ProfileList";
   
     
    /**
     * 获取Information的pList文件Map数据
     * @param pList
     * @return
     */
    public static String parseUnlockToken(String pList){
        /**组装查询结果中重要的数据（一）**/
        int dataStart = pList.lastIndexOf("<data>")+6;
        int dataEnd = pList.lastIndexOf("</data>");
        String strBlank =  pList.substring(dataStart,dataEnd);
        return strBlank;
    }



    /**
     * 将通过TokenUpdate获取的原始Token转化成16进制新的Token
     * @param OriToken
     * @return
     * @throws IOException
     */
    public static String parseToken(String OriToken) throws IOException{
        BASE64Decoder decoder = new BASE64Decoder();
        byte[] decodedBytes = decoder.decodeBuffer(OriToken);
        StringBuffer buf = new StringBuffer();
        for (int i = 0; i < decodedBytes.length; ++i) {
            buf.append(String.format("%02x", decodedBytes[i]));
        }
        String Token = buf.toString();
        return  Token;
    }


    /**
     * 获取Information的pList文件Map数据
     * @param pList
     * @return
     */
    public static Map<String, String> parseInformation(String pList){
        /**组装查询结果中重要的数据（一）**/
        String strBlank = replaceBlank(pList);
        strBlank =  strBlank.replace("<key>QueryResponses</key><dict>","");
        strBlank =  strBlank.replace("</dict><key>Status</key>","<key>Status</key>");
        strBlank =  strBlank.replace("<real>","<string>");
        strBlank =  strBlank.replace("</real>","</string>");
        Map<String, String> plistMap = new HashMap<String, String>();
        /**获取key、string列表数据**/
        List<String> keyList = getList(KEY,strBlank);
        List<String> stringList = getList(STRING,strBlank);
        /**组装数据称plistMap**/
        for(int i=0;i<stringList.size();i++){
            plistMap.put(keyList.get(i), stringList.get(i));
        }
        return plistMap;
    }


    /**
     * 获取InstalledApplicationList的pList文件Map数据
     * @param pList
     * @return
     */
    public static Map<String, Map<String, String>> parseInstalledApplicationList(String pList){

        String strBlank  = replaceBlank(pList);

        /**(1)、组装APP列表数据**/
        String newBlank =  getList(ARRAY,strBlank).get(0);
        List<String> dictList = getList(DICT,newBlank);

        Map<String,Map<String,String>> dictMapList = new HashMap<String ,Map<String, String>>();
        Map<String,String> dictMap = null;
        for(String dict : dictList){
            dictMap = new HashMap<String,String>();
            dict = dict.replace("integer","string");
            List<String> keyList = getList(KEY,dict);
            List<String> stringList = getList(STRING,dict);
            for(int num=0;num<keyList.size();num++){
                dictMap.put(keyList.get(num),stringList.get(num));
            }
            dictMapList.put(dictMap.get(Identifier),dictMap);
        }
        /**(2)、组装其他数据**/
        String otherStr = strBlank.replace(newBlank,"").replace("<array>","").replace("</array>","").replace("<key>InstalledApplicationList</key>","");

        List<String> keyList = getList(KEY,otherStr);
        List<String> stringList = getList(STRING,otherStr);
        dictMap = new HashMap<String,String>();
        for(int num=0;num<keyList.size();num++){
            dictMap.put(keyList.get(num),stringList.get(num));
        }
        dictMapList.put(InstalledApplicationList,dictMap);
        return  dictMapList;
    }

    //解析app的xml的格式
    public static List<TKmAppInfoUpload> getIosApp(String pList) {
    	  List<TKmAppInfoUpload> tKmApps=new ArrayList<TKmAppInfoUpload>();
    	 // System.out.println(pList);
    	//创建一个新的字符串
          StringReader read = new StringReader(pList);
          //创建新的输入源SAX 解析器将使用 InputSource 对象来确定如何读取 XML 输入
          InputSource source = new InputSource(read);
          //创建一个新的SAXBuilder
          SAXBuilder sb = new SAXBuilder();
          try {
              //通过输入源构造一个Document
              Document doc = sb.build(source);
              //取的根元素
              Element root = doc.getRootElement();//获得跟袁术 plist
             // System.out.println(root.getName());//输出根元素的名称（测试）
              //得到根元素所有子元素的集合
              List plist= root.getChildren();  //plist 下所有孩子  (dict)
              //获得XML中的命名空间（XML中未定义可不写）
             // Namespace ns = root.getNamespace();
              Element et1 = null;
              Element et2 = null;
              Element et3 = null;
              List  dict=null;
              List arrayss=null;
              List  keyintst=null;
              List  result4=null;
              for(int i=0;i<plist.size();i++){
              	//System.out.println("plist child----"+plist.size());
                  et1 = (Element) plist.get(i);//循环依次得到孩子元素    dict
                  dict=et1.getChildren();  //  dict  下所有孩子  key string int  array
              } 
                for(int i1=0;i1<dict.size();i1++){
              	 et2=(Element)dict.get(3); //循环依次得到dict孩子元素    array
          	      arrayss=et2.getChildren();  //array下的所有孩子
          	      break;
                }
          	      for(int j=0;j<arrayss.size();j++){
          	    	  et3=(Element)arrayss.get(j);  //循环依次得到 arrayss下孩子元素    <dict>
          		      keyintst=et3.getChildren();  //arrayss下dict所有孩子元素
          	        for(int k=0;k<arrayss.size();k++){
          	        	TKmAppInfoUpload tKmApp=new TKmAppInfoUpload();
          	           //String src="https://itunes.apple.com/lookup?bundleId="+et3.getChildren().get(5).getText();
                       tKmApp.setName(et3.getChildren().get(9).getText());
          	        	tKmApp.setPackagename(et3.getChildren().get(5).getText());
          	        	tKmApps.add(tKmApp);
					break;
          	        }
          	      }
          } catch (Exception e) {
        	  return tKmApps;
          } 
          
    	  return tKmApps;
    } 
    
    
    /**
     * 获取Information的pList文件Map数据
     * @param pList
     * @return
     */
    public static Map<String, String> parseOtherInformation(String pList){
        /**组装查询结果中重要的数据（一）**/
        String strBlank = replaceBlank(pList);
        int startNum = strBlank.lastIndexOf("<key>QueryResponses</key>");
        int endNum = strBlank.indexOf("</dict>",1)+7;
        String nowStr = strBlank.substring(startNum,endNum);
        nowStr = strBlank.replace(nowStr,"");
        Map<String, String> plistMap = new HashMap<String, String>();
        /**获取key、string列表数据**/
        List<String> keyList = getList(KEY,nowStr);
        List<String> stringList = getList(STRING,nowStr);
        /**组装数据称plistMap**/
        for(int i=0;i<stringList.size();i++){
            plistMap.put(keyList.get(i), stringList.get(i));
        }
        /**组装查询结果中重要的数据（二）**/
        return plistMap;
    }


    /**
     * Java读取MobileConfig配置描述文件
     * @return
     * @throws IOException
     */
    public static String readConfig(String path) throws IOException {
        String config=  ConfigUtils.getConfig("APNS_CONFIG");
        InputStream fis = new FileInputStream(path + config);        
        BufferedReader br = new BufferedReader(new InputStreamReader(fis));
        StringBuffer sb = new StringBuffer();
        String line;
        while ((line = br.readLine()) != null) {
            sb.append(line).append("\n");
        }
        return sb.toString();
    }


    /**
     * 获取返回数据Command的pList文件Map数据
     * @param pList
     * @return
     */
    public static Map<String, String> parseCommand(String pList){
        String strBlank = replaceBlank(pList);
        Map<String, String> plistMap = new HashMap<String, String>();
        /**获取key、string列表数据**/
        List<String> keyList = getList(KEY,strBlank);
        List<String> stringList = getList(STRING,strBlank);
        /**组装数据称plistMap**/
        for(int i=0;i<stringList.size();i++){
            plistMap.put(keyList.get(i), stringList.get(i));
        }
        return plistMap;
    }

    /**
     * 发送命令的pList格式的模板文件
     * @return
     */
    public static String getCommandPList(String command,String commandUUID){
        StringBuffer backString = new StringBuffer();
        backString.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        backString.append("<!DOCTYPE plist PUBLIC \"-//Apple Computer//DTD PLIST 1.0//EN\"");
        backString.append("\"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">");
        backString.append("<plist version=\"1.0\">");
        backString.append("<dict>");
        backString.append("<key>Command</key>");
        backString.append("<dict>");
        backString.append("<key>RequestType</key>");
        backString.append("<string>");
        backString.append(command);  //ManagedApplicationList
        backString.append("</string>");
        backString.append("</dict>");
        backString.append("<key>CommandUUID</key>");
        backString.append("<string>");
        backString.append(commandUUID);
        backString.append("</string>");
        backString.append("</dict>");
        backString.append("</plist>");
        return backString.toString();
    }
    /**
     * 安装配置文件文件
     * @return
     */
    public static String getInstalProfile(String command,String file,String commandUUID){
        StringBuffer backString = new StringBuffer();
        backString.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        backString.append("<!DOCTYPE plist PUBLIC \"-//Apple Computer//DTD PLIST 1.0//EN\"");
        backString.append("\"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">");
        backString.append("<plist version=\"1.0\">");
        backString.append("<dict>");
        backString.append("<key>Command</key>");
        backString.append("<dict>");
        backString.append("<key>RequestType</key>");
        backString.append("<string>");
        backString.append(command);  //ManagedApplicationList
        backString.append("</string>");
        backString.append("<key>Payload</key>");
        backString.append("<data>");
        backString.append(Base64.encode(file.getBytes()));
        backString.append("</data>");
        backString.append("</dict>");
        backString.append("<key>CommandUUID</key>");
        backString.append("<string>");
        backString.append(commandUUID);
        backString.append("</string>");
        backString.append("</dict>");
        backString.append("</plist>");
        return backString.toString();
    }
  
    /**
     * 删除配置文件的模板
     * @return
     */
    public static String getRemoveProfile(String command,String commandUUID){
        StringBuffer backString = new StringBuffer();
        backString.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        backString.append("<!DOCTYPE plist PUBLIC \"-//Apple Computer//DTD PLIST 1.0//EN\"");
        backString.append("\"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">");
        backString.append("<plist version=\"1.0\">");
        backString.append("<dict>");
        backString.append("<key>Command</key>");
        backString.append("<dict>");
        backString.append("<key>RequestType</key>");
        backString.append("<string>");
        backString.append(command);  //ManagedApplicationList
        backString.append("</string>");
        backString.append("<string>");
        backString.append("cn.kidmate.lock");  //ManagedApplicationList
        backString.append("</string>");
        backString.append("</dict>");
        backString.append("<key>CommandUUID</key>");
        backString.append("<string>");
        backString.append(commandUUID);
        backString.append("</string>");
        backString.append("</dict>");
        backString.append("</plist>");
        return backString.toString();
    }
  
    /**
     * 发送清除设备密码命令的pList格式的模板文件
     * @return
     */
    public static String getClearPassCodePList(String command,String commandUUID,KmEquipment mdm){
        StringBuffer backString = new StringBuffer();
        backString.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        backString.append("<!DOCTYPE plist PUBLIC \"-//Apple Computer//DTD PLIST 1.0//EN\" \n");
        backString.append("\"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n");
        backString.append("<plist version=\"1.0\">\n");
        backString.append("<dict>\n");
        backString.append("<key>Command</key>\n" );
        backString.append("<dict>\n");
        backString.append("<key>RequestType</key>\n");
        backString.append("<string>"+command+"</string>\n");
        backString.append("<key>UnlockToken</key>\n");
        backString.append("<data>"+mdm.getUnlockToken()+"</data>\n");
        backString.append("</dict>\n");
        backString.append("<key>CommandUUID</key>\n");
        backString.append("<string>"+commandUUID+"</string>\n");
        backString.append("</dict>\n");
        backString.append("</plist>");
        return backString.toString();
    }
   
    /**
     * 发送命令的pList格式的模板文件（获取设备信息）
     * @return
     */
    public static String getCommandInfoPList(String command,String commandUUID){
        StringBuffer backString = new StringBuffer();
        backString.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        backString.append("<!DOCTYPE plist PUBLIC \"-//Apple Computer//DTD PLIST 1.0//EN\"");
        backString.append("\"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">");
        backString.append("<plist version=\"1.0\">");
        backString.append("<dict>");
        backString.append("<key>Command</key>");
        backString.append("<dict>");
        backString.append("<key>RequestType</key>");
        backString.append("<string>");
        backString.append(command);
        backString.append("</string>");
        backString.append("<key>Queries</key>");
        backString.append("<array>");
        backString.append("<string>IMEI</string>");
        backString.append("<string>PhoneNumber</string>");
        backString.append("<string>DeviceName</string>");
        backString.append("<string>ModelName</string>");
        backString.append("<string>Model</string>");
        backString.append("<string>BatteryLevel</string>");
        backString.append("<string>DeviceCapacity</string>");
        backString.append("<string>AvailableDeviceCapacity</string>");
        backString.append("<string>OSVersion</string>");
        backString.append("<string>ICCID</string>");
        backString.append("<string>CurrentMCC</string>");
        backString.append("<string>CarrierSettingsVersion</string>");
        backString.append("<string>BluetoothMAC</string>");
        backString.append("<string>isRoaming</string>");
        backString.append("<string>DataRoamingEnabled</string>");
        backString.append("</array>");
        backString.append("</dict>");
        backString.append("<key>CommandUUID</key>");
        backString.append("<string>");
        backString.append(commandUUID);
        backString.append("</string>");
        backString.append("</dict></plist>");
        return backString.toString();
    }

    /**
     * 空的pList格式的文件（用户checkIn认证时候的返回）
     * @return
     */
    public static String getBlankPList(){
        StringBuffer backString = new StringBuffer();
        backString.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        backString.append("<!DOCTYPE plist PUBLIC \"-//Apple Computer//DTD PLIST 1.0//EN\"");
        backString.append("\"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">");
        backString.append("<plist version=\"1.0\">");
        backString.append("<dict>");
        backString.append("</dict>");
        backString.append("</plist>");
        return backString.toString();
    }


    /**
     * 获取Authenticate的pList文件Map数据
     * @param pList
     * @return
     */
    public static Map<String, String> parseAuthenticate(String pList){
        String strBlank = replaceBlank(pList);
        Map<String, String> plistMap = new HashMap<String, String>();
        /**获取key、string列表数据**/
        List<String> keyList = getList(KEY,strBlank);
        List<String> stringList = getList(STRING,strBlank);
        /**组装数据称plistMap**/
        for(int i=0;i<stringList.size();i++){
            plistMap.put(keyList.get(i), stringList.get(i));
        }
        return plistMap;
    }


    /**
     * 获取TokenUpdate的pList文件Map数据
     * @param pList
     * @return
     */
    public static Map<String, String> parseTokenUpdate(String pList){
        String strBlank  = replaceBlank(pList);
        Map<String, String> plistMap = new HashMap<String, String>();
        /**获取key、string、data列表数据**/
        List<String> keyList = getList(KEY,strBlank);
        List<String> stringList = getList(STRING,strBlank);
        List<String> dataList = getList(DATA,strBlank);
        /**组装数据称plistMap**/
        int stringNum = 0;
        for(int i=0;i<keyList.size();i++){
            if(keyList.get(i).equals(Token)){
                plistMap.put(Token, dataList.get(0));
            }else if(keyList.get(i).equals(UnlockToken)){
                plistMap.put(UnlockToken, dataList.get(1));
            }else if(keyList.get(i).equals("AwaitingConfiguration")){
                    plistMap.put("AwaitingConfiguration", "false");
            }else{
                plistMap.put(keyList.get(i), stringList.get(stringNum));stringNum++;
            }
        }
        return plistMap;
    }

    /**
     * 获取字符串列表数据
     * @param pattern
     * @param pList
     * @return
     */
    public static List<String> getList(String pattern,String pList){
        /**获取data列表数据**/
        List<String> dataList = new ArrayList<String>();
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(pList);
        while(m.find()) {
            dataList.add(m.group(1));
        }
        return dataList;
    }


    /**
     * java去除字符串中的空格、回车、换行符、制表符
     * @param str
     * @return
     */
    public static String replaceBlank(String str) {
        String strBlank = "";
        if (str!=null) {
            Pattern p = Pattern.compile("\\s*|\t|\r|\n");
            Matcher m = p.matcher(str);
            strBlank = m.replaceAll("");
        }
        return strBlank;
    }
    
    /**
     * 创建MobileConfig配置文件
     * @param filePath
     * @param content
     * @return
     * @throws Exception
     */
    public static boolean createMobileConfigFile(String filePath,String content)throws Exception {
        boolean createSuccess = false;
        File filename = new File(filePath);
        RandomAccessFile mm = null;
        try {
            mm = new RandomAccessFile(filename,"rw");
            mm.write(content.getBytes("UTF-8"));
            mm.close();
            createSuccess = true;
        } catch (IOException e1) {
            System.out.println("出错了："+e1.getMessage());
        }
        return createSuccess;
    }
    
    /**
     * 将inputStream转化成为String
     * @param is
     * @return
     * @throws IOException
     */
    public static String inputStream2String(InputStream is) throws IOException{ 
    	ByteArrayOutputStream baos = new ByteArrayOutputStream(); 
    	int i = -1; 
    	while((i=is.read())!=-1){ 
    	    baos.write(i); 
    	} 
    	return baos.toString(); 
    } 

    //根据连接地址，http打开连接获得图片的路径
    
    public  static String getImgUrl(String strUrl) throws Exception{

		URL getUrl = new URL(strUrl);
		HttpURLConnection connection = (HttpURLConnection) getUrl
				.openConnection();
		connection.connect();
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				connection.getInputStream()));
		String lines = null;
		StringBuffer s = new StringBuffer();
		while ((lines = reader.readLine()) != null) {
			s.append(lines);
		}
		reader.close();
		connection.disconnect();// 断开连接
		JSONObject json = JSONObject.fromObject(s.toString());
		String imgUrl="https://itunes.apple.com/lookup?bundleId=com.yum.kfc.brand";
		if (json.containsKey("resultCount")) {
			if (json.getString("resultCount").equals("0")) {
				return  null;
			} else if (json.getString("resultCount").equals("1")) {
				int st = s.toString().indexOf("Url100") + 9;
				String surl = s.toString().substring(st, s.toString().length() - 1);
				int ee = surl.indexOf(",") - 1;
				return surl.substring(0, ee);
			}
			
		}
		return null;
		
    }
    /** 
     * 根据地址获得数据的字节流 
     * @param strUrl 网络连接地址 
     * @return 
     */  
    public static ByteBuffer getImageFromNetByUrl(String strUrl){  
        try {  
            URL url = new URL(strUrl);  
            HttpURLConnection conn = (HttpURLConnection)url.openConnection();  
           InputStream inStream = conn.getInputStream();//通过输入流获取图片数据  
           ByteBuffer btImg = readInputStream(inStream);//得到图片的二进制数据  
            return btImg;  
        } catch (Exception e) {  
           return null;
        }  
       
    }  
    public static ByteBuffer readInputStream(InputStream inStream) throws Exception{  
        ByteArrayOutputStream outStream = new ByteArrayOutputStream();  
        byte[] buffer = new byte[1024];  
        int len = 0;  
        while( (len=inStream.read(buffer)) != -1 ){  
            outStream.write(buffer, 0, len);  
        }  
        inStream.close(); 
        return  ByteBuffer.wrap(outStream.toByteArray());
          
    }  
    public static void main(String args[]) throws Exception{
    	String src="https://itunes.apple.com/lookup?bundleId=com.yum.kfc.brand";
    	String s=MdmUtils.getImgUrl(src);
    	ByteBuffer bb=MdmUtils.getImageFromNetByUrl(MdmUtils.getImgUrl(src));
    	
    	System.out.print(bb);
    }
    
}
