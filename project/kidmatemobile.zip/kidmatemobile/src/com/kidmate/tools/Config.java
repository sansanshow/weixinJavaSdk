package com.kidmate.tools;

public class Config {
	private String parentAppkey;
	private String parentAppSec;
	private String childAppKey;
	private String childAppSec;
	private String taoBaoServerUrl;
	
	private String imagePath;
	private String imageUrl;
	
	private String parentAudit;
	private String parentCode;
	private String parentVersion;
	private boolean develop;
	
	private int timedur;
	
	public String getParentAppkey() {
		return parentAppkey;
	}
	public void setParentAppkey(String parentAppkey) {
		this.parentAppkey = parentAppkey;
	}
	public String getParentAppSec() {
		return parentAppSec;
	}
	public void setParentAppSec(String parentAppSec) {
		this.parentAppSec = parentAppSec;
	}
	public String getChildAppKey() {
		return childAppKey;
	}
	public void setChildAppKey(String childAppKey) {
		this.childAppKey = childAppKey;
	}
	public String getChildAppSec() {
		return childAppSec;
	}
	public void setChildAppSec(String childAppSec) {
		this.childAppSec = childAppSec;
	}
	public String getTaoBaoServerUrl() {
		return taoBaoServerUrl;
	}
	public void setTaoBaoServerUrl(String taoBaoServerUrl) {
		this.taoBaoServerUrl = taoBaoServerUrl;
	}
	public int getTimedur() {
		return timedur;
	}
	public void setTimedur(int timedur) {
		this.timedur = timedur;
	}
	public String getImagePath() {
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public String getParentAudit() {
		return parentAudit;
	}
	public void setParentAudit(String parentAudit) {
		this.parentAudit = parentAudit;
	}
	public String getParentCode() {
		return parentCode;
	}
	public void setParentCode(String parentCode) {
		this.parentCode = parentCode;
	}
	public String getParentVersion() {
		return parentVersion;
	}
	public void setParentVersion(String parentVersion) {
		this.parentVersion = parentVersion;
	}
	public boolean isDevelop() {
		return develop;
	}
	public void setDevelop(boolean develop) {
		this.develop = develop;
	}
	
}
