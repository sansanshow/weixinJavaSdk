package com.kidmate.tools;

import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.PooledObjectFactory;
import org.apache.commons.pool2.BasePooledObjectFactory;
import org.apache.commons.pool2.impl.DefaultPooledObject;
import org.apache.thrift.TException;
import org.apache.thrift.protocol.TCompactProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.transport.TFramedTransport;
import org.apache.thrift.transport.TSocket;
import org.apache.thrift.transport.TTransport;

import com.kidmate.kmservice.InternalService;
import com.kidmate.kmservice.InternalService.Client;
import com.kidmate.kmservice.InternalService.Iface;

public class InternalServiceClientFactory implements PooledObjectFactory<Iface> {
	private String ip;
	private int port;
	
	@Override
	public void activateObject(PooledObject<Iface> arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void destroyObject(PooledObject<Iface> arg0) throws Exception {
		// TODO Auto-generated method stub
		InternalService.Client client = (Client) arg0.getObject();
		client.getInputProtocol().getTransport().close();
	}

	@Override
	public PooledObject<Iface> makeObject() throws Exception {
		TTransport transport = new TFramedTransport(new TSocket(ip, port));
		transport.open();
		TProtocol protocol = new TCompactProtocol(transport);
		InternalService.Client client = new InternalService.Client(protocol);	
		return new DefaultPooledObject<Iface>(client);
	}

	@Override
	public void passivateObject(PooledObject<Iface> arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean validateObject(PooledObject<Iface> arg0) {
		// TODO Auto-generated method stub
		InternalService.Client client = (Client) arg0.getObject();
		try {
			return client.ping();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}
}
