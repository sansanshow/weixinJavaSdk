package com.kidmate.tools;

import java.util.List;

import org.apache.log4j.Logger;

import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

public class RedisUtil {
	private static Logger logger = Logger.getLogger(RedisUtil.class);
	private ShardedJedisPool shardedJedisPool;
	public <T> T getObject(ShardedJedis shardedJedis, String key) {
		Object object = null;
		if (shardedJedis==null) {
			shardedJedis = shardedJedisPool.getResource();
			if (shardedJedis.exists(key.getBytes())) {
				object = SerializeUtil.unserialize(shardedJedis.get(key.getBytes()));
				if (object == null) {
					logger.info("SerializeUtil.unserialize failed ,maybe key(" + key + ") has changed, remove it");
					del(shardedJedis, key);
				}
			}
			shardedJedisPool.returnResource(shardedJedis);
		}
		else {
			if (shardedJedis.exists(key.getBytes())) {
				object = SerializeUtil.unserialize(shardedJedis.get(key
						.getBytes()));
				if (object == null) {
					logger.info("SerializeUtil.unserialize failed ,maybe key(" + key + ") has changed, remove it");
					del(shardedJedis, key);
				}
			}
		}
		if (object!=null)
			return (T)object;
		return null;
	}

	public void setObject(ShardedJedis shardedJedis, String key, Object value) {
		if (shardedJedis==null) {
			shardedJedis = shardedJedisPool.getResource();
			shardedJedis.set(key.getBytes(), SerializeUtil.serialize(value));
		} else {
			shardedJedis.set(key.getBytes(), SerializeUtil.serialize(value));
		}
	}
	
	public void del(ShardedJedis shardedJedis, String key) {
		if (shardedJedis==null) {
			shardedJedis = shardedJedisPool.getResource();
			shardedJedis.del(key);
		} else {
			shardedJedis.del(key);
		}
	}
	
	public <T> T hgetObject(ShardedJedis shardedJedis, String key, String field) {
		Object object = null;
		if (shardedJedis==null) {
			shardedJedis = shardedJedisPool.getResource();
			if (shardedJedis.exists(key.getBytes()) && shardedJedis.hexists(key.getBytes(), field.getBytes())) {
				object = SerializeUtil.unserialize(shardedJedis.hget(key.getBytes(), field.getBytes()));
				if (object == null) {
					logger.info("SerializeUtil.unserialize failed ,maybe key(" + key + ") has changed, remove it");
					del(shardedJedis, key);
				}
			}
			shardedJedisPool.returnResource(shardedJedis);
		}
		else {
			if (shardedJedis.exists(key.getBytes()) && shardedJedis.hexists(key.getBytes(), field.getBytes())) {
				object = SerializeUtil.unserialize(shardedJedis.hget(key.getBytes(), field.getBytes()));
				if (object == null) {
					logger.info("SerializeUtil.unserialize failed ,maybe key(" + key + ") has changed, remove it");
					del(shardedJedis, key);
				}
			}
		}
		if (object!=null)
			return (T)object;
		return null;
	}

	public void hsetObject(ShardedJedis shardedJedis, String key, String field, Object value) {
		if (shardedJedis==null) {
			shardedJedis = shardedJedisPool.getResource();
			shardedJedis.hset(key.getBytes(), field.getBytes(), SerializeUtil.serialize(value));
		} else {
			shardedJedis.hset(key.getBytes(), field.getBytes(), SerializeUtil.serialize(value));
		}
		shardedJedisPool.returnResource(shardedJedis);
	}
	
	
	public void hsetListObject(ShardedJedis shardedJedis, String key, String field, List<Object> value) {
		if (shardedJedis==null) {
			shardedJedis = shardedJedisPool.getResource();
			shardedJedis.hset(key.getBytes(), field.getBytes(), SerializeUtil.serializeList(value));
		} else {
			shardedJedis.hset(key.getBytes(), field.getBytes(), SerializeUtil.serializeList(value));
		}
		shardedJedisPool.returnResource(shardedJedis);
	}
	public void hdel(String key, String field, ShardedJedis shardedJedis) {
		if (shardedJedis == null) {
			shardedJedis = shardedJedisPool.getResource();
			shardedJedis.hdel(key, field);
			shardedJedisPool.returnResource(shardedJedis);
		} else {
			shardedJedis.hdel(key, field);
		}
	}
	
	public ShardedJedisPool getShardedJedisPool() {
		return shardedJedisPool;
	}

	public void setShardedJedisPool(ShardedJedisPool shardedJedisPool) {
		this.shardedJedisPool = shardedJedisPool;
	}
}
