package com.kidmate.tools;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.imageio.stream.FileImageInputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class FileUtil {
	public static Log logger = LogFactory.getLog(FileUtil.class);
	
	/**
	 * 上传文件
	 * @param bytebuffer
	 * @param path
	 * @return
	 */
	public static String saveFile(ByteBuffer bytebuffer, String path)
	{
		logger.info("FileUtil saveFile path:"+path);
		try {
			String name = SecurityUtils.md5ByHex("" +System.currentTimeMillis() + Math.random())+".jpg";
			FileOutputStream fos = new FileOutputStream(path + "/" + name );
			FileChannel outChannel = fos.getChannel();
			logger.info("FileUtil saveFile write!");
			outChannel.write(bytebuffer);
			outChannel.close();
			fos.close();
			logger.info("FileUtil saveFile close!");
			return name;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			logger.error(e,e);
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			logger.error(e,e);
			return null;
		}
	}
	
	public static String saveFile(byte[] bytebuffer, String path)
	{
		logger.info("FileUtil saveFile path:"+path);
		try {
			String name = SecurityUtils.md5ByHex("" +System.currentTimeMillis() + Math.random())+".jpg";
			FileOutputStream fos = new FileOutputStream(path + "/" + name );
			fos.write(bytebuffer);
			fos.close();
			logger.info("FileUtil saveFile close!");
			return name;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			logger.error(e,e);
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			logger.error(e,e);
			return null;
		}
	}

	public static String readString3(String filePath)

	{
		String str = "";
		File file = new File(filePath);
		try {
			FileInputStream in = new FileInputStream(file);
			// size 为字串的长度 ，这里一次性读完
			int size = in.available();
			byte[] buffer = new byte[size];
			in.read(buffer);
			in.close();
			str = new String(buffer, "utf-8");
		} catch (IOException e) {
			// TODO Auto-generated catch block
		e.printStackTrace();
		}
		return str;
	}
}
