package com.kidmate.tools;

import java.util.List;

import org.apache.thrift.TException;

import com.kidmate.kmservice.TKmAppInfo;
import com.kidmate.kmservice.TKmAppInfoUpload;
import com.kidmate.service.IAppInfoService;

public class AppleMetaThread extends Thread {

	private String info;
	private IAppInfoService appInfoService;
	private String deviceId;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public AppleMetaThread(String info,IAppInfoService appInfoService,String deviceId) {
		this.info = info;
		this.appInfoService=appInfoService;
		this.deviceId=deviceId;
	}
	
    public void run() {  
    	 List<TKmAppInfoUpload> iosApp=MdmUtils.getIosApp(info);
         /**保存处理后的APP列表数据 start**/
        try {
			this.appInfoService.addNewAppInfo((long)Integer.parseInt(deviceId), iosApp);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
   }  
}
