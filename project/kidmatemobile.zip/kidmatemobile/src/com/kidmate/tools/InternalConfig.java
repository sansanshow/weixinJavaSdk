package com.kidmate.tools;

public class InternalConfig {
	private int port;
	private int selectorThreadCount;
	private int workerThreadCount;
	
	private int parentMessageThreadCount;
	private int childMessageThreadCount;
	
	
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	public int getSelectorThreadCount() {
		return selectorThreadCount;
	}
	public void setSelectorThreadCount(int selectorThreadCount) {
		this.selectorThreadCount = selectorThreadCount;
	}
	public int getWorkerThreadCount() {
		return workerThreadCount;
	}
	public void setWorkerThreadCount(int workerThreadCount) {
		this.workerThreadCount = workerThreadCount;
	}
	public int getParentMessageThreadCount() {
		return parentMessageThreadCount;
	}
	public void setParentMessageThreadCount(int parentMessageThreadCount) {
		this.parentMessageThreadCount = parentMessageThreadCount;
	}
	public int getChildMessageThreadCount() {
		return childMessageThreadCount;
	}
	public void setChildMessageThreadCount(int childMessageThreadCount) {
		this.childMessageThreadCount = childMessageThreadCount;
	}
	

}
