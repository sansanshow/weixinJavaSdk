package com.kidmate.tools;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class SerializeUtil {
	public static Log logger = LogFactory.getLog(SerializeUtil.class);
	public static byte[] serialize(Object object) 
	{
		ObjectOutputStream oos = null;
		ByteArrayOutputStream baos = null;
		try {
			//序列化
			baos = new ByteArrayOutputStream();
			oos = new ObjectOutputStream(baos);
			oos.writeObject(object);
			byte[] bytes = baos.toByteArray();
			return bytes;
		} 
		catch (Exception e) {
			logger.error(e,e);
		}
		return null;
	}
	 
	public  static <T> T unserialize(byte[] bytes) {
		ByteArrayInputStream bais = null;
		try {
			//反序列化
			if(bytes == null || bytes.length == 0)
			{
				return null;
			}
			bais = new ByteArrayInputStream(bytes);
			ObjectInputStream ois = new ObjectInputStream(bais);
			Object o = ois.readObject();
			if (o!=null) {
				return (T)o;
			} 
		} 
		catch (Exception e) {
			logger.error(e,e);
		}
		return null;
	}
	
	public static byte[] serializeList(List<?> object) 
	{
		ObjectOutputStream oos = null;
		ByteArrayOutputStream baos = null;
		try {
			//序列化
			baos = new ByteArrayOutputStream();
			oos = new ObjectOutputStream(baos);
			 for(Object o : object){
				 oos.writeObject(o);
             }
			 oos.writeObject(null);
           
            oos.close();
            baos.close();
            byte[] bytes = baos.toByteArray();
			return bytes;
		} 
		catch (Exception e) {
			logger.error(e,e);
		}
		return null;
	}
	
	public static <T> List<T> unserializeList(byte[] bytes) {
		ByteArrayInputStream bais = null;
		List<Object> list = new ArrayList<Object>();
        try {
			// 反序列化
			if (bytes == null || bytes.length == 0) {
				return null;
			}
			bais = new ByteArrayInputStream(bytes);
			ObjectInputStream ois = new ObjectInputStream(bais);
			while (true) {
				Object object = ois.readObject();
				if (object == null) {
					break;
				} else {
					list.add(object);
				}
			}

			bais.close();
			ois.close();
		} catch (Exception e) {
			logger.error(e, e);
		}
		return (List<T>) list;
	}
}
