package com.kidmate.tools;

public class Constants {
	public static final int OP_SUC = 200;

	public static final String LATEST_APP_USAGE = "kmlatestappusage";
	public static final String LATEST_NOTSYSAPP_USAGE = "kmlatestnotsysappusage";
	public static final String EQ2CID = "kmequipmenttochild";
	public static final String AVGDAYTIME = "kmavgdaytime";
	public static final String CHILDDAYTIME = "kmchilddaytime";
	public static final String PARENTSIGN = "kmparentsign";
	public static final String EQUIPMENTSIGN = "kmeqsign";
	public static final String PARENTACCOUNT = "kmeqaccount";
	public static final String APP_USEAGE = "kmappusage";
	public static final String APPLE_META = "kmappleMeta";
	public static final String APP_INFOMATION = "kmappinfomation";
	public static final String UNIONID="kmunionid";
	public static final String SNAPSHOTID="kmsnapshotid";
	public static final String CONTROLRULE="kmcontrolrule";
	public static final String CREDIT="kmcredit";
	
}
