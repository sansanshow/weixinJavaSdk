package com.kidmate.wx.main;

import org.apache.thrift.TException;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.transport.THttpClient;
import org.apache.thrift.transport.TTransportException;

import com.kidmate.kmservice.ParentService;
import com.kidmate.kmservice.TKmException;
import com.kidmate.kmservice.TKmUser;
import com.kidmate.wx.pojo.AccessToken;
import com.kidmate.wx.utils.MD5Utils;
import com.kidmate.wx.utils.PropertyManager;
import com.kidmate.wx.utils.WeixinUtil;

public class Appclient {
	public static String FROM_URL = "http://192.168.0.232:9000/kidmatemobile/parent.do";
	public static void main(String[] args) {
//		AccessToken ac = WeixinUtil.getAccessToken("wxd63248a75b932894", "0d1cebc086ff5ca5a60f8dc4d2fea35a");
//		System.out.println(ac);
//		ParentService.Client client;
//		THttpClient thc;
//		try {
//			thc = new THttpClient(FROM_URL);
//			thc.setConnectTimeout(15000);
//			thc.setReadTimeout(30000);
//			TProtocol loPFactory = new TBinaryProtocol(thc);
//			client = new ParentService.Client(loPFactory);
//			TKmUser user=new TKmUser();
//			user.setUserid(2019);
//			user.setTimestamp(System.currentTimeMillis());
//			user.setSign("09B04D4396CD1A6D3427CC1771E86F39");
//			System.out.println(client.getAllEquipment(user));
//		} catch (TTransportException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (TKmException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (TException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		System.out.println(MD5Utils.md5ByHex(MD5Utils.md5ByHex("A3295B5B5B2AB77B36FC5C5E3F975B45")+"A3295B5B5B2AB77B36FC5C5E3F975B45"+(1467855127813L<<5)));
//		System.out.println(MD5Utils.md5ByHex("178B4C48E7669AF4B02F38BDCC6E102EA3295B5B5B2AB77B36FC5C5E3F975B4546971379110208"));
//		System.out.println("Q:如何解绑\n\nA:iOS版家长端：设置——孩子的手机，右滑孩子手机列表即可解绑\n安卓版家长端：设置——孩子的手机，点击孩子手机列表进入后按删除键。");
//		System.out.println("appid:"+PropertyManager.getProperty("appid"));
		System.out.println(MD5Utils.md5ByHex("gQGJ7zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL3dqX2dGa1BsOVJfTWY4UEVUeGR1AAIEfgQHWAMEAAAAAA="));
		System.out.println("qrscene_123456789".replace("qrscene_", ""));
		System.out.println("qrscene_123456789".startsWith("qrscene_"));
	}
}
