package com.kidmate.wx.main;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kidmate.wx.pojo.AccessToken;
import com.kidmate.wx.pojo.Button;
import com.kidmate.wx.pojo.CommonButton;
import com.kidmate.wx.pojo.ComplexButton;
import com.kidmate.wx.pojo.ViewButton;
import com.kidmate.wx.pojo.WxMenu;
import com.kidmate.wx.utils.PropertyManager;
import com.kidmate.wx.utils.WeixinUtil;

/**
 * 菜单管理器类
 * 
 * @author liufeng
 * @date 2013-08-08
 */
public class MenuManager0826 {
	private static Logger log = LoggerFactory.getLogger(MenuManager0826.class);

	public static void main(String[] args) {
		// 第三方用户唯一凭证
		String appId = PropertyManager.getProperty("appid");
		// 第三方用户唯一凭证密钥
		String appSecret = PropertyManager.getProperty("appsecret");

		// 调用接口获取access_token
		AccessToken at = WeixinUtil.getAccessToken(appId, appSecret);

		if (null != at) {
			// 调用接口创建菜单
			int result = WeixinUtil.createMenu(getMenu(), at.getToken());

			// 判断菜单创建结果
			if (0 == result)
				log.info("菜单创建成功！");
			else
				log.info("菜单创建失败，错误码：" + result);
		}
	}

	/**
	 * 组装菜单数据
	 * 
	 * @return
	 */
	private static WxMenu getMenu() {

/****************************正式服务菜单***************************************************************/
		ViewButton btn21 = new ViewButton();
		btn21.setName("家长端");
		btn21.setType("view");
		btn21.setUrl(PropertyManager.getProperty("parent_download_url"));
		
		CommonButton btn22 = new CommonButton();
		btn22.setName("儿童端");
		btn22.setType("click");
		btn22.setKey("1022");

		ViewButton btn30 = new ViewButton();
		btn30.setName("关于苗苗");
		btn30.setType("view");
		btn30.setUrl("http://www.kidmate.cn/about.html");
		
		ViewButton btn31 = new ViewButton();
		btn31.setName("服务与帮助");
		btn31.setType("view");
		btn31.setUrl("http://www.kidmate.cn/help.html");
		
//		ViewButton btn33 = new ViewButton();
//		btn33.setName("kmwxweb");
//		btn33.setType("view");
//		btn33.setUrl("https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx365c10c5232278d3&redirect_uri=http%3A%2F%2Ft.kidmate.cn%2Fkmwxweb%2Findex.html&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect");


		ViewButton mainBtn1 = new ViewButton();
		mainBtn1.setName("苗苗管家");
		mainBtn1.setType("view");
//		mainBtn1.setUrl("https://open.weixin.qq.com/connect/oauth2/authorize?appid="+PropertyManager.getProperty("appid")+"&redirect_uri=https%3A%2F%2Fi.kidmate.cn%2Fkmwxweb%2Fpage%2Fjudge.html&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect");
		//外部本地测试服务
		mainBtn1.setUrl("https://open.weixin.qq.com/connect/oauth2/authorize?appid="+PropertyManager.getProperty("appid")+"&redirect_uri=http%3A%2F%2Fms.wenchaoxu.tk%2Fkmwxweb%2Findex.html&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect");
		//外部，外部服务
//		mainBtn1.setUrl("https://open.weixin.qq.com/connect/oauth2/authorize?appid="+PropertyManager.getProperty("appid")+"&redirect_uri=https%3A%2F%2Fi.kidmate.cn%2Fkmwxweb%2Findex.html&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect");
		

		ComplexButton mainBtn2 = new ComplexButton();
		mainBtn2.setName("下载APP");
		mainBtn2.setSub_button(new Button[] { btn22, btn21});

		ComplexButton mainBtn3 = new ComplexButton();
		mainBtn3.setName("更多");
		mainBtn3.setSub_button(new Button[] { btn30, btn31 });
		/**
		 * 这是公众号xiaoqrobot目前的菜单结构，每个一级菜单都有二级菜单项<br>
		 * 
		 * 在某个一级菜单下没有二级菜单的情况，menu该如何定义呢？<br>
		 * 比如，第三个一级菜单项不是“更多体验”，而直接是“幽默笑话”，那么menu应该这样定义：<br>
		 * menu.setButton(new Button[] { mainBtn1, mainBtn2, btn33 });
		 */
		WxMenu menu = new WxMenu();
		menu.setButton(new Button[] { mainBtn1, mainBtn2, mainBtn3 });

		return menu;
	}
}