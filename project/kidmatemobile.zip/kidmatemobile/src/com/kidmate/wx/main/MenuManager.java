package com.kidmate.wx.main;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kidmate.wx.pojo.AccessToken;
import com.kidmate.wx.pojo.Button;
import com.kidmate.wx.pojo.CommonButton;
import com.kidmate.wx.pojo.ComplexButton;
import com.kidmate.wx.pojo.ViewButton;
import com.kidmate.wx.pojo.WxMenu;
import com.kidmate.wx.utils.PropertyManager;
import com.kidmate.wx.utils.WeixinUtil;

/**
 * 菜单管理器类
 * 
 */
public class MenuManager {
	private static Logger log = LoggerFactory.getLogger(MenuManager.class);

//	public static void main(String[] args) {
//		// 第三方用户唯一凭证
//		String appId = PropertyManager.getProperty("appid");
//		// 第三方用户唯一凭证密钥
//		String appSecret = PropertyManager.getProperty("appsecret");
//
//		// 调用接口获取access_token
//		AccessToken at = WeixinUtil.getAccessToken(appId, appSecret);
//
//		if (null != at) {
//			// 调用接口创建菜单
//			int result = WeixinUtil.createMenu(getMenu(), at.getToken());
//
//			// 判断菜单创建结果
//			if (0 == result)
//				log.info("菜单创建成功！");
//			else
//				log.info("菜单创建失败，错误码：" + result);
//		}
//	}

	public static void main(String[] args) {
		// 第三方用户唯一凭证
		String appId = "wx63bbf298061ea9a3";
		// 第三方用户唯一凭证密钥
		String appSecret = "3895dc80569a5bd6715dee5cb7884679";

		// 调用接口获取access_token
		AccessToken at = WeixinUtil.getAccessToken(appId, appSecret);

		if (null != at) {
			// 调用接口创建菜单
			int result = WeixinUtil.createMenu(createMenuYyl(), at.getToken());

			// 判断菜单创建结果
			if (0 == result)
				log.info("菜单创建成功！");
			else
				log.info("菜单创建失败，错误码：" + result);
		}
	}
	
	/**
	 * 组装菜单数据
	 * 
	 * @return
	 */
	private static WxMenu getMenu() {
//		ViewButton btn21 = new ViewButton();
//		btn21.setName("家长端");
//		btn21.setType("view");
//		btn21.setUrl("https://itunes.apple.com/us/app/miao-miao-er-tong-shou-ji/id1107815819");
//
//		ViewButton btn22 = new ViewButton();
//		btn22.setName("家长端-安卓");
//		btn22.setType("view");
//		btn22.setUrl("http://img.baobeizn.com/kidmate/parent/kidmate_parent.apk");
//
//		CommonButton btn23 = new CommonButton();
//		btn23.setName("儿童端-IOS");
//		btn23.setType("click");
//		btn23.setKey("2003");
//
//		ViewButton btn24 = new ViewButton();
//		btn24.setName("儿童端-安卓");
//		btn24.setType("view");
//		btn24.setUrl("http://img.baobeizn.com/kidmate/parent/kidmate_parent.apk");
//
//		ViewButton btn30 = new ViewButton();
//		btn30.setName("关于苗苗0");
//		btn30.setType("view");
//		btn30.setUrl("http://kidmate.cn/help.html");
//		
//		CommonButton btn31 = new CommonButton();
//		btn31.setName("关于苗苗1");
//		btn31.setType("click");
//		btn31.setKey("3001");
//
//		ViewButton btn32 = new ViewButton();
//		btn32.setName("帮助");
//		btn32.setType("view");
//		btn32.setUrl("https://open.weixin.qq.com/connect/oauth2/authorize?appid=+PropertyManager.getProperty("appid")+&redirect_uri=http%3A%2F%2Ft.kidmate.cn%2Fkidmatemobile%2Fweixin%2Fuser%2Flogin.wx&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect");
//
//		ViewButton mainBtn1 = new ViewButton();
//		mainBtn1.setName("苗苗管家");
//		mainBtn1.setType("view");
//		mainBtn1.setUrl("https://open.weixin.qq.com/connect/oauth2/authorize?appid=+PropertyManager.getProperty("appid")+&redirect_uri=http%3A%2F%2Ft.kidmate.cn%2Fkmwxweb%2Fpage%2Fjudge.html&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect");

//		ComplexButton mainBtn2 = new ComplexButton();
//		mainBtn2.setName("下载APP");
//		mainBtn2.setSub_button(new Button[] { btn21, btn22, btn23, btn24 });
//
//		ComplexButton mainBtn3 = new ComplexButton();
//		mainBtn3.setName("更多");
//		mainBtn3.setSub_button(new Button[] { btn30, btn31, btn32 });
/****************************正式服务菜单***************************************************************/
		ViewButton btn21 = new ViewButton();
		btn21.setName("家长端");
		btn21.setType("view");
		btn21.setUrl(PropertyManager.getProperty("parent_download_url"));
		
		CommonButton btn22 = new CommonButton();
		btn22.setName("儿童端");
		btn22.setType("click");
		btn22.setKey("1022");

		ViewButton btn30 = new ViewButton();
		btn30.setName("关于苗苗");
		btn30.setType("view");
		btn30.setUrl("http://www.kidmate.cn/about.html");
		
		ViewButton btn31 = new ViewButton();
		btn31.setName("服务与帮助");
		btn31.setType("view");
		btn31.setUrl("http://www.kidmate.cn/help.html");
		
//		ViewButton btn32 = new ViewButton();
//		btn32.setName("服务与帮助2");
//		btn32.setType("view");
//		btn32.setUrl("https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx365c10c5232278d3&redirect_uri=http%3A%2F%2Ft.kidmate.cn%2Fkmweb-vue%2Findex.html&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect");
//		
//		ViewButton btn33 = new ViewButton();
//		btn33.setName("kmwxweb");
//		btn33.setType("view");
//		btn33.setUrl("https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx365c10c5232278d3&redirect_uri=http%3A%2F%2Ft.kidmate.cn%2Fkmwxweb%2Findex.html&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect");


		ViewButton mainBtn1 = new ViewButton();
		mainBtn1.setName("苗苗管家");
		mainBtn1.setType("view");
		if(PropertyManager.getProperty("isDevelop")=="false"){
			mainBtn1.setUrl("https://open.weixin.qq.com/connect/oauth2/authorize?appid="+PropertyManager.getProperty("appid")+"&redirect_uri=https%3A%2F%2Fi.kidmate.cn%2Fkmwxweb%2Fpage%2Fjudge.html&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect");
		}else {
			mainBtn1.setUrl("https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx365c10c5232278d3&redirect_uri=http%3A%2F%2Ft.kidmate.cn%2Fkmwxweb%2Findex.html&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect");
		}
		

		ComplexButton mainBtn2 = new ComplexButton();
		mainBtn2.setName("下载APP");
		mainBtn2.setSub_button(new Button[] { btn22, btn21});

		ComplexButton mainBtn3 = new ComplexButton();
		mainBtn3.setName("更多");
		mainBtn3.setSub_button(new Button[] { btn30, btn31 });
		/**
		 * 这是公众号xiaoqrobot目前的菜单结构，每个一级菜单都有二级菜单项<br>
		 * 
		 * 在某个一级菜单下没有二级菜单的情况，menu该如何定义呢？<br>
		 * 比如，第三个一级菜单项不是“更多体验”，而直接是“幽默笑话”，那么menu应该这样定义：<br>
		 * menu.setButton(new Button[] { mainBtn1, mainBtn2, btn33 });
		 */
		WxMenu menu = new WxMenu();
		menu.setButton(new Button[] { mainBtn1, mainBtn2, mainBtn3 });

		return menu;
	}
	/**
	 * 组装菜单数据
	 * 红咖社
	 * @return
	 */
	private static WxMenu createMenuHks(){
	/****************************正式服务菜单***************************************************************/
			/*
			 * 菜单一
			 */
			CommonButton btn11 = new CommonButton();
			btn11.setName("活动一");
			btn11.setType("click");
			btn11.setKey("1011");
			
			CommonButton btn12 = new CommonButton();
			btn12.setName("活动二");
			btn12.setType("click");
			btn12.setKey("1012");
			
			ComplexButton mainBtn1 = new ComplexButton();
			mainBtn1.setName("今日通告");
			mainBtn1.setSub_button(new Button[] { btn11, btn12});
			/*
			 * 菜单二
			 */
			ViewButton btn21 = new ViewButton();
			btn21.setName("我的二维码");
			btn21.setType("view");
			btn21.setUrl("http://wx.51bi.com/yylweb/qrcode.htm");
			
			ViewButton btn22 = new ViewButton();
			btn22.setName("发红包");
			btn22.setType("view");
			btn22.setUrl("http://wx.51bi.com/yylweb/qrcode.htm");
			
			ComplexButton mainBtn2 = new ComplexButton();
			mainBtn2.setName("我要赚钱");
			mainBtn2.setSub_button(new Button[] { btn21, btn22});
			
			/*
			 * 菜单三
			 */
			ViewButton btn31 = new ViewButton();
			btn31.setName("个人信息");
			btn31.setType("view");
			btn31.setUrl("http://wx.51bi.com/yylweb/qrcode.htm");
			
			ViewButton btn32 = new ViewButton();
			btn32.setName("我的粉丝");
			btn32.setType("view");
			btn32.setUrl("http://wx.51bi.com/yylweb/qrcode.htm");
			
			ViewButton btn33 = new ViewButton();
			btn33.setName("查看收益");
			btn33.setType("view");
			btn33.setUrl("http://wx.51bi.com/yylweb/qrcode.htm");
			
			ViewButton btn34 = new ViewButton();
			btn34.setName("关于红咖社");
			btn34.setType("view");
			btn34.setUrl("http://wx.51bi.com/yylweb/qrcode.htm");
			
			ComplexButton mainBtn3 = new ComplexButton();
			mainBtn3.setName("个人中心");
			mainBtn3.setSub_button(new Button[] { btn31, btn32, btn33, btn34});
			/**
			 * 这是公众号xiaoqrobot目前的菜单结构，每个一级菜单都有二级菜单项<br>
			 * 
			 * 在某个一级菜单下没有二级菜单的情况，menu该如何定义呢？<br>
			 * 比如，第三个一级菜单项不是“更多体验”，而直接是“幽默笑话”，那么menu应该这样定义：<br>
			 * menu.setButton(new Button[] { mainBtn1, mainBtn2, btn33 });
			 */
			WxMenu menu = new WxMenu();
			menu.setButton(new Button[] { mainBtn1, mainBtn2, mainBtn3 });

			return menu;
	}
	/**
	 * 组装菜单数据
	 * 粉丝端
	 * @return
	 */
	private static WxMenu createMenuYyl(){
	/****************************正式服务菜单***************************************************************/
		/*
		 * 菜单一
		 */
		ViewButton btn11 = new ViewButton();
		btn11.setName("找朋友");
		btn11.setType("view");
		btn11.setUrl("http://www.baidu.com");
		
		ViewButton btn12 = new ViewButton();
		btn12.setName("抢红包");
		btn12.setType("view");
		btn12.setUrl("http://news.163.com");
		
		ViewButton btn13 = new ViewButton();
		btn13.setName("花余额");
		btn13.setType("view");
		btn13.setUrl("http://news.163.com/");
		
		
		ComplexButton mainBtn1 = new ComplexButton();
		mainBtn1.setName("个人中心");
		mainBtn1.setSub_button(new Button[] { btn11, btn12, btn13});
		/*
		 * 菜单二
		 */
		ViewButton mainBtn2 = new ViewButton();
		mainBtn2.setName("摇一摇");
		mainBtn2.setType("view");
		mainBtn2.setUrl("http://www.baidu.com");
	
		/*
		 * 菜单三
		 */
		ViewButton mainBtn3 = new ViewButton();
		mainBtn3.setName("个人中心");
		mainBtn3.setType("view");
		mainBtn3.setUrl("http://www.baidu.com");
		
			/**
			 * 这是公众号xiaoqrobot目前的菜单结构，每个一级菜单都有二级菜单项<br>
			 * 
			 * 在某个一级菜单下没有二级菜单的情况，menu该如何定义呢？<br>
			 * 比如，第三个一级菜单项不是“更多体验”，而直接是“幽默笑话”，那么menu应该这样定义：<br>
			 * menu.setButton(new Button[] { mainBtn1, mainBtn2, btn33 });
			 */
			WxMenu menu = new WxMenu();
			menu.setButton(new Button[] { mainBtn1, mainBtn2, mainBtn3 });

			return menu;
	}
}