package com.kidmate.wx.utils;

import com.kidmate.kmservice.TKmUser;
import com.kidmate.tools.SecurityUtils;

public class UserSignUtils {
//	private UserSignUtils(){
//		
//	}
//	private static UserSignUtils instance;
//	public static UserSignUtils 
	public static TKmUser getSignUser(long userId, String sign, String ver) {

		TKmUser user = new TKmUser();
		user.setUserid(userId);
		long timestamp = System.currentTimeMillis();
		// MD5Utils.md5ByHex4Sign(getLoginUserToken(),user.sign, timestamp)
		System.out.println("--sign--:" + sign);
		String token = SecurityUtils.md5ByHex(SecurityUtils.md5ByHex(sign)
				+ sign + (timestamp << 5));
		System.err.println("token:" + token);
		user.setSign(token);
		// String md5Str = md5ByHex(authToken) + sign + (timestamp << 5);
		// return md5ByHex(md5Str);
		user.setTimestamp(timestamp);
		user.setVer(ver);
		return user;
	}
}
