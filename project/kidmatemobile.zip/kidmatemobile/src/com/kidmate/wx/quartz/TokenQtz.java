package com.kidmate.wx.quartz;

import java.util.Date;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.kidmate.wx.pojo.AccessToken;
import com.kidmate.wx.pojo.JsapiTicket;
import com.kidmate.wx.service.IWxConfigService;
import com.kidmate.wx.utils.PropertyManager;
import com.kidmate.wx.utils.WeixinConfig;
import com.kidmate.wx.utils.WeixinUtil;

public class TokenQtz {
	private static int counter = 0;
	private static Logger log = LoggerFactory.getLogger(TokenQtz.class);
	// 第三方用户唯一凭证
//	public static String appid = "wx365c10c5232278d3";
//	// 第三方用户唯一凭证密钥
//	public static String appsecret = "eac1dd18813e6f8df303bae40692509b";

	@Autowired
	@Qualifier("WxConfigService")
	private IWxConfigService wxConfigService;

	public static AccessToken accessToken = null;
	public static JsapiTicket jsapi_ticket = null;
	@Autowired
	@Resource(name = "wxconfig")
	private WeixinConfig config;

	protected void execute() {
		long ms = System.currentTimeMillis();
		System.out.println("\t\t" + new Date(ms));
		System.out.println("(" + counter++ + ")");
		// 获取web.xml中配置的参数
		// appid = config.getAppid();
		// appsecret = config.getAppsecret();

		System.out.println(config);
		log.info("weixin api appid:" + config.getAppid());
		log.info("weixin api appsecret:" + config.getAppsecret());

		// 未配置appid、appsecret时给出提示
		// if ("".equals(appid) || "".equals(appsecret)) {
		// log.error("appid and appsecret configuration error, please check carefully.");
		// } else {
		// 定时获取access_token
		accessToken = wxConfigService.getAccessToken();
		jsapi_ticket = wxConfigService.getJSApiTicket();
		log.info("获取jsapi_ticket成功，有效时长" + jsapi_ticket.getExpiresIn() + "秒 jsapi_ticket:" + jsapi_ticket.getTicket());
		if (null != accessToken) {
			log.info("获取access_token成功，有效时长{" + accessToken.getExpiresIn() + "}秒 token:{" + accessToken.getToken() + "}");
		} else {
			// 如果access_token为null，60秒后再获取
			log.info("access_token为null");
		}
	}

	public WeixinConfig getConfig() {
		return config;
	}

	public void setConfig(WeixinConfig config) {
		this.config = config;
	}

}
