package com.kidmate.wx.model;

import java.nio.ByteBuffer;
import java.util.Date;

import com.kidmate.kmservice.TKmSnapshot;
import com.kidmate.wx.utils.MyUtils;

public class Snapshot {
	private long id;
	private String url;
	private double longitude;
	private double latitude;
	private String addr;
	// private long time;
	private String time;
	private int type;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public Snapshot() {
		// TODO Auto-generated constructor stub
		super();
	}
	public Snapshot(TKmSnapshot snapshot) {
		// TODO Auto-generated constructor stub
		super();
		this.id=snapshot.getId();
		this.url=snapshot.getUrl();
		this.longitude=snapshot.getLongitude();
		this.latitude=snapshot.getLatitude();
		this.addr=snapshot.getAddr();
		this.time=MyUtils.formatDate("yyyy-MM-dd HH:mm:ss", new Date(snapshot.getTime()));
		this.type=snapshot.getType();
	}
}
