package com.kidmate.wx.model;

import java.sql.Timestamp;

/**
 * BiYylActivity entity. @author MyEclipse Persistence Tools
 */

public class BiYylActivity implements java.io.Serializable {

	// Fields

	private Long id;
	private String content;
	private String type;
	private String status;
	private Timestamp createtime;
	private Timestamp starttime;
	private Timestamp endtime;

	// Constructors

	/** default constructor */
	public BiYylActivity() {
	}

	/** minimal constructor */
	public BiYylActivity(Long id, String content) {
		this.id = id;
		this.content = content;
	}

	/** full constructor */
	public BiYylActivity(Long id, String content, String type, String status,
			Timestamp createtime, Timestamp starttime, Timestamp endtime) {
		this.id = id;
		this.content = content;
		this.type = type;
		this.status = status;
		this.createtime = createtime;
		this.starttime = starttime;
		this.endtime = endtime;
	}

	// Property accessors

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getCreatetime() {
		return this.createtime;
	}

	public void setCreatetime(Timestamp createtime) {
		this.createtime = createtime;
	}

	public Timestamp getStarttime() {
		return this.starttime;
	}

	public void setStarttime(Timestamp starttime) {
		this.starttime = starttime;
	}

	public Timestamp getEndtime() {
		return this.endtime;
	}

	public void setEndtime(Timestamp endtime) {
		this.endtime = endtime;
	}

}