package com.kidmate.wx.model;

import org.apache.commons.lang.StringUtils;

import com.kidmate.kmservice.TKmAppInfo;
import com.kidmate.kmservice.TKmControlRuleInfo;
import com.kidmate.wx.utils.MyUtils;

public class ControlRuleInfo {

	private long id;
	private long parentId;//
	private long childId;
	private long equipmentId;
	private long appId;
	private AppInfo appInfo;
	private long startTime;
	private long endTime;
	private long dur;
	private int repeatType;
	private String exceptapp;
	private boolean on;
	private long creattime;
	private String controlname;
	private String start;
	private String end;
	// extras
	private String repeat;
	private String repeatValue;
	private int exceptnum;
	private String durString;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getParentId() {
		return parentId;
	}

	public void setParentId(long parentId) {
		this.parentId = parentId;
	}

	public long getChildId() {
		return childId;
	}

	public void setChildId(long childId) {
		this.childId = childId;
	}

	public long getEquipmentId() {
		return equipmentId;
	}

	public void setEquipmentId(long equipmentId) {
		this.equipmentId = equipmentId;
	}

	public long getAppId() {
		return appId;
	}

	public void setAppId(long appId) {
		this.appId = appId;
	}

	public AppInfo getAppInfo() {
		return appInfo;
	}

	public void setAppInfo(AppInfo appInfo) {
		this.appInfo = appInfo;
	}

	public long getStartTime() {
		return startTime;
	}

	public void setStartTime(long startTime) {
		this.startTime = startTime;
	}

	public long getEndTime() {
		return endTime;
	}

	public void setEndTime(long endTime) {
		this.endTime = endTime;
	}

	public long getDur() {
		return dur;
	}

	public void setDur(long dur) {
		this.dur = dur;
	}

	public int getRepeatType() {
		return repeatType;
	}

	public void setRepeatType(int repeatType) {
		this.repeatType = repeatType;
	}

	public String getExceptapp() {
		return exceptapp;
	}

	public void setExceptapp(String exceptapp) {
		this.exceptapp = exceptapp;
	}

	public boolean isOn() {
		return on;
	}

	public void setOn(boolean on) {
		this.on = on;
	}

	public long getCreattime() {
		return creattime;
	}

	public void setCreattime(long creattime) {
		this.creattime = creattime;
	}

	public String getControlname() {
		return controlname;
	}

	public void setControlname(String controlname) {
		this.controlname = controlname;
	}

	public String getRepeat() {
		return repeat;
	}

	public void setRepeat(String repeat) {
		this.repeat = repeat;
	}

	public String getRepeatValue() {
		return repeatValue;
	}

	public void setRepeatValue(String repeatValue) {
		this.repeatValue = repeatValue;
	}

	public int getExceptnum() {
		return exceptnum;
	}

	public void setExceptnum(int exceptnum) {
		this.exceptnum = exceptnum;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public String getEnd() {
		return end;
	}

	public void setEnd(String end) {
		this.end = end;
	}

	public String getDurString() {
		return durString;
	}

	public void setDurString(String durString) {
		this.durString = durString;
	}

	public ControlRuleInfo() {
		super();
	}

	public ControlRuleInfo(TKmControlRuleInfo info) {
		super();
		this.id = info.id;
		this.parentId = info.parentId;
		this.childId = info.childId;
		this.equipmentId = info.equipmentId;
		this.appId = info.appId;
		this.startTime = info.startTime;
		this.endTime = info.endTime;
		this.dur = info.dur;
		this.repeatType = info.repeatType;
		this.exceptapp = info.exceptapp;
		this.on = info.on;
		this.creattime = info.creattime;
		this.controlname = info.controlname;
		this.repeat = MyUtils.getRepeatDayStr(this.repeatType);
		this.repeatValue = MyUtils.getRepeatDayVal(this.repeatType);
		if (!StringUtils.isEmpty(exceptapp))
			this.exceptnum = this.exceptapp.split(",").length;
		else
			exceptnum = 0;
		this.start = MyUtils.formatMilliToTimeStr(this.startTime);
		this.end = MyUtils.formatMilliToTimeStr(this.endTime);
		if (info.isSetDur())
			this.durString = MyUtils.convertMilliToHHMM(info.dur);
	}

}
