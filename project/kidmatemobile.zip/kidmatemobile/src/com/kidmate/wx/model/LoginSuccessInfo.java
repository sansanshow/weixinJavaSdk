package com.kidmate.wx.model;

public class LoginSuccessInfo {
	private String accessToken;
	private int equipNum;

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public int getEquipNum() {
		return equipNum;
	}

	public void setEquipNum(int equipNum) {
		this.equipNum = equipNum;
	}

	public LoginSuccessInfo(String accessToken, int equipNum) {
		super();
		this.accessToken = accessToken;
		this.equipNum = equipNum;
	}

	public LoginSuccessInfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LoginSuccessInfo(String accessToken) {
		super();
		this.accessToken = accessToken;
	}

}
