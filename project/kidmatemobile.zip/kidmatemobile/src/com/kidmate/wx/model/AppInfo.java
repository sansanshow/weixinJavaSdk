package com.kidmate.wx.model;

import com.kidmate.kmservice.TKmAppInfo;

public class AppInfo {
	private long id;
	private String name;
	private String packagename;
	private String url;
	private String ver;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPackagename() {
		return packagename;
	}
	public void setPackagename(String packagename) {
		this.packagename = packagename;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getVer() {
		return ver;
	}
	public void setVer(String ver) {
		this.ver = ver;
	}
	public AppInfo(){
		super();
	}
	public AppInfo(TKmAppInfo info){
		super();
		this.id= info.id;
		if(info.isSetName())
			this.name= info.name;
		if(info.isSetPackagename())
			this.packagename= info.packagename;
		if(info.isSetUrl())
			this.url= info.url;
		if(info.isSetVer())
			this.ver= info.ver;
		
	}
}
