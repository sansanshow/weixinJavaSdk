package com.kidmate.wx.model;

import java.io.Serializable;

import com.kidmate.kmservice.TKmAppInfo;

public class AllowApp {
	private long id;
	private String name; // required
	private String packagename; // required
	private String url; // required
	private String ver;
	private int statusType;
	private boolean isSelected;

	public AllowApp(TKmAppInfo appInfo) {
		super();
		this.id = appInfo.id;
		this.name = appInfo.name;
		this.packagename = appInfo.packagename;
		this.url = appInfo.url;
		this.ver = appInfo.ver;
	}

	public AllowApp() {
		// TODO Auto-generated constructor stub
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPackagename() {
		return packagename;
	}

	public void setPackagename(String packagename) {
		this.packagename = packagename;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getVer() {
		return ver;
	}

	public void setVer(String ver) {
		this.ver = ver;
	}

	public int getStatusType() {
		return statusType;
	}

	public void setStatusType(int statusType) {
		this.statusType = statusType;
	}

	public boolean isSelected() {
		return isSelected;
	}

	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}

}
