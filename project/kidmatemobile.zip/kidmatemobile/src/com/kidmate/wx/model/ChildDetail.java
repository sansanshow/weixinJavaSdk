package com.kidmate.wx.model;

import java.util.List;

import com.kidmate.kmservice.TKmEquipment;

public class ChildDetail {
	private long id; // required
	private String name; // required
	private boolean gender; // required
	private long birth; // required
	private List<TKmEquipment> equipmentList;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isGender() {
		return gender;
	}

	public void setGender(boolean gender) {
		this.gender = gender;
	}

	public long getBirth() {
		return birth;
	}

	public void setBirth(long birth) {
		this.birth = birth;
	}

	public List<TKmEquipment> getEquipmentList() {
		return equipmentList;
	}

	public void setEquipmentList(List<TKmEquipment> equipmentList) {
		this.equipmentList = equipmentList;
	}

}
