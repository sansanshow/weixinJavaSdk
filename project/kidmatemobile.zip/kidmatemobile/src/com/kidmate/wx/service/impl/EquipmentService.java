package com.kidmate.wx.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.thrift.TException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kidmate.kmservice.TKmAppInfo;
import com.kidmate.kmservice.TKmAppUsage;
import com.kidmate.kmservice.TKmAppUsageStatistics;
import com.kidmate.kmservice.TKmChild;
import com.kidmate.kmservice.TKmControlRuleInfo;
import com.kidmate.kmservice.TKmEquipment;
import com.kidmate.kmservice.TKmException;
import com.kidmate.kmservice.TKmTimeStatistics;
import com.kidmate.kmservice.TKmUser;
import com.kidmate.service.impl.ParentServiceImpl;
import com.kidmate.wx.model.AppInfo;
import com.kidmate.wx.model.ControlRuleInfo;
import com.kidmate.wx.model.EquipDetail;
import com.kidmate.wx.model.History;
import com.kidmate.wx.pojo.WxTimeStatistics;
import com.kidmate.wx.service.IWxEquipmentService;
import com.kidmate.wx.utils.MyUtils;
import com.kidmate.wx.utils.WeixinConfig;

@Service("EquipmentService")
public class EquipmentService implements IWxEquipmentService {
	@Autowired
	@Resource(name = "wxconfig")
	private WeixinConfig config;

	@Resource(name = "ParentServiceImpl")
	private ParentServiceImpl parentServiceImpl;

	@Override
	public List<History> getEquipHistory(TKmUser user, long equipid, int page,
			int size, int type) throws TException {
		List<TKmAppUsage> appUsages = parentServiceImpl
				.getEquipmentAppUsageStatistics(user, equipid, page, size, type);
//		System.out.println("----appUsages obj------" + appUsages);
		List<History> histories = new ArrayList<History>();
		History item = null;
		if (appUsages != null && appUsages.size() > 0) {
			// 得到APP信息
			List<Long> appids = new ArrayList<Long>();
			appids = parentServiceImpl.getEquipmentAllAPP(user, equipid);
			List<TKmAppInfo> appInfos = parentServiceImpl.getAppInfoByIDs(user,
					appids);
			Map<Long, TKmAppInfo> mapInfos = new HashMap<Long, TKmAppInfo>();
			for (TKmAppInfo tKmAppInfo : appInfos) {
				mapInfos.put(tKmAppInfo.getId(), tKmAppInfo);
			}
			for (TKmAppUsage usage : appUsages) {
				item = new History();
				item.setId(usage.getId());
				item.setAppid(usage.getAppid());
				if(usage.getAppid() <= 0 || mapInfos.get(usage.getAppid()) == null || StringUtils.isEmpty(mapInfos.get(usage.getAppid()).getName())){
//					System.out.println("History---continue--appid:"+usage.getAppid()+",sss:"+mapInfos.get(usage.getAppid()));
					continue;
				}
				item.setAppName(mapInfos.get(usage.getAppid()).getName());
				item.setStart(MyUtils.formatMilliToTime(usage.getTime()));
				item.setEnd(MyUtils.formatMilliToTime(usage.getTime()
						+ usage.getDuration()));
				item.setUrl(mapInfos.get(usage.getAppid()).getUrl());
				item.setTime(MyUtils.convertMilliToMinStr(usage.getDuration()));
				histories.add(item);
//				if(histories.size()==5){
//					break;
//				}
			}
		}
		return histories;
	}

	/**
	 * 
	 */
	@Override
	public List<EquipDetail> getAllEquipmentDetail(TKmUser user)
			throws TKmException, TException {
		List<TKmEquipment> equipments = parentServiceImpl.getAllEquipment(user);
		List<EquipDetail> equipDetails = new ArrayList<EquipDetail>();
		EquipDetail detail = null;
		if (equipments != null && equipments.size() > 0) {
			List<TKmChild> childs = parentServiceImpl.getChildList(user);
			Map<Long, TKmChild> childMap = new HashMap<Long, TKmChild>();
			for (TKmChild tKmChild : childs) {
				childMap.put(tKmChild.getId(), tKmChild);
			}
			for (TKmEquipment tKmEquipment : equipments) {
				detail = new EquipDetail();
				detail.setEquipId(tKmEquipment.getId());
				detail.setAliasName(tKmEquipment.getAliasName());
				detail.setChildId(tKmEquipment.getChildId());
				long childId = tKmEquipment.getChildId();
				detail.setChildName(childMap.get(tKmEquipment.getChildId()) != null ? childMap
						.get(tKmEquipment.getChildId()).getName() : "");
				detail.setLastip(tKmEquipment.getLastip());
				detail.setLasttime(tKmEquipment.getLasttime());
				detail.setMac(tKmEquipment.getMac());
				detail.setSign(tKmEquipment.getSign());
				equipDetails.add(detail);
			}

		}
		return equipDetails;
	}

	/**
	 * 获取孩子最近一周平均使用情况
	 * 
	 */
	@Override
	public List<WxTimeStatistics> getChildTimeStatistics(TKmUser user,
			long childId, int dayCount) throws TException {
		List<WxTimeStatistics> list = new ArrayList<WxTimeStatistics>();
		List<TKmTimeStatistics> tKmlist = parentServiceImpl
				.getChildTimeStatistics(user, childId, dayCount);
		WxTimeStatistics wxobj = null;
		if (tKmlist != null) {
			for (int i = 0; i < tKmlist.size(); i++) {
				double selfdur = MyUtils
						.convertMilliToMin(tKmlist.get(i).selfDuration);
				double avgdur = MyUtils
						.convertMilliToMin(tKmlist.get(i).avgDuration);
				wxobj = new WxTimeStatistics();
				wxobj.setTime(MyUtils.formatDate("MM/dd",
						new Date(tKmlist.get(i).time)));
				wxobj.setAvgDuration(avgdur);
				wxobj.setSelfDuration(selfdur);
				list.add(wxobj);
			}
		}
		return list;
	}

	/**
	 * 获取最近几日使用top
	 * 
	 */
	@Override
	public List<History> getChildAppUsageStatistics(TKmUser user, long childId,
			long equipId, int dayCount, int topX) throws TException {
		List<TKmAppUsageStatistics> tKmlist = parentServiceImpl
				.getChildAppUsageStatistics(user, childId, dayCount, topX);
		List<History> mineHistories = new ArrayList<History>();
		History item = null;
		if (tKmlist != null && tKmlist.size() > 0) {
			// 得到APP信息
			List<Long> appids = new ArrayList<Long>();
			appids = parentServiceImpl.getEquipmentAllAPP(user, equipId);
			List<TKmAppInfo> appInfos = parentServiceImpl.getAppInfoByIDs(user,
					appids);
//			System.out.println("Top-History-appInfos:"+appInfos);
			Map<Long, TKmAppInfo> mapInfos = new HashMap<Long, TKmAppInfo>();
			for (TKmAppInfo tKmAppInfo : appInfos) {
				mapInfos.put(tKmAppInfo.getId(), tKmAppInfo);
			}
			for (TKmAppUsageStatistics usage : tKmlist) {
				item = new History();
				item.setAppid(usage.getAppid());
				if(usage.getAppid() <= 0 || mapInfos.get(usage.getAppid()) == null || StringUtils.isEmpty(mapInfos.get(usage.getAppid()).getName())){
//					System.out.println("Top-History---continue--appid:"+usage.getAppid()+",sss:"+mapInfos.get(usage.getAppid()));
					continue;
				}
				item.setAppName(mapInfos.get(usage.getAppid()).getName());
				item.setStart(MyUtils.formatMilliToTime(usage.getTime()));
				item.setEnd(MyUtils.formatMilliToTime(usage.getTime()
						+ usage.getDuration()));
				item.setUrl(mapInfos.get(usage.getAppid()).getUrl());
				item.setTime(MyUtils.convertMilliToMinStr(usage.getDuration()));
				item.setMinutes(MyUtils.convertMilliToMin(usage.getDuration()));
				mineHistories.add(item);
			}
		}
//		System.out.println("最近5日top:" + mineHistories);
		return mineHistories;
	}

	@Override
	public TKmControlRuleInfo getLockRule(TKmUser user, long childid, long equipmentID) throws TKmException, TException {
		List<TKmControlRuleInfo> controlRuleInfos = parentServiceImpl.getAllControlRuleInfo(user, childid, equipmentID);
		System.out.println("---controlRuleInfos:"+controlRuleInfos);
		for (TKmControlRuleInfo tKmControlRuleInfo : controlRuleInfos) {
			if(tKmControlRuleInfo.getAppId()==1){
				return tKmControlRuleInfo;
			}
		}
		TKmControlRuleInfo rule =new TKmControlRuleInfo();
		rule = new TKmControlRuleInfo();
		rule.parentId = user.userid;
		rule.childId = childid;
		rule.equipmentId = equipmentID;
		rule.appId = 1;
		rule.on = false;
//		rule = parentServiceImpl.saveControlRuleInfo(user, rule);
		return parentServiceImpl.saveControlRuleInfo(user, rule);
	}
	/**
	 * 获取规则
	 * @author san
	 * @param user
	 * @param childid
	 * @param equipmentID
	 * @param type 0:时段控制；1：锁屏规则；大于0：单个应用（时长限制）
	 * @return
	 * @throws TKmException
	 * @throws TException List<TKmControlRuleInfo>
	 */
	@Override
	public List<ControlRuleInfo> getControlRule(TKmUser user, long childid, long equipmentID,int type)throws TKmException, TException {
		System.out.println("===EquipService==getControlRule------");
		List<TKmControlRuleInfo> controlRuleInfos;
		List<ControlRuleInfo> ret_list = new ArrayList<ControlRuleInfo>();
//		for (TKmControlRuleInfo tKmControlRuleInfo : controlRuleInfos) {
//			if(tKmControlRuleInfo.getAppId()==type){
//				ret_list.add(tKmControlRuleInfo);
//			}else {
//				ret_list.add(tKmControlRuleInfo);
//			}
//		}
		System.out.println("===type=="+type);
		switch (type) {
		case 0:
		case 1:
			controlRuleInfos = parentServiceImpl.getAllControlRuleInfo(user, childid, equipmentID);
			System.out.println("---controlRuleInfos:"+controlRuleInfos);
			for (TKmControlRuleInfo tKmControlRuleInfo : controlRuleInfos) {
				if(tKmControlRuleInfo.getAppId()==type){
					ret_list.add(new ControlRuleInfo(tKmControlRuleInfo));
				}
			}
			break;
		case 10000://锁屏
			controlRuleInfos = parentServiceImpl.getAllControlRuleInfo(user, childid, equipmentID);
			System.out.println("---controlRuleInfos:"+controlRuleInfos);
			for (TKmControlRuleInfo tKmControlRuleInfo : controlRuleInfos) {
				if(tKmControlRuleInfo.getAppId()==1){
					ret_list.add(new ControlRuleInfo(tKmControlRuleInfo));
				}
			}
			break;
		case 1000: // 不受控制
			//得到 控制 ids
			List<Long> ctrlIds=new ArrayList<Long>();
			ctrlIds = parentServiceImpl.getEquipmentOutOfControlAPP(user, equipmentID);
			if (ctrlIds != null && ctrlIds.size() > 0) {
				// 得到APP信息，放入map
				List<TKmAppInfo> appInfos = parentServiceImpl.getAppInfoByIDs(user,
						ctrlIds);
				Map<Long, TKmAppInfo> map_id_Infos = new HashMap<Long, TKmAppInfo>();
				for (TKmAppInfo tKmAppInfo : appInfos) {
					map_id_Infos.put(tKmAppInfo.getId(), tKmAppInfo);
				}
				//遍历，对应关系、
				ControlRuleInfo info;
				for (Long appid : ctrlIds) {
					info = new ControlRuleInfo();
					info.setAppId(appid);
					if( map_id_Infos.get(info.getAppId()) == null || StringUtils.isEmpty(map_id_Infos.get(info.getAppId()).getName())){
						continue;
					}
					info.setAppInfo(new AppInfo(map_id_Infos.get(info.getAppId())));
					ret_list.add(info);
				}
			}
			break;
		case 2000: // 受控制
			//得到 控制 ids
			ctrlIds = parentServiceImpl.getEquipmentUnderControlAPP(user, equipmentID);
			controlRuleInfos = parentServiceImpl.getAllControlRuleInfo(user, childid, equipmentID);
			System.out.println("---controlRuleInfos:"+controlRuleInfos);
			if (ctrlIds != null && ctrlIds.size() > 0) {
				// 得到APP信息，放入map
				List<TKmAppInfo> appInfos = parentServiceImpl.getAppInfoByIDs(user,
						ctrlIds);
				Map<Long, TKmAppInfo> map_id_Infos = new HashMap<Long, TKmAppInfo>();
				for (TKmAppInfo tKmAppInfo : appInfos) {
					map_id_Infos.put(tKmAppInfo.getId(), tKmAppInfo);
					System.out.println("appInfos:"+appInfos);
				}
				//ControlRuleInfo 放入Map
				Map<Long, TKmControlRuleInfo> map_appId_ControlRuleInfo = new HashMap<Long, TKmControlRuleInfo>();
				for (TKmControlRuleInfo tKmControlRuleInfo : controlRuleInfos) {
					if(tKmControlRuleInfo.getAppId() >= 2000){
						System.out.println(tKmControlRuleInfo.getAppId());
						map_appId_ControlRuleInfo.put(tKmControlRuleInfo.getAppId(), tKmControlRuleInfo);
					}
				}
				//遍历，对应关系、
				System.out.println("--------id ctrlIds------");
				System.out.println(ctrlIds);
				System.out.println("--------id ctrlIds for------");
				ControlRuleInfo info;
				for (Long appid : ctrlIds) {
					TKmControlRuleInfo tKmControlRuleInfo = map_appId_ControlRuleInfo.get(appid);
					System.out.println(appid);
					System.out.println("--appid---"+tKmControlRuleInfo);
					if(tKmControlRuleInfo==null){
						System.out.println("tKmControlRuleInfo==null");
						continue;
					}
					info = new ControlRuleInfo(tKmControlRuleInfo);
					if( map_id_Infos.get(info.getAppId()) == null || StringUtils.isEmpty(map_id_Infos.get(info.getAppId()).getName())){
						continue;
					}
					info.setAppInfo(new AppInfo(map_id_Infos.get(info.getAppId())));
					ret_list.add(info);
				}
			}
			break;
		default:
			break;
		}
		System.out.println("ret_list----");
		System.out.println(ret_list);
		return ret_list;
	}

	@Override
	public TKmControlRuleInfo getRuleByRuleId(TKmUser user, long ruleId, long childid, long equipmentID) throws TKmException, TException {
		List<TKmControlRuleInfo> controlRuleInfos = parentServiceImpl.getAllControlRuleInfo(user, childid, equipmentID);
		List<TKmControlRuleInfo> ret_list = new ArrayList<TKmControlRuleInfo>();
		for (TKmControlRuleInfo tKmControlRuleInfo : controlRuleInfos) {
			if(tKmControlRuleInfo.id==ruleId){
				return tKmControlRuleInfo;
			}
		}
		return null;
	}
}
