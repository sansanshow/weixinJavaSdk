package com.kidmate.wx.service;

import java.net.MalformedURLException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.thrift.TException;

import com.kidmate.kmservice.TKmChild;
import com.kidmate.kmservice.TKmEquipment;
import com.kidmate.kmservice.TKmException;
import com.kidmate.kmservice.TKmUser;

public interface IUserService {
	public TKmUser login(String openid,String token, String ip);
	public String doSendVerifyCode(String mobiles, String openid,String function);
	public TKmUser bindMobile(String mobile, String openid, String ip);
	public int checkVerifyCode(String mobile, String openid, String code, String func);
	/**
	 * 获取孩子列表
	 * @author san
	 * @param user
	 * @return List<TKmChild>
	 * @throws TException 
	 */
	public List<TKmChild> getChildList(TKmUser user) throws TException;
	public List<TKmEquipment> getAllEquipment(TKmUser user) throws TKmException,
			TException;
	public String getChidStr(TKmUser user, long childId) throws TKmException,
			TException;
	
	/**********************************************/
	public TKmUser loginWx(String accessToken,String opendId,String unionid, int source, String ip);
	public String getNewsList(HttpServletResponse response)
			throws MalformedURLException, KeyManagementException, NoSuchAlgorithmException, NoSuchProviderException;
	public JSONObject login(String code, int source, String singnature, String encryptedData, String iv, String ip);
}
