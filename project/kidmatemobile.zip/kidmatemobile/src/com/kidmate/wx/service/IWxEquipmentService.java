package com.kidmate.wx.service;

import java.util.List;

import org.apache.thrift.TException;

import com.kidmate.kmservice.TKmAppUsageStatistics;
import com.kidmate.kmservice.TKmControlRuleInfo;
import com.kidmate.kmservice.TKmException;
import com.kidmate.kmservice.TKmUser;
import com.kidmate.wx.model.ControlRuleInfo;
import com.kidmate.wx.model.EquipDetail;
import com.kidmate.wx.model.History;
import com.kidmate.wx.pojo.WxTimeStatistics;

public interface IWxEquipmentService {

	public List<History> getEquipHistory(TKmUser user, long equipid, int page, int size, int type) throws TException;

	public List<EquipDetail> getAllEquipmentDetail(TKmUser user) throws TKmException, TException ;

	List<WxTimeStatistics> getChildTimeStatistics(TKmUser user, long childId,
			int dayCount) throws TException;

	List<History> getChildAppUsageStatistics(TKmUser user,
			long childId, long equipId, int dayCount, int topX) throws TException;

	public TKmControlRuleInfo getLockRule(TKmUser user, long childid, long equipid) throws TKmException, TException ;

	//
	List<ControlRuleInfo> getControlRule(TKmUser user, long childid,
			long equipmentID, int type) throws TKmException, TException;

	public TKmControlRuleInfo getRuleByRuleId(TKmUser user, long ruleId, long childid, long equipid) throws TKmException, TException;

}
