package com.kidmate.wx.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

import com.kidmate.wx.response.Article;
import com.kidmate.wx.response.NewsMessage;
import com.kidmate.wx.response.TextMessage;
import com.kidmate.wx.utils.MessageUtil;

/**
 * 核心服务类
 * 
 * @author liufeng
 * @date 2013-05-20
 */
public class CoreService {
	/**
	 * 处理微信发来的请求
	 * 
	 * @param request
	 * @return
	 */
	public static String processRequest(HttpServletRequest request) {
		String respMessage = null;
		try {
			// 默认返回的文本消息内容
			String respContent = "您好，我们会根据你提供的信息稍后为您做出答复！";

			// xml请求解析
			Map<String, String> requestMap = MessageUtil.parseXml(request);
			System.out.println("requestMap:" + requestMap);
			// 发送方帐号（open_id）
			String fromUserName = requestMap.get("FromUserName");
			// 公众帐号
			String toUserName = requestMap.get("ToUserName");
			// 消息类型
			String msgType = requestMap.get("MsgType");
			// 消息内容
			String msgContent = requestMap.get("Content");

			// 回复文本消息
			TextMessage textMessage = new TextMessage();
			textMessage.setToUserName(fromUserName);
			textMessage.setFromUserName(toUserName);
			textMessage.setCreateTime(new Date().getTime());
			textMessage.setMsgType(MessageUtil.RESP_MESSAGE_TYPE_TEXT);
			textMessage.setFuncFlag(0);
			
			// 文本消息
			if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_TEXT)) {
				List<Article> articleList = new ArrayList<Article>();  
				NewsMessage newsMessage = new NewsMessage();  
                newsMessage.setToUserName(fromUserName);  
                newsMessage.setFromUserName(toUserName);  
                newsMessage.setCreateTime(new Date().getTime());  
                newsMessage.setMsgType(MessageUtil.RESP_MESSAGE_TYPE_NEWS);  
                newsMessage.setFuncFlag(0);
				if(msgContent.contains("傻逼") || msgContent.contains("煞笔") || msgContent.toUpperCase().contains("SB")){
					respContent = "文明用语哦~";
					textMessage.setContent(respContent);
					respMessage = MessageUtil.textMessageToXml(textMessage);
				}
				else if(msgContent.trim().equals("?")||msgContent.trim().equals("？")){
					respContent = getMainMenu(2);
					textMessage.setContent(respContent);
					respMessage = MessageUtil.textMessageToXml(textMessage);
				}
				else if(msgContent.trim().equals("1")){		//家长端
					respMessage = MessageUtil.initImageMessage(toUserName, fromUserName,1);
				}
				else if(msgContent.trim().equals("2")){		//儿童端下载图片
					respMessage = MessageUtil.initImageMessage(toUserName, fromUserName,2);
				}
				else if(msgContent.trim().equals("3")){		//使用帮助
					Article article = new Article();  
                    article.setTitle("苗苗帮助手册");  
                    // 图文消息中可以使用QQ表情、符号表情  
                    article.setDescription("一、绑定儿童端与解绑\n……\n\n二、儿童端自启动设置\n……\n\n三、常见问题\n……");  
                    // 将图片置为空  
                    article.setPicUrl("http://0.xiaoqrobot.duapp.com/images/avatar_liufeng.jpg");  
                    article.setUrl("http://www.kidmate.cn/help.html");  
                    articleList.add(article);  
                    newsMessage.setArticleCount(articleList.size());  
                    newsMessage.setArticles(articleList);  
                    respMessage = MessageUtil.newsMessageToXml(newsMessage); 
				}
				else if(msgContent.trim().equals("6")){ //6 视频消息  
					respMessage = MessageUtil.initVideoMessage(toUserName, fromUserName);
				}
				else if(msgContent.trim().equals("7")){//7  语音消息
					respMessage = MessageUtil.initVoiceMessage(toUserName, fromUserName);
					
				}
				else if(msgContent.trim().equals("8")){//8  音乐消息
					respContent = "音乐消息";
					textMessage.setContent(respContent);
					respMessage = MessageUtil.textMessageToXml(textMessage);
				}
				else{
					respContent = "发送“？”得到更多帮助哦~";
					textMessage.setContent(respContent);
					respMessage = MessageUtil.textMessageToXml(textMessage);
				}
			}
			// 图片消息
			else if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_IMAGE)) {
				textMessage.setContent(respContent);
				respMessage = MessageUtil.textMessageToXml(textMessage);
			}
			// 地理位置消息
			else if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_LOCATION)) {
				textMessage.setContent(respContent);
				respMessage = MessageUtil.textMessageToXml(textMessage);
			}
			// 链接消息
			else if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_LINK)) {
				textMessage.setContent(respContent);
				respMessage = MessageUtil.textMessageToXml(textMessage);
			}
			// 音频消息
			else if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_VOICE)) {
				textMessage.setContent(respContent);
				respMessage = MessageUtil.textMessageToXml(textMessage);
			}
			// 事件推送
			else if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_EVENT)) {
				// 事件类型
				String eventType = requestMap.get("Event");
				// 订阅
				if (eventType.equals(MessageUtil.EVENT_TYPE_SUBSCRIBE)) {
					respContent = getMainMenu(2);
					textMessage.setContent(respContent);
					respMessage = MessageUtil.textMessageToXml(textMessage);
				}
				// 取消订阅
				else if (eventType.equals(MessageUtil.EVENT_TYPE_UNSUBSCRIBE)) {
					// TODO 取消订阅后用户再收不到公众号发送的消息，因此不需要回复消息
				}
				// 自定义菜单点击事件
				else if (eventType.equals(MessageUtil.EVENT_TYPE_CLICK)) {
					// TODO 自定义菜单权没有开放，暂不处理该类消息
					String eventKey = requestMap.get("EventKey");
					int key=Integer.parseInt(eventKey);
					System.out.println("key="+key);
					switch (key) {
					case 1021:
						respMessage = MessageUtil.initImageMessage(toUserName, fromUserName,1);
						break;
					case 1022:
						respMessage = MessageUtil.initImageMessage(toUserName, fromUserName,1);
						break;
						
					default:
						break;
					}
				}
//				textMessage.setContent(respContent);
//				respMessage = MessageUtil.textMessageToXml(textMessage);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("返回消息：");
		System.out.println(respMessage);
		return respMessage;
	}
	
	/** 
	 * xiaoqrobot的主菜单 
	 *  
	 * @return 
	 */  
	public static String getMainMenu(int type) {  
		StringBuffer buffer = new StringBuffer();  
		buffer.append("您好，亲爱的家长，欢迎"+(type==1?"关注":"使用")+"“苗苗”!\n您可以点击菜单选择服务，或者回复数字选择服务：").append("\n\n");
		buffer.append("1  家长端APP下载").append("\n");
		buffer.append("2 儿童端APP下载").append("\n");  
		buffer.append("3  使用帮助").append("\n\n");  
		buffer.append("回复“?”显示此帮助菜单");  
		return buffer.toString();  
	}  
	/** 
     * emoji表情转换(hex -> utf-16) 
     *  
     * @param hexEmoji 
     * @return 
     */  
    public static String emoji(int hexEmoji) {  
        return String.valueOf(Character.toChars(hexEmoji));  
    }  
}
