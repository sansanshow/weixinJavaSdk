package com.kidmate.wx.service.impl;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.annotation.Resource;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.apache.thrift.TException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

import com.kidmate.kmservice.TKmChild;
import com.kidmate.kmservice.TKmEquipment;
import com.kidmate.kmservice.TKmException;
import com.kidmate.kmservice.TKmUser;
import com.kidmate.model.KmParent;
import com.kidmate.model.KmParentDAO;
import com.kidmate.model.KmParentSms;
import com.kidmate.model.KmParentSmsDAO;
import com.kidmate.service.IChildUserService;
import com.kidmate.service.IEquipmentService;
import com.kidmate.service.IParentUserService;
import com.kidmate.tools.Config;
import com.kidmate.tools.Constants;
import com.kidmate.tools.SecurityUtils;
import com.kidmate.wx.model.LoginSuccessInfo;
import com.kidmate.wx.pojo.ReturnValue;
import com.kidmate.wx.service.IUserService;
import com.kidmate.wx.sms.SMSHandle;
import com.kidmate.wx.utils.MD5Utils;
import com.kidmate.wx.utils.MyUtils;
import com.kidmate.wx.utils.MyX509TrustManager;
import com.kidmate.wx.utils.PropertyManager;
import com.kidmate.wx.utils.WXBizDataCrypt;
import com.kidmate.wx.utils.WeixinConfig;
import com.kidmate.wx.utils.WeixinUtil;

@Service("UserService")
public class UserService implements IUserService {
	private static Logger logger = LoggerFactory.getLogger(UserService.class);
	private Random random = new Random();

	@Resource(name = "Config")
	private Config config;

	@Resource(name = "wxconfig")
	private WeixinConfig wxconfig;

	@Resource(name = "KmParentSmsDAO")
	private KmParentSmsDAO kmParentSmsDAO;

	@Resource(name = "KmParentDAO")
	private KmParentDAO kmParentDAO;

	@Resource(name = "ChildUserServiceImpl")
	private IChildUserService childUserService;

	@Resource(name = "EquipmentServiceImpl")
	private IEquipmentService equipmentService;

	@Resource(name = "ParentUserServiceImpl")
	private IParentUserService parentUserService;

	@Resource(name = "ShardedJedisPool")
	private ShardedJedisPool shardedJedisPool;

	@Override
	public TKmUser login(String openid, String access_token, String ip) {
		// TODO Auto-generated method stub
		List<KmParent> kmParentList = kmParentDAO.findByWxopenid(openid);
		if (MyUtils.notEmptyList(kmParentList)) {
			// &&
			// sign.toUpperCase().equals(kmParentList.get(0).getSign().toUpperCase())
			KmParent kmParent = new KmParent();
			kmParent = kmParentList.get(0);
			String sign = SecurityUtils.md5ByHex("#$wrt"
					+ random.nextInt(10000000) + openid
					+ random.nextInt(10000000));
			String md5token = MD5Utils.md5ByHex(sign);
			kmParent.setSign(sign);
			kmParent.setMd5token(md5token);
			kmParent.setLastloginip(ip);
			kmParent.setLastlogintime(new Date(System.currentTimeMillis()));
			kmParentDAO.attachDirty(kmParent);
			TKmUser user = new TKmUser();
			user.setUserid(kmParent.getId());
			user.setSign(kmParent.getSign());

			ShardedJedis shardedJedis = shardedJedisPool.getResource();
			shardedJedis.hset(Constants.PARENTSIGN,
					String.valueOf(kmParent.getId()), kmParent.getMd5token()
							+ kmParent.getSign());
			shardedJedisPool.returnResource(shardedJedis);
			/*************************************/
			// parentUserService.login(authToken, source, ip, invitecode);

			return user;
		}
		return null;
	}

	@Override
	public String doSendVerifyCode(String mobiles, String openid,
			String function) {
		logger.info("---------doSendVerifyCode--------------");
		String verifyCode = String.format("%06d", random.nextInt(999999));
		String msg = "验证码：" + verifyCode + "，验证码20分钟有效，请及时验证哦！";
		List<KmParentSms> list = kmParentSmsDAO.findByOpenid(openid);
		KmParentSms sms = new KmParentSms();
		if (list != null && list.size() > 0) {
			sms = list.get(0);
		}
		sms.setCreatetime(new Date());
		sms.setMobiles(mobiles);
		sms.setMsg(msg);
		sms.setOpenid(openid);
		sms.setFunctionname(function);
		sms.setVerifyCode(verifyCode);
		kmParentSmsDAO.attachDirty(sms);
		SMSHandle.getInstance().sendSMS(mobiles, msg);
		return null;
	}

	@Override
	public TKmUser bindMobile(String mobile, String openid, String ip) {
		long timestamp = System.currentTimeMillis();
		// if (!StringUtils.isEmpty(mobile) && !StringUtils.isEmpty(openid)) {
		// KmParent kmParent = new KmParent();
		// List<KmParent> kmParentList = kmParentDAO.findByMobile(mobile);
		// String sign = SecurityUtils.md5ByHex("#$wrt"
		// + random.nextInt(10000000) + openid
		// + random.nextInt(10000000));
		// String md5token = MD5Utils.md5ByHex(sign);
		// System.out.println("sign="+sign+",md5token:"+md5token);
		// System.err.println(md5token);
		// if (kmParentList != null && kmParentList.size() > 0) {
		// kmParent = kmParentList.get(0);
		// kmParent.setLastlogintime(new Date(timestamp));
		// kmParent.setLastloginip(ip);
		// kmParent.setWxopenid(openid);
		// kmParent.setMd5token(md5token);
		// kmParent.setSign(sign);
		// kmParentDAO.attachDirty(kmParent);
		// } else {
		// kmParent = new KmParent();
		// kmParent.setMobile(mobile);
		// kmParent.setStatus("1");
		// kmParent.setSourceid(3000L);
		// kmParent.setRegtime(new Date(timestamp));
		// kmParent.setRegip(ip);
		// kmParent.setWxopenid(openid);
		// kmParent.setLastlogintime(new Date(timestamp));
		// kmParent.setLastloginip(ip);
		// Calendar cal = Calendar.getInstance();
		// // 新注册用户，赠送7天VIP
		// cal.setTime(new Date());
		// cal.add(Calendar.DAY_OF_MONTH, 7);
		// kmParent.setVip(cal.getTime());
		// kmParent.setWxopenid(openid);
		// kmParent.setMd5token(md5token);
		// kmParent.setSign(sign);
		// kmParentDAO.save(kmParent);
		// }
		//
		// if (kmParent != null) {
		// TKmUser kmUser = new TKmUser();
		// kmUser.setSign(sign);
		// kmUser.setUserid(kmParent.getId());
		// if (kmParent.getVip() != null) {
		// kmUser.setTimestamp(kmParent.getVip().getTime());
		// }
		// ShardedJedis shardedJedis = shardedJedisPool.getResource();
		// shardedJedis.hset(Constants.PARENTSIGN,
		// String.valueOf(kmParent.getId()),
		// kmParent.getMd5token() + kmParent.getSign());
		// shardedJedisPool.returnResource(shardedJedis);
		//
		// return kmUser;
		// }
		// }
		return null;
	}

	@Override
	public int checkVerifyCode(String mobile, String openid, String code,
			String func) {
		if (!StringUtils.isEmpty(openid) && !StringUtils.isEmpty(mobile)) {
			List<KmParentSms> kmParentSms = kmParentSmsDAO
					.findByMobiles(mobile);
			if (MyUtils.notEmptyList(kmParentSms)) {
				KmParentSms sms = kmParentSms.get(0);
				if (openid.equals(sms.getOpenid())
						&& code.equals(sms.getVerifyCode())) {
					return 100;
				}
			}
		}
		return -1;
	}

	@Override
	public List<TKmChild> getChildList(TKmUser user) throws TException {
		return childUserService.getCHild(user.getUserid());
	}

	@Override
	public List<TKmEquipment> getAllEquipment(TKmUser user)
			throws TKmException, TException {

		return equipmentService.getParentEquipmentList(user.getUserid());

	}

	@Override
	public String getChidStr(TKmUser user, long childId) throws TKmException,
			TException {
		KmParent parent = kmParentDAO.findById(user.getUserid());
		String md5token = "";
		if (parent != null) {
			md5token = parent.getMd5token();
		}
		return MD5Utils.createChildInfoForServer(md5token, user.getUserid(),
				childId, System.currentTimeMillis());

	}

	/* #########-------###########------########## */
	/**
	 * accessToken:小程序的情况下，变成了sessionKey unionid:小程序的情况下，同openId一样
	 */
	@Override
	public TKmUser loginWx(String accessToken, String openId, String unionid,
			int source, String ip) {
		// TODO Auto-generated method stub
		TKmUser kmUser = new TKmUser();
		// if (config.isDevelop()) {
		if (false) {
			String md5token = SecurityUtils.md5ByHex(accessToken);
			String signature = SecurityUtils.md5ByHex("#$wrt"
					+ random.nextInt(10000000) + System.currentTimeMillis()
					+ random.nextInt(10000000));
			KmParent kmParent = null;
			if ("oqsSYxNPU-Ds-vAIrAwMKfq8uvq8".equals(openId)) {// 三三
				kmParent = kmParentDAO.findById(2029L);
				// } else
				// if("oqsSYxBIOeC2TyhEm-YL0j2vtWks".equals(openId)){//jhon
				// kmParent = kmParentDAO.findById(2000L);
			} else if ("oqsSYxBIOeC2TyhEm-YL0j2vtWks".equals(openId)) {// 王书婷
				kmParent = kmParentDAO.findById(2022L);
			} else {// 轩
				kmParent = kmParentDAO.findById(2022L);
			}
			long timestamp = System.currentTimeMillis();
			kmParent.setLastlogintime(new Date(timestamp));
			kmParent.setLastloginip(ip);
			kmParent.setOpenaccountid(kmParent.getId().toString());
			kmParent.setMd5token(md5token);
			kmParent.setSign(signature);
			kmParent.setStatus("1");
			kmParentDAO.attachDirty(kmParent);
			kmUser.setUserid(kmParent.getId());
			kmUser.setSign(signature);
			if (kmParent.getVip() != null) {
				kmUser.setTimestamp(kmParent.getVip().getTime());
			}
			System.err.println("develop-use=" + kmUser);
			ShardedJedis shardedJedis = shardedJedisPool.getResource();
			shardedJedis.hset(Constants.PARENTSIGN,
					String.valueOf(kmParent.getId()), kmParent.getMd5token()
							+ kmParent.getSign());
			shardedJedisPool.returnResource(shardedJedis);
			return kmUser;
		} else {
			try {
				kmUser = parentUserService.loginWx(accessToken, openId,
						unionid, source, ip);
			} catch (TException e) {
				e.printStackTrace();
				return null;
			}
			return kmUser;
		}
	}

	@Override
	public String getNewsList(HttpServletResponse response)
			throws MalformedURLException, KeyManagementException,
			NoSuchAlgorithmException, NoSuchProviderException {
		String url = PropertyManager.getProperty("rss_json_url");
		String ret = downloadNet(response, url);
		return ret;
	}

	public String downloadNet(HttpServletResponse response, String strurl)
			throws MalformedURLException, NoSuchAlgorithmException,
			NoSuchProviderException, KeyManagementException {
		// 下载网络文件
		int byteread = 0;
		response.setCharacterEncoding("UTF-8");
		URL url = new URL(strurl);
		StringBuffer buffer = new StringBuffer();
		JSONObject jsonObject = null;
		try {
			// 创建SSLContext对象，并使用我们指定的信任管理器初始化
			// TrustManager[] tm = { new MyX509TrustManager() };
			// SSLContext sslContext = SSLContext.getInstance("SSL", "SunJSSE");
			// sslContext.init(null, tm, new java.security.SecureRandom());
			// // 从上述SSLContext对象中得到SSLSocketFactory对象
			// SSLSocketFactory ssf = sslContext.getSocketFactory();
			URLConnection conn = url.openConnection();
			InputStream inStream = conn.getInputStream();

			// 将返回的输入流转换成字符串
			InputStreamReader inputStreamReader = new InputStreamReader(
					inStream, "utf-8");
			BufferedReader bufferedReader = new BufferedReader(
					inputStreamReader);

			String str = null;
			while ((str = bufferedReader.readLine()) != null) {
				buffer.append(str);
			}
			bufferedReader.close();
			inputStreamReader.close();
			// 释放资源
			inStream.close();
			inStream = null;
			jsonObject = JSONObject.fromObject(buffer.toString());

			//
			// ByteArrayOutputStream bos = new ByteArrayOutputStream();
			// byte[] buffer = new byte[1204];
			// while ((byteread = inStream.read(buffer)) != -1) {
			// bos.write(buffer, 0, byteread);
			// }
			// bos.close();
			// inStream.close();
			// String retStr = bos.toString();
			// System.out.println("------retStr--------");
			// System.out.println(retStr);
			// retStr =new String(retStr.getBytes(), "UTF-8");
			// return retStr;
			return jsonObject.toString();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public JSONObject login(String code, int source, String singnature,
			String encryptedData, String iv, String ip) {
		// TODO Auto-generated method stub
		ReturnValue result = new ReturnValue();
		logger.info("---new---login-source-");
		result.setStatus(200);
		TKmUser kmUser = new TKmUser();
		String openid = null, unionid = "", sessionKey = null, access_token = null;
		try {
			if (StringUtils.isEmpty(code)) {
				System.out.println("errorMsg:code is empty");
				result.setStatus(400);
				return JSONObject.fromObject(result);
			} else {
				JSONObject token_info = WeixinUtil.getAccessTokenByCode(
						source == 2000 ? wxconfig.getXcx_appid() : wxconfig
								.getAppid(),
						source == 2000 ? wxconfig.getXcx_appsecret() : wxconfig
								.getAppsecret(), code, source);
				// logger.info("---token_info---"+token_info);
				if (token_info.containsKey("errcode")) { // 如果包含errcode，说明该接口调用失败
					logger.info("--source--openid error----:" + token_info);
					result.setStatus(400);
				} else {

					if (source == 2000) {
						System.out.println("source==2000:");
						System.out.println(token_info.toString());
						sessionKey = token_info.getString("session_key");
						System.out.println("------sessionKey-------------");
						System.out.println(sessionKey);

						if (!"nodata".equals(singnature)) {

							System.out
									.println("------encryptedData-----------");
							System.out.println(encryptedData);
							System.out.println("------iv-----------------");
							System.out.println(iv);
							// openid = token_info.getString("openid");
							String deString = WXBizDataCrypt.getInstance()
									.decrypt(encryptedData, sessionKey, iv,
											"utf-8");
							System.out.println("=======deString=============");
							System.out.println(deString);
							com.alibaba.fastjson.JSONObject jsonObject = com.alibaba.fastjson.JSONObject
									.parseObject(deString);
							System.out.println("=====water=====start========");
							System.out.println(jsonObject);
							System.out.println("=====openid============");
							openid = jsonObject.getString("openId");
							System.out.println("=====unionid============");
							if (!jsonObject.containsKey("unionid")) {
								System.out.println("=====unionid===no-key=========");
								unionid = openid;
							} else {
								System.out.println("=====unionid===exists=========");
								unionid = jsonObject.getString("unionId");
							}
						} else {
							System.out.println("nodata.equals(singnature)");
							openid = token_info.getString("openid");
							unionid = token_info.getString("openid");
						}
						System.out.println("=====unionid============");
						kmUser = loginWx(sessionKey, openid, unionid, source,
								ip);
					} else if (source == 3000) {
						openid = token_info.getString("openid");
						access_token = token_info.getString("access_token");
						JSONObject userinfo = WeixinUtil.getUserInfoByToken(
								access_token, openid);
						result.setOpenid(openid);
						LoginSuccessInfo info = new LoginSuccessInfo(
								MD5Utils.md5ByHex(access_token));
						result.setContent(info);
						unionid = (String) userinfo.get("unionid");
						kmUser = loginWx(access_token, openid, unionid, source,
								ip);
					}

				}
				if (kmUser != null && kmUser.getUserid() > 0) {
					// try {
					// long viptime = parentServiceImpl.getVipTime(kmUser);
					// } catch (TException e) {
					// e.printStackTrace();
					// }
					result.setExtras(kmUser);
					result.setContent(new LoginSuccessInfo(MD5Utils
							.md5ByHex(source == 2000 ? sessionKey
									: access_token)));
					result.setUser(kmUser);
				} else {

				}
			}
		} catch (TKmException e) {
			// TODO Auto-generated catch block
			System.out.println("errorMsg: TKmException");
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("errorMsg: Exception");
			e.printStackTrace();
		}

		logger.info("config.isDevelop()-source-" + config.isDevelop());

		return JSONObject.fromObject(result);
	}
}
