package com.kidmate.wx.service.impl;

import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

import com.kidmate.model.KmParent;
import com.kidmate.model.KmParentDAO;
import com.kidmate.model.KmWxKeyReply;
import com.kidmate.model.KmWxKeyReplyDAO;
import com.kidmate.service.IParentUserService;
import com.kidmate.tools.Config;
import com.kidmate.tools.Constants;
import com.kidmate.tools.SecurityUtils;
import com.kidmate.wx.controller.EquipmentController;
import com.kidmate.wx.pojo.WxMenu;
import com.kidmate.wx.response.Article;
import com.kidmate.wx.response.NewsMessage;
import com.kidmate.wx.response.TextMessage;
import com.kidmate.wx.service.ICoreService;
import com.kidmate.wx.service.IWxConfigService;
import com.kidmate.wx.utils.MessageUtil;
import com.kidmate.wx.utils.MyUtils;
import com.kidmate.wx.utils.WeixinConfig;
import com.kidmate.wx.utils.WeixinUtil;

/**
 * 核心服务类
 * 
 * @author liufeng
 * @date 2013-05-20
 */
@Service("CoreServiceImpl")
public class CoreServiceImpl implements ICoreService{
	private static Logger logger = LoggerFactory
			.getLogger(CoreServiceImpl.class);
	public static final String KMWX_KEYWORD = "kmwxkeyword";
	@Resource(name = "KmWxKeyReplyDAO")
	private KmWxKeyReplyDAO kmWxKeyReplyDAO;
	
	@Resource(name = "ParentUserServiceImpl")
	private IParentUserService parentUserService;
	
	@Resource(name = "Config")
	private Config config;

	@Resource(name = "wxconfig")
	private WeixinConfig wxconfig;

	@Resource(name = "KmParentDAO")
	private KmParentDAO kmParentDAO;
	
	@Resource(name="WxConfigService")
	private IWxConfigService wxConfigService;
	
	@Resource(name = "ShardedJedisPool")
	private ShardedJedisPool shardedJedisPool;
	// 带渠道的二维码信息url
	private String QR_CODE_URL = "https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=TOKEN";
	// By Openid 获取 userInfo URL
	private String USERINFO_URL = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=ACCESS_TOKEN&openid=OPENID&lang=zh_CN";

	/**
	 * 处理微信发来的请求
	 * 
	 * @param request
	 * @return
	 */
	@Override
	public String processRequest(HttpServletRequest request) {
		String respMessage = null;
		try {
			// 默认返回的文本消息内容
			String respContent = "您好，我们会根据你提供的信息稍后为您做出答复！";

			// xml请求解析
			Map<String, String> requestMap = MessageUtil.parseXml(request);
			System.out.println("requestMap:" + requestMap);
			// 发送方帐号（open_id）
			String fromUserName = requestMap.get("FromUserName");
			// 公众帐号
			String toUserName = requestMap.get("ToUserName");
			// 消息类型
			String msgType = requestMap.get("MsgType");
			// 消息内容
			String msgContent = requestMap.get("Content");

			// 回复文本消息
			TextMessage textMessage = new TextMessage();
			textMessage.setToUserName(fromUserName);
			textMessage.setFromUserName(toUserName);
			textMessage.setCreateTime(new Date().getTime());
			textMessage.setMsgType(MessageUtil.RESP_MESSAGE_TYPE_TEXT);
			textMessage.setFuncFlag(0);

			// 文本消息
			if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_TEXT)) {
				List<Article> articleList = new ArrayList<Article>();
				NewsMessage newsMessage = new NewsMessage();
				newsMessage.setToUserName(fromUserName);
				newsMessage.setFromUserName(toUserName);
				newsMessage.setCreateTime(new Date().getTime());
				newsMessage.setMsgType(MessageUtil.RESP_MESSAGE_TYPE_NEWS);
				newsMessage.setFuncFlag(0);
				if (msgContent.contains("傻逼") || msgContent.contains("煞笔")
						|| msgContent.toUpperCase().contains("SB")) {
					respContent = "文明用语哦~";
					textMessage.setContent(respContent);
					respMessage = MessageUtil.textMessageToXml(textMessage);
				} else if (msgContent.trim().equals("?")
						|| msgContent.trim().equals("？")) {
					respContent = getMainMenu(2);
					textMessage.setContent(respContent);
					respMessage = MessageUtil.textMessageToXml(textMessage);
				} else if (msgContent.trim().equals("1")) { // 家长端
					// respMessage = MessageUtil.initImageMessage(toUserName,
					// fromUserName,1);
					respContent = "<a href=\"http://a.app.qq.com/o/simple.jsp?pkgname=com.kidmate.parent\">点击下载家长端</a>";
					textMessage.setContent(respContent);
					respMessage = MessageUtil.textMessageToXml(textMessage);
				} else if (msgContent.trim().equals("2")) { // 儿童端下载图片
					respMessage = MessageUtil.initImageMessage(toUserName,
							fromUserName, 2);
				} else if (msgContent.trim().equals("3")) { // 使用帮助
					respContent = "<a href=\"http://www.kidmate.cn/help.html\">服务与帮助</a>";
					textMessage.setContent(respContent);
					respMessage = MessageUtil.textMessageToXml(textMessage);
				}
				// else if(msgContent.trim().equals("4")){ //关键字
				// respContent = getKeyWordList();
				// }
				else {
					System.out.println("keyword==0==" + msgContent.trim());
					if (doReplyTextKeyword(msgContent.trim()) != null) {
						respContent = doReplyTextKeyword(msgContent.trim());
						System.out.println("keyword==1==");
					}
					textMessage.setContent(respContent);
					respMessage = MessageUtil.textMessageToXml(textMessage);
				}
				// else if(msgContent.trim().equals("3")){ //使用帮助
				// Article article = new Article();
				// article.setTitle("苗苗帮助手册");
				// // 图文消息中可以使用QQ表情、符号表情
				// article.setDescription("一、绑定儿童端与解绑\n……\n\n二、儿童端自启动设置\n……\n\n三、常见问题\n……");
				// // 将图片置为空
				// article.setPicUrl("http://0.xiaoqrobot.duapp.com/images/avatar_liufeng.jpg");
				// article.setUrl("http://www.kidmate.cn/help.html");
				// articleList.add(article);
				// newsMessage.setArticleCount(articleList.size());
				// newsMessage.setArticles(articleList);
				// respMessage = MessageUtil.newsMessageToXml(newsMessage);
				// }
				// else if(msgContent.trim().equals("6")){ //6 视频消息
				// respMessage = MessageUtil.initVideoMessage(toUserName,
				// fromUserName);
				// }
				// else if(msgContent.trim().equals("7")){//7 语音消息
				// respMessage = MessageUtil.initVoiceMessage(toUserName,
				// fromUserName);
				//
				// }
				// else if(msgContent.trim().equals("8")){//8 音乐消息
				// respContent = "音乐消息";
				// textMessage.setContent(respContent);
				// respMessage = MessageUtil.textMessageToXml(textMessage);
				// }
				// else{
				// respContent = "发送“？”得到更多帮助哦~";
				// textMessage.setContent(respContent);
				// respMessage = MessageUtil.textMessageToXml(textMessage);
				// }
			}
			// 图片消息
			else if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_IMAGE)) {
				textMessage.setContent(respContent);
				respMessage = MessageUtil.textMessageToXml(textMessage);
			}
			// 地理位置消息
			else if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_LOCATION)) {
				textMessage.setContent(respContent);
				respMessage = MessageUtil.textMessageToXml(textMessage);
			}
			// 链接消息
			else if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_LINK)) {
				textMessage.setContent(respContent);
				respMessage = MessageUtil.textMessageToXml(textMessage);
			}
			// 音频消息
			else if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_VOICE)) {
				textMessage.setContent(respContent);
				respMessage = MessageUtil.textMessageToXml(textMessage);
			}
			// 事件推送
			else if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_EVENT)) {
				// 事件类型
				String eventType = requestMap.get("Event");
				// 订阅
				if (eventType.equals(MessageUtil.EVENT_TYPE_SUBSCRIBE)) {
					System.out.println("requestMap-subscribe-"+requestMap);
					if(!StringUtils.isEmpty(requestMap.get("Ticket"))){
						String ticket = requestMap.get("Ticket");
						String openid = requestMap.get("FromUserName");
						String sceneid = requestMap.get("EventKey");
						System.out.println("ticket-subscribe-"+ticket);
						JSONObject userInfo = getUserInfoByOpenId(openid);
						System.out.println("userInfo--subscribe-"+userInfo.toString());
						String unionid = (String) userInfo.get("unionid");
						if (config.isDevelop() && StringUtils.isEmpty(unionid)) {
							unionid = "oqsSYxNPU-Ds-vAIrAwMKfq8uvq8";
						}
						if (!StringUtils.isEmpty(sceneid) && !StringUtils.isEmpty(unionid)) {
							//
							if(sceneid.startsWith("qrscene_")){
								sceneid = sceneid.replace("qrscene_", "");
							}
							KmParent instance = null;
							List<KmParent> parents = kmParentDAO.findByWxopenid(unionid);
							long timestamp = System.currentTimeMillis();
							String ip = MyUtils.getRemoteHost(request);
							if (parents != null && parents.size() > 0) {
								instance = parents.get(0);
								if(StringUtils.isEmpty(instance.getChannel())){
//									instance.setLastlogintime(new Date(timestamp));
									instance.setLastloginip(ip);
//									instance.setOpenaccountid(String.valueOf(instance.getId()));
//									instance.setStatus("1");
									instance.setChannel(sceneid);
									kmParentDAO.attachDirty(instance);
								}
							} else {
								instance = new KmParent();
								instance.setWxopenid(unionid);
								instance.setLastlogintime(new Date(timestamp));
								instance.setRegip(ip);
								instance.setSourceid(3000L);
								instance.setRegtime(new Date(timestamp));
								instance.setStatus("1");
								instance.setLastloginip(ip);
								Calendar cal = Calendar.getInstance();
								// 新注册用户，赠送7天VIP
								cal.setTime(new Date());
								cal.add(Calendar.DATE, 7);
								instance.setVip(cal.getTime());
								instance.setChannel(sceneid);
								kmParentDAO.save(instance);
								if (instance.getId() != null) {
									instance.setOpenaccountid(String
											.valueOf(instance.getId()));
								} else {
									instance.setOpenaccountid("0");
								}
								kmParentDAO.attachDirty(instance);
							}
						} else {
							System.out.println("---unionid--获取不到-");
						}
					}
					respContent = getMainMenu(1);
					textMessage.setContent(respContent);
					respMessage = MessageUtil.textMessageToXml(textMessage);
				}
				else if (eventType.equals(MessageUtil.EVENT_TYPE_SCAN)) {
//					if(config.isDevelop()){
//						System.out.println("requestMap-scan-"+requestMap);
//						String ticket = requestMap.get("Ticket");
//						System.out.println("ticket-scan-"+ticket);
//						respContent = "已经关注，扫描进入";
//						String openid = requestMap.get("FromUserName");
//						String sceneid = requestMap.get("EventKey");
//						System.out.println("ticket-subscribe-"+ticket);
//						JSONObject userInfo = getUserInfoByOpenId(openid);
//						System.out.println("userInfo-scan--"+userInfo.toString());
//						textMessage.setContent(respContent);
//						respMessage = MessageUtil.textMessageToXml(textMessage);
//					} else {
						textMessage.setContent(getMainMenu(2));
						respMessage = MessageUtil.textMessageToXml(textMessage);
//					}
					
				}
				// 取消订阅
				else if (eventType.equals(MessageUtil.EVENT_TYPE_UNSUBSCRIBE)) {
					// TODO 取消订阅后用户再收不到公众号发送的消息，因此不需要回复消息
					if(config.isDevelop()){
						String openid = requestMap.get("FromUserName");
						logger.info("-----取消订阅:" + openid);
					}
				}
				// 自定义菜单点击事件
				else if (eventType.equals(MessageUtil.EVENT_TYPE_CLICK)) {
					// TODO 自定义菜单权没有开放，暂不处理该类消息
					String eventKey = requestMap.get("EventKey");
					int key = Integer.parseInt(eventKey);
					System.out.println("key=" + key);
					switch (key) {
					case 1021:
						respMessage = MessageUtil.initImageMessage(toUserName,
								fromUserName, 1);
						break;
					case 1022:
						respMessage = MessageUtil.initImageMessage(toUserName,
								fromUserName, 2);
						break;

					default:
						break;
					}
				}
				// textMessage.setContent(respContent);
				// respMessage = MessageUtil.textMessageToXml(textMessage);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		logger.info("--返回消息：----\n" + respMessage);
		return respMessage;
	}

	/**
	 * xiaoqrobot的主菜单
	 * 
	 * @return
	 */
	@Override
	public String getMainMenu(int type) {
		StringBuffer buffer = new StringBuffer();
		buffer.append(
				"您好，亲爱的家长，欢迎" + (type == 1 ? "关注" : "使用")
						+ "“苗苗”!\n您可以点击菜单选择服务，或者回复数字选择服务：").append("\n\n");
		buffer.append("1  家长端APP下载").append("\n");
		buffer.append("2 儿童端APP下载").append("\n");
		buffer.append("3 <a href=\"http://www.kidmate.cn/help.html\">服务与帮助</a>")
				.append("\n");
		// buffer.append("4 更多").append("\n");
		buffer.append("\n");
		buffer.append("回复“?”显示此帮助菜单");
		return buffer.toString();
	}

	/**
	 * emoji表情转换(hex -> utf-16)
	 * 
	 * @param hexEmoji
	 * @return
	 */
	public String emoji(int hexEmoji) {
		return String.valueOf(Character.toChars(hexEmoji));
	}
	/**
	 * 关键字回复
	 * @param keyword
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@Override
	public String doReplyTextKeyword(String keyword) throws UnsupportedEncodingException {
		// KmWxKeyReply instance = new KmWxKeyReply();
		System.err.println("doReplyTextKeyword====0");
		String reply = null;
		ShardedJedis shardedJedis = shardedJedisPool.getResource();// 清除缓存
		if (shardedJedis.hexists(KMWX_KEYWORD, keyword)) {
			System.err.println("doReplyTextKeyword====1");
			System.out.println("1=="
					+ new String(shardedJedis.hget(KMWX_KEYWORD, keyword)
							.getBytes("UTF-8"), "UTF-8"));
			reply = new String(shardedJedis.hget(KMWX_KEYWORD, keyword)
					.getBytes("UTF-8"), "UTF-8");
			shardedJedisPool.returnResource(shardedJedis);
			return reply;
		} else {
			List<KmWxKeyReply> list = kmWxKeyReplyDAO.findAll();
			for (KmWxKeyReply kmWxKeyReply : list) {
				if (keyword.contains(kmWxKeyReply.getKeyword())
						&& "1".equals(kmWxKeyReply.getStatus())) {
					shardedJedis.hset(KMWX_KEYWORD, kmWxKeyReply.getKeyword(),
							kmWxKeyReply.getContent());
					// shardedJedisPool.returnResource(shardedJedis);
					System.out.println("2=="
							+ new String(kmWxKeyReply.getContent().getBytes(
									"UTF-8"), "UTF-8"));
					reply = new String(kmWxKeyReply.getContent().getBytes(
							"UTF-8"), "UTF-8");
				}
			}
		}

		System.err.println("doReplyTextKeyword====3");
		shardedJedisPool.returnResource(shardedJedis);
		return reply;
	}
	/**
	 * 关键字回复
	 * @return
	 */
	@Override
	public String getKeyWordList() {
		List<KmWxKeyReply> list = kmWxKeyReplyDAO.findAll();
		HashMap<Long, String> keyMap = new HashMap<Long, String>();
		StringBuffer buffer = new StringBuffer();
		buffer.append("您好，亲爱的家长，欢迎使用“苗苗”!\n您可以回复数字或关键字选择内容：").append("\n\n");
		for (KmWxKeyReply item : list) {
			keyMap.put(item.getId(), item.getContent());
			buffer.append(item.getId() + " " + item.getKeyword()).append("\n");
		}
		buffer.append("\n");
		return buffer.toString();
	}

	/**
	 * 判断字符是否为数字
	 * 
	 * @author san
	 * @param str
	 * @return boolean
	 */
	public boolean isNumeric(String str) {
		Pattern pattern = Pattern.compile("[0-9]*");
		Matcher isNum = pattern.matcher(str);
		if (!isNum.matches()) {
			return false;
		}
		return true;
	}

	/**
	 * 
	 * @param sceneId
	 * @param type
	 * @return
	 */
	@Override
	public JSONObject getSubscribeQrcodeBySource(String sceneId, int type) {
		if (type == 1) {
			return getPersistentQrcode(sceneId);
		}else {
			return getTempQrcode(sceneId);	
		}
	}

	/**
	 * 获取临时二维码
	 * 
	 * @param sceneId
	 * @return
	 */
	private JSONObject getTempQrcode(String sceneId) {
		Map<String, Object> param = new HashMap<String, Object>();
		Map<String, Object> action_info = new HashMap<String, Object>();
		Map<String, Object> scene = new HashMap<String, Object>();
		// {"expire_seconds": 604800, "action_name": "QR_SCENE", "action_info":
		// {"scene": {"scene_id": 123}}}
		param.put("expire_seconds", "604800");
		param.put("action_name", "QR_SCENE");
		scene.put("scene_id", sceneId);
		action_info.put("scene", scene);
		param.put("action_info", action_info);
		JSONObject ticket = getTicket(JSONObject.fromObject(param).toString(), wxConfigService.getAccessToken().getToken());
		System.out.println("=----getPersistentQrcode---");
		System.out.println(ticket.toString());
		return ticket;
	}

	/**
	 * 获取持久二维码
	 * 
	 * @param sceneId
	 * @return
	 */
	private JSONObject getPersistentQrcode(String sceneId) {
		Map<String, Object> param = new HashMap<String, Object>();
		Map<String, Object> action_info = new HashMap<String, Object>();
		Map<String, Object> scene = new HashMap<String, Object>();
		// {"action_name": "QR_LIMIT_STR_SCENE", "action_info": {"scene": {"scene_str": "123"}}}
		param.put("action_name", "QR_LIMIT_STR_SCENE");
		scene.put("scene_str", sceneId);
		action_info.put("scene", scene);
		param.put("action_info", action_info);
		System.out.println("param:" + JSONObject.fromObject(param).toString());
		JSONObject ticket = getTicket(JSONObject.fromObject(param).toString(), wxConfigService.getAccessToken().getToken());
		System.out.println("=----getPersistentQrcode---");
		System.out.println(ticket.toString());
		return ticket;
	}

	/**
	 * 获取Ticket
	 * @param param
	 * @param accessToken
	 * @return
	 */
	private JSONObject getTicket(String param, String accessToken) {
		// url
		String url = QR_CODE_URL.replace("TOKEN", accessToken);
		JSONObject jsonObject = WeixinUtil.httpRequest(url, "POST", param);
		if (null != jsonObject) {
			if(!jsonObject.containsKey("errcode")){
				return jsonObject;
			}
		}

		return jsonObject;
	}
	
	private JSONObject getUserInfoByOpenId(String openid){
//		Map<String, Object> param = new HashMap<String, Object>();
//		param.put("access_token", wxConfigService.getAccessToken().getToken());
//		param.put("openid", openid);
//		param.put("lang", "zh_CN");
//		https://api.weixin.qq.com/cgi-bin/user/info?access_token=ACCESS_TOKEN&openid=OPENID&lang=zh_CN
		String url = USERINFO_URL.replace("ACCESS_TOKEN", wxConfigService.getAccessToken().getToken()).replace("OPENID", openid);
		JSONObject jsonObject = WeixinUtil.httpRequest(url, "GET", null);
		if (null != jsonObject) {
			if(!jsonObject.containsKey("errcode")){
				return jsonObject;
			}
		}
		return jsonObject;
	}
}
