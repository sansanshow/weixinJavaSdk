package com.kidmate.wx.service;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;

import net.sf.json.JSONObject;

public interface ICoreService {

	JSONObject getSubscribeQrcodeBySource(String sceneId, int type);

	String getKeyWordList();

	String doReplyTextKeyword(String keyword) throws UnsupportedEncodingException;

	String getMainMenu(int type);

	String processRequest(HttpServletRequest request);

}
