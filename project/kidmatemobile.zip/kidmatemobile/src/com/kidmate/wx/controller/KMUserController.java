package com.kidmate.wx.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.apache.thrift.TException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.kidmate.kmservice.TKmAppUsage;
import com.kidmate.kmservice.TKmChild;
import com.kidmate.kmservice.TKmEquipment;
import com.kidmate.kmservice.TKmException;
import com.kidmate.kmservice.TKmUser;
import com.kidmate.model.KmParentDAO;
import com.kidmate.model.KmRss;
import com.kidmate.service.impl.ParentServiceImpl;
import com.kidmate.tools.SecurityUtils;
import com.kidmate.wx.model.LoginSuccessInfo;
import com.kidmate.wx.pojo.ReturnValue;
import com.kidmate.wx.pojo.RetMsg;
import com.kidmate.wx.service.IUserService;
import com.kidmate.wx.utils.WeixinConfig;
import com.kidmate.wx.utils.MD5Utils;
import com.kidmate.wx.utils.MyUtils;
import com.kidmate.wx.utils.WeixinUtil;

//@RequestMapping(value = "/user")
@Controller
public class KMUserController {
	private static Logger logger = LoggerFactory
			.getLogger(KMUserController.class);
	@Autowired
	@Resource(name = "wxconfig")
	private WeixinConfig config;
	@Autowired
	@Qualifier("UserService")
	private IUserService userService;

	@Resource(name = "ParentServiceImpl")
	private ParentServiceImpl parentServiceImpl;
	@Resource(name = "KmParentDAO")
	private KmParentDAO kmParentDAO;

	@RequestMapping(value = "/judge.wx")
	public void judge(@RequestParam(value = "code") String code,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		ReturnValue result = new ReturnValue();
		result.setStatus(200);
		System.err.println("code--" + code);
		JSONObject token_info = WeixinUtil.getAccessTokenByCode(
				config.getAppid(), config.getAppsecret(), code);
		if (token_info.containsKey("errcode")) { // 如果包含errcode，说明该接口调用失败
			logger.info("----openid error----:" + token_info);
		} else {

		}
		String openid = token_info.getString("openid");
		String access_token = token_info.getString("access_token");
		TKmUser user = userService.login(openid, access_token,
				MyUtils.getRemoteHost(request));
		result.setOpenid(openid);
		try {
			if (user != null && user.getUserid() > 0) {
				List<TKmEquipment> equipments = userService
						.getAllEquipment(user);
				// 模拟绑定流程
				// equipments=new ArrayList<TKmEquipment>();
				logger.info("equipments:" + equipments);
				result.setUser(user);
				if (equipments != null && equipments.size() > 0) {
					// 已将绑定，返回首页
					result.setType(100);
					result.setContent(equipments.size());
				} else {
					List<TKmChild> childs = userService.getChildList(user);
					logger.info("childs:" + childs);
					if (childs != null && childs.size() > 0) {
						// 扫码绑定
						result.setType(101);
						result.setContent(JSONObject.fromObject(childs.get(0))
								.toString());
						result.setExtras(0);
					} else {
						// 添加孩子
						result.setType(102);
					}
				}
			} else {
				result.setType(103);
			}
		} catch (TException e) {
			e.printStackTrace();
			result.setStatus(400);
		}
		PrintWriter out = response.getWriter();
		logger.info("ret:" + JSONObject.fromObject(result).toString());
		out.print(JSONObject.fromObject(result).toString());
		out.close();
		out = null;
	}

	/**
	 * 菜单-登陆
	 * 
	 * @author san
	 */
	@RequestMapping(value = "/login11111.wx")
	public ModelAndView login(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		logger.info("---/user/login.do---");
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String code = request.getParameter("code");
		JSONObject token_info = WeixinUtil.getAccessTokenByCode(
				config.getAppid(), config.getAppsecret(), code);
		logger.info("--token_info-:" + token_info);
		TKmUser user = userService.login(token_info.getString("openid"),
				token_info.getString("access_token"),
				MyUtils.getRemoteHost(request));
		String openid = token_info.getString("openid");
		mv.addObject("user_openid", token_info.getString("openid"));
		if (user != null && user.getUserid() > 0) {
			mv.addObject("user", user);
			mv.addObject("openid", openid);
			request.getSession().setAttribute("user", user);
			request.getSession().setAttribute("openid", openid);
			mv.setViewName("redirect:/weixin/user/login_success.wx");
		} else {
			mv.setViewName("login");
		}
		return mv;
	}

	/**
	 * 登陆成功后的跳转
	 * 
	 * @author san
	 */
	@RequestMapping(value = "/login_success.wx")
	public ModelAndView login_success(@ModelAttribute("user") TKmUser user,
			HttpServletRequest request, HttpServletResponse response,
			Model model) throws IOException {
		ModelAndView mv = new ModelAndView();
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		user = (TKmUser) request.getSession().getAttribute("user");
		String openid = (String) request.getSession().getAttribute("openid");
		logger.info("-------login_success-------");
		logger.info("user:" + user);
		request.getSession().setAttribute("user", user);
		request.getSession().setAttribute("openid", openid);
		mv.addObject("user", user);
		try {
			List<TKmEquipment> equipments = userService.getAllEquipment(user);
			// 模拟绑定流程
			// equipments=new ArrayList<TKmEquipment>();
			logger.info("equipments:" + equipments);
			if (equipments != null && equipments.size() > 0) {
				// 已将绑定，返回首页
				mv.setViewName("redirect:/weixin/user/index.wx");
			} else {
				List<TKmChild> childs = userService.getChildList(user);
				logger.info("childs:" + childs);
				if (childs != null && childs.size() > 0) {
					// 扫码绑定
					model.addAttribute("parentId", user.getUserid());
					model.addAttribute("childId", childs.get(0).getId());
					model.addAttribute("token", user.getSign());
					mv.addObject("childs", childs);
					mv.setViewName("redirect:/weixin/user/qrcode.wx");
					// mv.setViewName("qrcode");
				} else {
					// 添加孩子
					mv.setViewName("add_child");
				}
			}
		} catch (TException e) {
			e.printStackTrace();
		}
		return mv;
	}

	/**
	 * 绑定手机号
	 * 
	 * @author san
	 */
	@RequestMapping(value = "/bind.wx")
	public void bind(@RequestParam(value = "mobile") String mobile,
			@RequestParam(value = "verifycode") String code,
			@RequestParam(value = "function") String function,
			@RequestParam(value = "openid") String openid,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		logger.info("--------bind.wx-----------");
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		ReturnValue result = new ReturnValue();
		result.setStatus(400);
		PrintWriter out = response.getWriter();
		TKmUser user = null;
		// ret_obj.setStatus("error");
		if (userService.checkVerifyCode(mobile, openid, code, function) > 0) {
			logger.info("------checkVerifyCode--ok--------");
			user = userService.bindMobile(mobile, openid,
					MyUtils.getRemoteHost(request));
			if (user != null && user.getUserid() >= 0) {
				result.setStatus(200);
				try {
					List<TKmEquipment> equipments = userService
							.getAllEquipment(user);
					// 模拟绑定流程
					// equipments=new ArrayList<TKmEquipment>();
					logger.info("equipments:" + equipments);
					result.setUser(user);
					if (equipments != null && equipments.size() > 0) {
						// 已将绑定，返回首页
						result.setType(100);
					} else {
						List<TKmChild> childs = userService.getChildList(user);
						logger.info("childs:" + childs);
						if (childs != null && childs.size() > 0) {
							// 扫码绑定
							result.setType(101);
							result.setContent(JSONObject.fromObject(
									childs.get(0)).toString());
						} else {
							// 添加孩子
							result.setType(102);
						}
					}
				} catch (TKmException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (TException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		out.print(JSONObject.fromObject(result).toString());
		out.close();
		out = null;
	}

	/**
	 * 发送验证码
	 * 
	 * @author san
	 */
	@RequestMapping(value = "/sendsms.wx")
	public void doSendSMS(@RequestParam(value = "mobile") String mobile,
			@RequestParam(value = "function") String func,
			@RequestParam(value = "openid") String openid,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		logger.info("---------sendsms.wx----------");
		userService.doSendVerifyCode(mobile, openid, func);
		PrintWriter out = response.getWriter();
		RetMsg ret_obj = new RetMsg();
		ret_obj.setStatus("success");
		ret_obj.setContent("123456");
		out.print(JSONObject.fromObject(ret_obj).toString());
		out.close();
		out = null;
	}

	@RequestMapping(value = "/index.wx")
	public ModelAndView index(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		logger.info("------index-----");
		ModelAndView mv = new ModelAndView();
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		TKmUser user = (TKmUser) request.getSession().getAttribute("user");
		String openid = (String) request.getSession().getAttribute("openid");
		mv.addObject("user", user);
		mv.addObject("openid", openid);
		mv.setViewName("index");
		return mv;
	}

	@RequestMapping(value = "/equipment_get.wx")
	public void getEquips(@RequestParam(value = "userid") long userid,
			@RequestParam(value = "sign") String sign,
			@RequestParam(value = "openid") String openid,
			HttpServletRequest request, HttpServletResponse response) {
		logger.info("------equipment_get-----");
		PrintWriter out = null;
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			TKmUser user = new TKmUser();
			user.setUserid(userid);
			user.setSign(sign);
			List<TKmEquipment> equipments = userService.getAllEquipment(user);
			RetMsg ret_obj = new RetMsg();
			ret_obj.setStatus("success");
			ret_obj.setContent(equipments);
			out.print(JSONObject.fromObject(ret_obj).toString());
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TKmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		out.close();
		out = null;
	}

	@RequestMapping(value = "/history.wx")
	public void history(@RequestParam(value = "userid") long userId,
			@RequestParam(value = "sign") String sign,
			@RequestParam(value = "equipid") long equipId,
			HttpServletRequest request, HttpServletResponse response) {
		logger.info("------history-----");
		PrintWriter out = null;
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			TKmUser user = new TKmUser();
			user.setUserid(userId);
			long timestamp = System.currentTimeMillis();
			// MD5Utils.md5ByHex4Sign(getLoginUserToken(),user.sign, timestamp)
			logger.info("--sign--:" + sign);
			String token = SecurityUtils.md5ByHex(SecurityUtils.md5ByHex(sign)
					+ sign + (timestamp << 5));
			System.err.println("token:" + token);
			user.setSign(token);
			// String md5Str = md5ByHex(authToken) + sign + (timestamp << 5);
			// return md5ByHex(md5Str);
			user.setTimestamp(timestamp);
			user.setVer("1.5");

			logger.info("--user--:" + user);
			logger.info("--equip--" + equipId);
			List<TKmAppUsage> appUsages = parentServiceImpl
					.getEquipmentAppUsageStatistics(user, equipId, 1, 10, 1);
			RetMsg ret_obj = new RetMsg();
			ret_obj.setStatus("success");
			ret_obj.setContent(appUsages);
			out.print(JSONObject.fromObject(ret_obj).toString());
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TKmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		out.close();
		out = null;
	}

	/************************* 新版流程 *************************************/
	/**
	 * 微信登陆
	 * 
	 * @author san
	 * @throws IOException
	 *             void
	 */
	@RequestMapping(value = "/user/login.wx", method = RequestMethod.POST)
	public void login_wx(@RequestParam(value = "code") String code,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		ReturnValue result = new ReturnValue();
		// logger.info("---new---login--");
		result.setStatus(200);
		TKmUser kmUser = new TKmUser();
		logger.info("config.isDevelop()--" + config.isDevelop());
		String ip = MyUtils.getRemoteHost(request);
		if (!StringUtils.isEmpty(code)) {
			JSONObject token_info = WeixinUtil.getAccessTokenByCode(
					config.getAppid(), config.getAppsecret(), code);
			// logger.info("---token_info---"+token_info);
			if (token_info.containsKey("errcode")) { // 如果包含errcode，说明该接口调用失败
				logger.info("----openid error----:" + token_info);
				result.setStatus(400);
			} else {
				String openid = token_info.getString("openid");
				String access_token = token_info.getString("access_token");
				JSONObject userinfo = WeixinUtil.getUserInfoByToken(
						access_token, openid);
				result.setOpenid(openid);
				LoginSuccessInfo info = new LoginSuccessInfo(
						MD5Utils.md5ByHex(access_token));
				result.setContent(info);
				String unionid = (String) userinfo.get("unionid");
				kmUser = userService.loginWx(access_token, openid, unionid,
						config.getSource(), ip);
			}
			if (kmUser != null && kmUser.getUserid() > 0) {
				// try {
				// long viptime = parentServiceImpl.getVipTime(kmUser);
				// } catch (TException e) {
				// e.printStackTrace();
				// }
				result.setExtras(JSONObject.fromObject(kmUser).toString());
				result.setUser(kmUser);
			} else {
				result.setStatus(400);
			}
		} else {
			result.setStatus(400);
		}
		PrintWriter out = response.getWriter();
		logger.info("ret:" + JSONObject.fromObject(result).toString());
		out.print(JSONObject.fromObject(result).toString());
		out.close();
		out = null;
	}
	

	@RequestMapping(value = "/{source}/user/test.wx/{codedec}", method = RequestMethod.POST)
	public void login_wx_xcx_test(@PathVariable(value = "source") int source,
			@RequestParam(value = "code", required=false) String code,
			@PathVariable(value = "codedec") String codedec,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String ip = MyUtils.getRemoteHost(request);
		String signature=null,iv=null,encryptedData=null;
		
		if(source==2000)
		{
			System.out.println("-------source----");
			System.out.println(source);
			System.out.println("-------codedec----");
			System.out.println(codedec);
			System.out.println("-------code----");
			System.out.println(code);
			signature=request.getParameter("signature");
			iv=request.getParameter("iv");
			encryptedData =request.getParameter("encryptedData");
			System.out.println("-------signature----");
			System.out.println(signature);
			System.out.println("-------encryptedData----");
			System.out.println(encryptedData);
			System.out.println("-------iv----");
			System.out.println(iv);
		}
		String result="{}";
		PrintWriter out = response.getWriter();
		logger.info("source-ret:" + JSONObject.fromObject(result).toString());
		out.print(JSONObject.fromObject(result).toString());
		out.close();
		out = null;
	}

	@RequestMapping(value = "/user/vip.wx", method = RequestMethod.POST)
	public void getUserInfo(@RequestParam(value = "code") String code,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		ReturnValue result = new ReturnValue();
		// logger.info("---new---login--");
		result.setStatus(200);
		TKmUser kmUser = new TKmUser();
		logger.info("config.isDevelop()--" + config.isDevelop());
		try {
			long viptime = parentServiceImpl.getVipTime(kmUser);
		} catch (TException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		PrintWriter out = response.getWriter();
		logger.info("ret:" + JSONObject.fromObject(result).toString());
		out.print(JSONObject.fromObject(result).toString());
		out.close();
		out = null;
	}

	@RequestMapping(value = "/user/rss.wx", method = RequestMethod.POST)
	public void getNewsList(@RequestParam(value = "userid") long userid,
			@RequestParam(value = "sign") String sign,
			@RequestParam(value = "authToken") String authToken,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		ReturnValue result = new ReturnValue();
		result.setStatus(200);
		logger.info("---------getNewsList--------");
		TKmUser user = MD5Utils.signUser(userid, sign, authToken,
				config.getVersion());
//		List<KmRss> newList = parentServiceImpl.getKmRss(user, 100);
//		result.setContent(newList);
		logger.info("ret:" + JSONObject.fromObject(result).toString());
		PrintWriter out = response.getWriter();
		out.print(JSONObject.fromObject(result).toString());
		out.close();
		out = null;

	}
}
