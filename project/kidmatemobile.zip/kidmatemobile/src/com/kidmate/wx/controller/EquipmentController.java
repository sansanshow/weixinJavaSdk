package com.kidmate.wx.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.apache.thrift.TException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kidmate.kmservice.TKmAppInfo;
import com.kidmate.kmservice.TKmControlRuleInfo;
import com.kidmate.kmservice.TKmEquipment;
import com.kidmate.kmservice.TKmException;
import com.kidmate.kmservice.TKmPosition;
import com.kidmate.kmservice.TKmSnapshot;
import com.kidmate.kmservice.TKmUser;
import com.kidmate.service.impl.ParentServiceImpl;
import com.kidmate.wx.model.AllowApp;
import com.kidmate.wx.model.ControlRuleInfo;
import com.kidmate.wx.model.EquipDetail;
import com.kidmate.wx.model.History;
import com.kidmate.wx.model.Snapshot;
import com.kidmate.wx.pojo.ReturnValue;
import com.kidmate.wx.service.IWxEquipmentService;
import com.kidmate.wx.utils.MD5Utils;
import com.kidmate.wx.utils.MyUtils;
import com.kidmate.wx.utils.WeixinConfig;

/**
 * 设备相关
 * 
 * @author Keaven 功能： 1：获取设备信息、列表； 2：定位查看： 3：今日情况； 4：锁屏、5：初始化锁屏； 6：获取时段控制规则列表；
 *         7：打开/关闭 规则（时段控制）； 8：保存规则 ； 9：获取允许使用的列表； 10：删除设备 ； 11：截屏； 12：截屏列表
 */
@Controller
@RequestMapping(value = "/equip")
public class EquipmentController {
	private static Logger logger = LoggerFactory
			.getLogger(EquipmentController.class);
	@Autowired
	@Resource(name = "wxconfig")
	private WeixinConfig wxconfig;
	@Resource(name = "ParentServiceImpl")
	private ParentServiceImpl parentServiceImpl;

	@Resource(name = "EquipmentService")
	private IWxEquipmentService equipmentService;

	/**
	 * 微信服务号接口
	 * @author san
	 * @param method
	 *            ：1：get 获取所有设备；2：detail 设置页面的设备列表；3：EQUIPNUM 设备数量
	 */
	@RequestMapping(value = "/equipment.wx/{method}")
	public void getEquips(@PathVariable(value = "method") String method,
			@RequestParam(value = "userid") long userid,
			@RequestParam(value = "sign") String sign,
			@RequestParam(value = "authToken") String authToken,
			HttpServletRequest request, HttpServletResponse response) {
		logger.info("------equipment_get-----");
		PrintWriter out = null;
		ReturnValue ret_obj = new ReturnValue();
		ret_obj.setStatus(200);
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			// logger.info("userid:"+userid+",sign:"+sign+",token:"+authToken);
			TKmUser user = MD5Utils.signUser(userid, sign, authToken,
					wxconfig.getVersion());
			// logger.info("equip-user-"+user);
			if ("GET".equals(method.toUpperCase())) {
				// logger.info("equip----1");
				List<TKmEquipment> equipments = parentServiceImpl
						.getAllEquipment(user);
				ret_obj.setContent(equipments);

			} else if ("DETAIL".equals(method.toUpperCase())) {
				List<EquipDetail> equipDetails = equipmentService
						.getAllEquipmentDetail(user);
				ret_obj.setContent(equipDetails);
			} else if ("EQUIPNUM".equals(method.toUpperCase())) {
				List<TKmEquipment> equipments = parentServiceImpl
						.getAllEquipment(user);
				ret_obj.setContent(equipments.size());
			} else if ("DELETE".equals(method.toUpperCase())) {
				String e_ID_str = request.getParameter("equipId");
				logger.info("Equip_id-Str:" + e_ID_str);
				long e_id = Long.parseLong(e_ID_str);
				logger.info("Equip_id:" + e_id);
				boolean success = parentServiceImpl.delEquipment(user, e_id);
				if (success) {
					// List<TKmEquipment> equipments = parentServiceImpl
					// .getAllEquipment(user);
					ret_obj.setContent(200);
				} else {
					ret_obj.setContent(400);
				}
			} else {
				// logger.info("equip----2");
				ret_obj.setStatus(400);
			}
			// logger.info("equip--ret:"+JSONObject.fromObject(ret_obj).toString());
			out.print(JSONObject.fromObject(ret_obj).toString());
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (IOException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (TKmException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (TException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		}
		out.close();
		out = null;
	}
	
	/**
	 * 定位查看
	 * 
	 * @author san
	 */
	@RequestMapping(value = "/location.wx/{equipid}")
	public void getPosition(@RequestParam(value = "userid") long userid,
			@RequestParam(value = "sign") String sign,
			@RequestParam(value = "authToken") String authToken,
			@PathVariable(value = "equipid") long equipid,
			HttpServletRequest request, HttpServletResponse response) {
		logger.info("------location-----");
		// logger.info("------location----userid-"+userid+",sign:"+sign+",authToken:"+authToken+",equipid:"+equipid);
		PrintWriter out = null;
		ReturnValue ret_value = new ReturnValue();
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			TKmUser user = MD5Utils.signUser(userid, sign, authToken,
					wxconfig.getVersion());

			List<TKmPosition> positions = parentServiceImpl.getPositionList(
					user, equipid, 1, 10);

			if (positions != null && positions.size() > 0) {
				ret_value.setContent(positions.get(0));
				ret_value.setStatus(200);
			} else {
				ret_value.setStatus(400);
			}
			logger.info("loca-ret:"
					+ JSONObject.fromObject(ret_value).toString());
			out.print(JSONObject.fromObject(ret_value).toString());
		} catch (UnsupportedEncodingException e) {
			ret_value.setStatus(400);
			e.printStackTrace();
		} catch (IOException e) {
			ret_value.setStatus(400);
			e.printStackTrace();
		} catch (TKmException e) {
			ret_value.setStatus(400);
			e.printStackTrace();
		} catch (TException e) {
			ret_value.setStatus(400);
			e.printStackTrace();
		}
		out.close();
		out = null;
	}

	/**
	 * 今日情况
	 * 
	 * @author san
	 */
	@RequestMapping(value = "/appusage.wx/{equipid}/{page}/{size}/{type}", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	public void getEquipmentAppUsageStatistics(
			@RequestParam(value = "userid") long userid,
			@RequestParam(value = "sign") String sign,
			@RequestParam(value = "authToken") String authToken,
			@PathVariable(value = "equipid") long equipid,
			@PathVariable(value = "page") int page,
			@PathVariable(value = "size") int size,
			@PathVariable(value = "type") int type, HttpServletRequest request,
			HttpServletResponse response) {
		logger.info("------appusage-----" + equipid + ",page:" + page
				+ ",type:" + type);
		PrintWriter out = null;
		ReturnValue ret_obj = new ReturnValue();
		ret_obj.setStatus(200);
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			TKmUser user = MD5Utils.signUser(userid, sign, authToken,
					wxconfig.getVersion());

			List<History> histories = equipmentService.getEquipHistory(user,
					equipid, page, size, type);
			// logger.info("--histories---"+histories);

			ret_obj.setContent(histories);
			out.print(JSONObject.fromObject(ret_obj).toString());
		} catch (UnsupportedEncodingException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (IOException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (TKmException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (TException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		}
		out.close();
		out = null;
	}

	/**
	 * 锁屏
	 * 
	 * @author san
	 */
	@RequestMapping(value = "/lock.wx/{childid}/{equipid}/{lock}")
	public void lockScreen(@RequestParam(value = "userid") long userid,
			@RequestParam(value = "sign") String sign,
			@RequestParam(value = "authToken") String authToken,
			@PathVariable(value = "equipid") long equipid,
			@PathVariable(value = "childid") long childid,
			@PathVariable(value = "lock") int lock, HttpServletRequest request,
			HttpServletResponse response) {
		logger.info("----lockScreen----");
		PrintWriter out = null;
		ReturnValue ret_obj = new ReturnValue();
		ret_obj.setStatus(200);
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			TKmUser user = MD5Utils.signUser(userid, sign, authToken,
					wxconfig.getVersion());
			TKmControlRuleInfo controlrule = equipmentService.getLockRule(user,
					childid, equipid);
			logger.info("--lock-" + lock + ",before:" + controlrule);
			controlrule.setOn(lock == 1);
			controlrule = parentServiceImpl.saveControlRuleInfo(user,
					controlrule);
			logger.info("--lock-" + lock + ",after:" + controlrule);
			ret_obj.setContent(controlrule);
			out.print(JSONObject.fromObject(ret_obj).toString());
		} catch (UnsupportedEncodingException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (IOException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (TKmException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (TException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		}
		out.close();
		out = null;

	}

	/**
	 * 初始化 锁屏
	 * 
	 * @author san
	 */
	@RequestMapping(value = "/lock.wx/init/{childid}/{equipid}")
	public void initLockStatus(@RequestParam(value = "userid") long userid,
			@RequestParam(value = "sign") String sign,
			@RequestParam(value = "authToken") String authToken,
			@PathVariable(value = "equipid") long equipid,
			@PathVariable(value = "childid") long childid,
			HttpServletRequest request, HttpServletResponse response) {
		PrintWriter out = null;
		ReturnValue ret_obj = new ReturnValue();
		ret_obj.setStatus(200);
		try {
			logger.info("----initLockStatus----");
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			TKmUser user = MD5Utils.signUser(userid, sign, authToken,
					wxconfig.getVersion());
			TKmControlRuleInfo controlrule = equipmentService.getLockRule(user,
					childid, equipid);
			logger.info("----initLockStatus--controlrule--"
					+ controlrule);

			ret_obj.setContent(controlrule);
			out.print(JSONObject.fromObject(ret_obj).toString());
		} catch (UnsupportedEncodingException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (IOException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (TKmException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (TException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		}
		out.close();
		out = null;
	}

	/**
	 * 获取是否锁屏 un-use
	 * 
	 * @author san
	 * @param response
	 *            void
	 */
	@RequestMapping(value = "/lock.wx/status/{childid}/{equipid}")
	public void getLockState(@RequestParam(value = "userid") long userid,
			@RequestParam(value = "sign") String sign,
			@RequestParam(value = "authToken") String authToken,
			@PathVariable(value = "childid") long childid,
			@PathVariable(value = "equipid") long equipid,
			HttpServletRequest request, HttpServletResponse response) {
		logger.info("----getLockState----");
		PrintWriter out = null;
		ReturnValue ret_obj = new ReturnValue();
		ret_obj.setStatus(200);
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			TKmUser user = MD5Utils.signUser(userid, sign, authToken,
					wxconfig.getVersion());
			boolean success = parentServiceImpl.isEquipmentLocked(user,
					childid, equipid);
			ret_obj.setContent(success ? 1001 : 2001);
			out.print(JSONObject.fromObject(ret_obj).toString());
		} catch (UnsupportedEncodingException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (IOException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (TKmException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (TException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		}
		out.close();
		out = null;
	}

	/**
	 * 获取时段控制规则列表
	 * 
	 * @author san
	 * @param response
	 *            void
	 */
	@RequestMapping(value = "/rule.wx/get/{type}/{childid}/{equipid}")
	public void getControlRule(@RequestParam(value = "userid") long userid,
			@RequestParam(value = "sign") String sign,
			@RequestParam(value = "authToken") String authToken,
			@PathVariable(value = "type") int type,
			@PathVariable(value = "childid") long childid,
			@PathVariable(value = "equipid") long equipid,
			HttpServletRequest request, HttpServletResponse response) {
		logger.info("----getControlRule----");
		logger.info("----{type}:" + type + "{childid}:" + childid
				+ "{equipid}:" + equipid);
		PrintWriter out = null;
		ReturnValue ret_obj = new ReturnValue();
		ret_obj.setStatus(200);
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			if (type < 0) {
				ret_obj.setStatus(400);
			} else {
				TKmUser user = MD5Utils.signUser(userid, sign, authToken, wxconfig.getVersion());
				List<ControlRuleInfo> list = equipmentService.getControlRule(user, childid, equipid, type);
				ret_obj.setContent(list);
				
				
			}
			logger.info("ret---" + JSONObject.fromObject(ret_obj).toString());
			out.print(JSONObject.fromObject(ret_obj).toString());
		} catch (UnsupportedEncodingException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (IOException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (TKmException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (TException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		}
		out.close();
		out = null;
	}

	/**
	 * 打开/关闭 规则（时段控制） /rule.wx/RID/STATUS
	 * 
	 * @author san
	 * @param response
	 *            void
	 */
	@RequestMapping(value = "/rule.wx/status/{ruleid}/{status}")
	public void modifyStatus(@RequestParam(value = "userid") long userid,
			@RequestParam(value = "sign") String sign,
			@RequestParam(value = "authToken") String authToken,
			@PathVariable(value = "ruleid") long ruleid,
			@PathVariable(value = "status") int status,
			HttpServletRequest request, HttpServletResponse response) {
		logger.info("----modifyStatus----");
		PrintWriter out = null;
		ReturnValue ret_obj = new ReturnValue();
		ret_obj.setStatus(200);
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			TKmUser user = MD5Utils.signUser(userid, sign, authToken,
					wxconfig.getVersion());
			if (status == 1) {
				parentServiceImpl.setControlRuleInfoOn(user, ruleid);
			} else {
				parentServiceImpl.setControlRuleInfoOff(user, ruleid);
			}
			logger.info("ret---"
					+ JSONObject.fromObject(ret_obj).toString());
			out.print(JSONObject.fromObject(ret_obj).toString());
		} catch (UnsupportedEncodingException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (IOException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (TException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		}
		out.close();
		out = null;
	}

	/**
	 * 保存or更新规则
	 * 
	 * @author san
	 * @param response
	 *            void
	 */
	@RequestMapping(value = "/rule.wx/save/{childid}/{equipid}/{ruletype}")
	public void saveOrUpdateRule(@RequestParam(value = "userid") long userid,
			@RequestParam(value = "sign") String sign,
			@RequestParam(value = "authToken") String authToken,
			@PathVariable(value = "childid") long childid,
			@PathVariable(value = "equipid") long equipid,
			@PathVariable(value = "ruletype") int ruletype,
			HttpServletRequest request, HttpServletResponse response) {
		logger.info("----saveOrUpdateRule----");
		logger.info("----ruleid: ");
		PrintWriter out = null;
		ReturnValue ret_obj = new ReturnValue();
		ret_obj.setStatus(200);
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			TKmUser user = MD5Utils.signUser(userid, sign, authToken,
					wxconfig.getVersion());
			TKmControlRuleInfo saveOrUpdateRule = new TKmControlRuleInfo();
			String strRuleid = request.getParameter("ruleid");
			if (!StringUtils.isEmpty(strRuleid)) {
				long ruleId = Long.parseLong(strRuleid);
				saveOrUpdateRule = equipmentService.getRuleByRuleId(user,ruleId,childid,equipid);
//				logger.info("---getRuleByRuleId---");
//				logger.info(saveOrUpdateRule);
			} else {
				saveOrUpdateRule.on = true;
				saveOrUpdateRule.parentId = userid;
				saveOrUpdateRule.childId = childid;
				saveOrUpdateRule.equipmentId = equipid;
				if(ruletype == 1000){
					// appId
					String strAppId = request.getParameter("appId");
					logger.info("----strAppId:"+strAppId);
					if (!StringUtils.isEmpty(strAppId)) {
						long appId = Long.parseLong(strAppId);
						saveOrUpdateRule.appId = appId;
					} else {
						logger.info("----appId---=null");
					}
					// repeatType
					saveOrUpdateRule.repeatType = 127;
					
					saveOrUpdateRule.startTime = 0;
					saveOrUpdateRule.endTime = 24 * 60 * 60 * 1000;
					saveOrUpdateRule.creattime = System.currentTimeMillis();
					saveOrUpdateRule.on = true;
				}
			}
			saveOrUpdateRule.creattime = System.currentTimeMillis();

			switch (ruletype) {
			case 0:// 时段控制
				saveOrUpdateRule.appId = 0;
				String strStart = request.getParameter("start");
				long start = MyUtils.parseStringTimeToLong(strStart);
				String strEnd = request.getParameter("end");
				long end = MyUtils.parseStringTimeToLong(strEnd);
				// startTime,endTime
				saveOrUpdateRule.startTime = start;
				saveOrUpdateRule.endTime = end;
				// exceptapp
				String strExceptapp = request.getParameter("exceptapp");
				saveOrUpdateRule.exceptapp = strExceptapp;
				// repeatType
				String strRepeat = request.getParameter("repeatType");
				int repeatType = Integer.parseInt(strRepeat);
				saveOrUpdateRule.repeatType = repeatType;
				// controlname
				String strName = request.getParameter("ruleName");
				saveOrUpdateRule.controlname = strName;
				//on 
				String strOn = request.getParameter("on");
				logger.info("---strOn:"+strOn);
				boolean on = Boolean.parseBoolean(strOn);
				logger.info("----On:"+on);
				saveOrUpdateRule.on = on;
				TKmControlRuleInfo save = parentServiceImpl.saveControlRuleInfo(user, saveOrUpdateRule);
				if (save == null ) {
					ret_obj.setStatus(400);
				}
				break;
			case 1:// 锁屏
				saveOrUpdateRule.appId = 1;
				saveOrUpdateRule.repeatType = 127;
				break;
			case 1000:// Add 时长控制
				// dur
				String strDur = request.getParameter("duration");
				long duration = Long.parseLong(strDur);
				saveOrUpdateRule.dur = duration;
				save = parentServiceImpl.saveControlRuleInfo(user, saveOrUpdateRule);
				if (save == null ) {
					ret_obj.setStatus(400);
				}
				break;
			case 2000: // 解除
				// appId
				String strAppId = request.getParameter("appId");
				if (!StringUtils.isEmpty(strRuleid)) {
					long appId = Long.parseLong(strAppId);
					saveOrUpdateRule.appId = appId;
					boolean success = parentServiceImpl.setControlRuleInfoOffByAppid(user,
									saveOrUpdateRule.appId,
									saveOrUpdateRule.childId,
									saveOrUpdateRule.equipmentId);
					ret_obj.setStatus(success ? 200 : 400);
				} else {
					ret_obj.setStatus(300);
				}
				break;
			default:
				break;
			}
//			logger.info("--------saveOrUpdateRule-----");
//			logger.info(saveOrUpdateRule);
//			TKmControlRuleInfo save = parentServiceImpl.saveControlRuleInfo(user, saveOrUpdateRule);
//			if (save == null ) {
//				ret_obj.setStatus(400);
//			}
			logger.info("ret---"
					+ JSONObject.fromObject(ret_obj).toString());
			out.print(JSONObject.fromObject(ret_obj).toString());
		} catch (UnsupportedEncodingException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (IOException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (TKmException e) {
			e.printStackTrace();
		} catch (TException e) {
			e.printStackTrace();
		}
		out.close();
		out = null;
	}

	/**
	 * 获取允许使用的列表
	 * 
	 * @author san
	 * @param response
	 *            void
	 */
	@RequestMapping(value = "/rule.wx/allow/{equipid}/{ruleid}")
	public void getAllowAppList(@RequestParam(value = "userid") long userid,
			@RequestParam(value = "sign") String sign,
			@RequestParam(value = "authToken") String authToken,
			@PathVariable(value = "equipid") long equipid,
			@PathVariable(value = "ruleid") long ruleid,
			HttpServletRequest request, HttpServletResponse response) {
		logger.info("----getAllowAppList----");
		PrintWriter out = null;
		ReturnValue ret_obj = new ReturnValue();
		ret_obj.setStatus(200);
//		logger.info("- +--equipid:" + equipid);
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			String exceptapp = request.getParameter("except");
			out = response.getWriter();
			TKmUser user = MD5Utils.signUser(userid, sign, authToken,
					wxconfig.getVersion());
			// 获取所有app ids
			List<Long> allappids = parentServiceImpl.getEquipmentAllAPP(user,
					equipid);
			List<TKmAppInfo> appInfos = parentServiceImpl.getAppInfoByIDs(user,
					allappids);
			List<AllowApp> allowApps = new ArrayList<AllowApp>();
			HashMap<Long, TKmAppInfo> appInfosMap = new HashMap<Long, TKmAppInfo>();
			for (TKmAppInfo tKmAppInfo : appInfos) {
				appInfosMap.put(tKmAppInfo.id, tKmAppInfo);
			}

			List<AllowApp> lockList = new ArrayList<AllowApp>();// 锁定
			List<AllowApp> allowList = new ArrayList<AllowApp>();// 允许
			List<AllowApp> forbidList = new ArrayList<AllowApp>();// 禁止

			// 锁定
			List<Long> locksIds = parentServiceImpl
					.getEquipmentUnderControlAPP(user, equipid);
			// 允许使用
			List<Long> allowAppIds = new ArrayList<Long>();
			if (!StringUtils.isEmpty(exceptapp)) {
				String[] str_allowAppIds = exceptapp.split(",");
				for (int i = 0; i < str_allowAppIds.length; i++) {
					allowAppIds.add(Long.parseLong(str_allowAppIds[i]));
				}
//				logger.info("--exceptapp--"+exceptapp);
			} else {
				logger.info("---exceptapp is null");
			}
			
			AllowApp data;
			for (Long appid : allappids) {
				data = new AllowApp(appInfosMap.get(appid));
				if (locksIds.contains(appid)) {
					data.setStatusType(100);
					lockList.add(data);
				} else if (allowAppIds.contains(appid)) {
					data.setStatusType(200);
					allowList.add(data);
				} else {
					data.setStatusType(300);
					forbidList.add(data);
				}
			}
			allowApps.addAll(lockList);
			allowApps.addAll(allowList);
			allowApps.addAll(forbidList);
			if(forbidList.size()==0)
				ret_obj.setType(100);
			ret_obj.setContent(allowApps);
			ret_obj.setExtras(allowList.size()+forbidList.size());
//			logger.info("--ret_obj.getExtras--"+ret_obj.getExtras());
			out.print(JSONObject.fromObject(ret_obj).toString());
		} catch (UnsupportedEncodingException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (IOException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (TKmException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (TException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		}
		out.close();
		out = null;
	}

	/**
	 * 删除设备
	 * 
	 * @author san
	 * @param response
	 *            void
	 */
	@RequestMapping(value = "/delete.wx/{childid}/{equipid}")
	public void delEquipment(@RequestParam(value = "userid") long userid,
			@RequestParam(value = "sign") String sign,
			@RequestParam(value = "authToken") String authToken,
			@PathVariable(value = "childid") long childid,
			@PathVariable(value = "equipid") long equipid,
			HttpServletRequest request, HttpServletResponse response) {
		logger.info("----delEquipment----");
		PrintWriter out = null;
		ReturnValue ret_obj = new ReturnValue();
		ret_obj.setStatus(200);
//		logger.info("--childid:" + childid + ",--equipid:" + equipid);
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			TKmUser user = MD5Utils.signUser(userid, sign, authToken,
					wxconfig.getVersion());
			boolean success = parentServiceImpl.delEquipment(user, equipid);
			if (success) {
				ret_obj.setContent(200);
			} else {
				ret_obj.setContent(400);
			}
			out.print(JSONObject.fromObject(ret_obj).toString());
		} catch (UnsupportedEncodingException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (IOException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (TKmException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (TException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		}
		out.close();
		out = null;
	}

	/**
	 * 截屏 操作
	 * 
	 * @author san
	 * @param response
	 *            void
	 */
	@RequestMapping(value = "/snapshot.wx/{equipid}")
	public void snapShot(@RequestParam(value = "userid") long userid,
			@RequestParam(value = "sign") String sign,
			@RequestParam(value = "authToken") String authToken,
			@PathVariable(value = "equipid") long equipid,
			HttpServletRequest request, HttpServletResponse response) {
		logger.info("----snapShot----");
		PrintWriter out = null;
		ReturnValue ret_obj = new ReturnValue();
		ret_obj.setStatus(200);
		logger.info("---equipid:" + equipid);
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			TKmUser user = MD5Utils.signUser(userid, sign, authToken,
					wxconfig.getVersion());
			parentServiceImpl.snapshot(user, equipid);
			out.print(JSONObject.fromObject(ret_obj).toString());
		} catch (UnsupportedEncodingException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (IOException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (TException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		}
		out.close();
		out = null;
	}

	/**
	 * 截屏列表
	 * 
	 * @author san
	 * @param response
	 *            void
	 */
	@RequestMapping(value = "/snapshot.wx/list/{equipid}/{size}/{page}")
	public void getSnapShotList(@RequestParam(value = "userid") long userid,
			@RequestParam(value = "sign") String sign,
			@RequestParam(value = "authToken") String authToken,
			@PathVariable(value = "equipid") long equipid,
			@PathVariable(value = "size") int size,
			@PathVariable(value = "page") int page, HttpServletRequest request,
			HttpServletResponse response) {
		logger.info("----getSnapShotList----");
		PrintWriter out = null;
		ReturnValue ret_obj = new ReturnValue();
		ret_obj.setStatus(200);
		logger.info("-- +--equipid:" + equipid +",page:"+page+",size"+size);
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			TKmUser user = MD5Utils.signUser(userid, sign, authToken,
					wxconfig.getVersion());
			List<TKmSnapshot> list = parentServiceImpl.getSnapshots(user,
					equipid, page, size);
			logger.info("-----SnapshotList----");
			logger.info(""+list);
			List<Snapshot> saList = new ArrayList<Snapshot>();
			Snapshot item = null;
			for (TKmSnapshot tKmSnapshot : list) {
				item = new Snapshot(tKmSnapshot);
				saList.add(item);
			}
			logger.info("--getSnapShotList---ret_data----");
			ret_obj.setContent(saList);
			logger.info(JSONObject.fromObject(ret_obj).toString());
			out.print(JSONObject.fromObject(ret_obj).toString());
		} catch (UnsupportedEncodingException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (IOException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (TException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		}
		out.close();
		out = null;
	}

	/**
	 * 时长限制列表
	 * 
	 * @author san
	 * @param response
	 *            void
	 */
	@RequestMapping(value = "/rule.wx/app/{equipid}/{type}")
	public void getAppRuleList(@RequestParam(value = "userid") long userid,
			@RequestParam(value = "sign") String sign,
			@RequestParam(value = "authToken") String authToken,
			@PathVariable(value = "equipid") long equipid,
			@PathVariable(value = "type") int type, HttpServletRequest request,
			HttpServletResponse response) {
		logger.info("----getAppRuleList----");
		PrintWriter out = null;
		ReturnValue ret_obj = new ReturnValue();
		ret_obj.setStatus(200);
		logger.info("-- +--equipid:" + equipid);
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			TKmUser user = MD5Utils.signUser(userid, sign, authToken,
					wxconfig.getVersion());
			out.print(JSONObject.fromObject(ret_obj).toString());
		} catch (UnsupportedEncodingException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (IOException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		}
		out.close();
		out = null;
	}
}
