package com.kidmate.wx.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.thrift.TException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kidmate.kmservice.TKmChild;
import com.kidmate.kmservice.TKmEquipment;
import com.kidmate.kmservice.TKmException;
import com.kidmate.kmservice.TKmExceptionType;
import com.kidmate.kmservice.TKmUser;
import com.kidmate.service.impl.ParentServiceImpl;
import com.kidmate.tools.Config;
import com.kidmate.wx.model.ChildDetail;
import com.kidmate.wx.model.History;
import com.kidmate.wx.pojo.ReturnValue;
import com.kidmate.wx.pojo.WxTimeStatistics;
import com.kidmate.wx.service.impl.EquipmentService;
import com.kidmate.wx.utils.MD5Utils;
import com.kidmate.wx.utils.MatrixToImageWriter;
import com.kidmate.wx.utils.WeixinConfig;

@Controller
public class WxChildController {

	@Autowired
	@Resource(name = "wxconfig")
	private WeixinConfig wxconfig;
	@Resource(name = "Config")
	private Config config;

	@Resource(name = "ParentServiceImpl")
	private ParentServiceImpl parentServiceImpl;
	@Resource(name = "EquipmentService")
	private EquipmentService equipmentService;

	private static Logger logger = LoggerFactory
			.getLogger(WxChildController.class);

	/**
	 * 
	 * @param source
	 * @param data
	 * @param method
	 * @param saveChild
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/{source}/child/child.wx/{method}", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	public void updatechild(@PathVariable(value = "source") int source,
			@RequestBody String data,
			@PathVariable(value = "method") String method,
			@ModelAttribute("child") TKmChild saveChild,
			HttpServletRequest request, HttpServletResponse response) {
		logger.info("--------child.wx-----------");
		PrintWriter out = null;
		ReturnValue value = new ReturnValue();
		long userid = 2000L;
		String sign = null;
		String authToken = null;
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			if (source == 2000) {
				JSONObject param = JSONObject.fromObject(data);
				userid = param.getLong("userid");
				sign = param.getString("sign");
				authToken = param.getString("authToken");
				if ("ADD".equals(method.toUpperCase())) {
					saveChild = new TKmChild();
					String childName = param.getString("name");
					int gender = param.getInt("gender");
					long birth = param.getLong("birth");
					long childid = param.getLong("childid");
					saveChild.setId(childid);
					saveChild.setName(childName);
					saveChild.setBirth(birth);
					saveChild.setGender(gender == 0);
				}else if("DELETE".equals(method.toUpperCase())){
					long childid = param.getLong("childid");
					saveChild.setId(childid);
				}
			} else if (source == 3000) {
				userid = Long.parseLong(request.getParameter("userid"));
				sign = request.getParameter("sign");
				authToken = request.getParameter("authToken");
			}
			TKmUser user = MD5Utils.signUser(userid, sign, authToken,
					wxconfig.getVersion());
			//
			if ("ADD".equals(method.toUpperCase())) {
				logger.info("---child----" + saveChild);
				// logger.info("--user--"+UserSignUtils.getSignUser(userid,
				// sign, wxconfig.getVersion()));

				// tKmChild.setName(name);
				TKmChild child = parentServiceImpl.saveChild(user, saveChild);
				// TKmChild child = saveChild;

				// TKmChild child = parentServiceImpl.getChildList(user).get(0);
				// logger.info("saveChild--"+child);
				if (child != null) {
					String info = MD5Utils.createChildInfo(sign, userid,
							child.id, System.currentTimeMillis());
					value.setExtras(info);
					value.setContent(child);
					value.setStatus(200);
				} else {
					value.setStatus(400);
				}
				value.setContent(child);
			} else if ("LIST".equals(method.toUpperCase())) {
				List<TKmChild> childList = parentServiceImpl.getChildList(user);
				value.setContent(childList);
			}else if("DELETE".equals(method.toUpperCase())){
//				saveChild.getId()
				boolean success = parentServiceImpl.delChild(user, saveChild.getId());
				value.setStatus(200);
				value.setContent(success);
			}else{
				value.setStatus(400);
			}

		} catch (UnsupportedEncodingException e) {
			value.setStatus(400);
			e.printStackTrace();
		} catch (IOException e) {
			value.setStatus(400);
			e.printStackTrace();
		} catch (TKmException e) {
			e.why.contains("孩子姓名已存在");
			value.setStatus(300);
			e.printStackTrace();
		} catch (TException e) {
			e.printStackTrace();
			value.setStatus(400);
		}
		out.print(JSONObject.fromObject(value));
		if (out != null) {
			out.close();
			out = null;
		}

	}

	@RequestMapping(value = "/{source}/child/detail.wx/{childId}", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	public void getChild(@PathVariable(value = "source") int source,
			@RequestBody String data,
			@PathVariable(value = "childId") long childId,
			HttpServletRequest request, HttpServletResponse response) {
		logger.info("--------child.wx-----------");
		PrintWriter out = null;
		ReturnValue ret_obj = new ReturnValue();
		ret_obj.setStatus(200);
		long userid = 2000L;
		String sign = null;
		String authToken = null;
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			if (source == 2000) {
				JSONObject param = JSONObject.fromObject(data);
				userid = param.getLong("userid");
				sign = param.getString("sign");
				authToken = param.getString("authToken");
			} else if (source == 3000) {
				userid = Long.parseLong(request.getParameter("userid"));
				sign = request.getParameter("sign");
				authToken = request.getParameter("authToken");
			}
			TKmUser user = MD5Utils.signUser(userid, sign, authToken,
					wxconfig.getVersion());
			//
			List<TKmEquipment> list = parentServiceImpl.getEquipmentsByChildId(
					user, childId);
			ChildDetail child = new ChildDetail();
			child.setId(childId);
			System.out.println("--childId:" + childId + ",equipNum:"
					+ list.size());
			child.setEquipmentList(list);
			ret_obj.setContent(child);
			System.out.println(JSONObject.fromObject(ret_obj).toString());
		} catch (UnsupportedEncodingException e) {
			ret_obj.setStatus(400);
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TKmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		out.print(JSONObject.fromObject(ret_obj));
		if (out != null) {
			out.close();
			out = null;
		}

	}

	/**
	 * 获取孩子最近X日使用情况
	 * 
	 * @author san void
	 */
	@RequestMapping(value = "/{source}/child/child.wx/{childid}/{method}/{dayCount}")
	public void getChildTimeStatistics(
			@PathVariable(value = "source") int source,
			@RequestBody String data,
			@PathVariable(value = "method") String method,
			@PathVariable(value = "childid") long childId,
			@PathVariable(value = "dayCount") int dayCount,
			HttpServletRequest request, HttpServletResponse response) {
		logger.info("----获取孩子最近X日使用情况-==1--");
		PrintWriter out = null;
		ReturnValue value = new ReturnValue();
		long userid = 2000L;
		String sign = null;
		String authToken = null;
		long equipId = 0L;
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			if (source == 2000) {
				JSONObject param = JSONObject.fromObject(data);
				userid = param.getLong("userid");
				sign = param.getString("sign");
				authToken = param.getString("authToken");
				if ("TOP".equals(method.toUpperCase())) {
					equipId = param.getLong("equipId");
				}
			} else if (source == 3000) {
				userid = Long.parseLong(request.getParameter("userid"));
				sign = request.getParameter("sign");
				authToken = request.getParameter("authToken");
				if ("TOP".equals(method.toUpperCase())) {
					equipId = Long.parseLong(request.getParameter("equipId"));
				}
			}
			TKmUser user = MD5Utils.signUser(userid, sign, authToken,
					wxconfig.getVersion());
			if ("CHART".equals(method.toUpperCase())) {
				List<WxTimeStatistics> list = equipmentService
						.getChildTimeStatistics(user, childId, dayCount);
				// logger.info("----获取孩子最近X日使用情况==2---");
				value.setStatus(200);
				value.setContent(list);
			} else if ("TOP".equals(method.toUpperCase())) {
				value.setStatus(200);

				List<History> list = equipmentService
						.getChildAppUsageStatistics(user, childId, equipId,
								dayCount, 5);
				value.setContent(list);
				// logger.info("----获取孩子最近X日使用情况==3---");
			} else {
				value.setStatus(400);
			}
			out.print(JSONObject.fromObject(value));
		} catch (TKmException e) {
			if(e.whatOp==TKmExceptionType.UNLOGIN){
				value.setStatus(405);
			}
			e.printStackTrace();
		} catch (TException e) {
			e.printStackTrace();
			value.setStatus(400);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			value.setStatus(400);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			value.setStatus(400);
			e.printStackTrace();
		} finally {
			if (out != null) {
				out.close();
				out = null;
			}
		}

	}

	@RequestMapping(value = "/{source}/child/qrcode.wx/{parentId}/{childId}")
	public void getQRcode(@PathVariable(value = "source") int source,
			@RequestBody String data,
			@PathVariable(value = "parentId") long parentId,
			@PathVariable(value = "childId") long childId,
			HttpServletRequest request, HttpServletResponse response) {
		logger.info("------qrcode-----");
		PrintWriter out = null;
		ReturnValue result = new ReturnValue();
		result.setStatus(200);
		long userid = 0L;
		String sign = null;
		String authToken = null;
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			if (source == 2000) {
				JSONObject param = JSONObject.fromObject(data);
				userid = param.getLong("userid");
				sign = param.getString("sign");
				authToken = param.getString("authToken");
				String info = MD5Utils.createChildInfo4Wx(
						(authToken + sign).substring(0, 32), parentId, childId,
						System.currentTimeMillis());
				String filePath = File.separator + "qrcode" + File.separator
						+ parentId / 30000 + File.separator + parentId;
				String fileName = "" + parentId + "_" + childId;

				MatrixToImageWriter.createQrcodeFile(info,
						config.getImagePath() + filePath, fileName);
				result.setContent(filePath + File.separator + fileName + ".jpg");
			} else if (source == 3000) {
				userid = Long.parseLong(request.getParameter("userid"));
				sign = request.getParameter("sign");
				authToken = request.getParameter("authToken");
				String info = MD5Utils.createChildInfo4Wx(
						(authToken + sign).substring(0, 32), parentId, childId,
						System.currentTimeMillis());
				result.setContent(info);
				logger.info("qrcode_str:" + info);
			}

			if (userid != parentId)
				result.setStatus(400);
			out.print(JSONObject.fromObject(result).toString());
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result.setStatus(400);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result.setStatus(400);
		}
		out.close();
		out = null;
	}
}
