package com.kidmate.wx.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.apache.thrift.TException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.kidmate.kmservice.TKmAppUsage;
import com.kidmate.kmservice.TKmChild;
import com.kidmate.kmservice.TKmEquipment;
import com.kidmate.kmservice.TKmException;
import com.kidmate.kmservice.TKmUser;
import com.kidmate.model.KmParentDAO;
import com.kidmate.model.KmRss;
import com.kidmate.service.impl.ParentServiceImpl;
import com.kidmate.tools.SecurityUtils;
import com.kidmate.wx.model.LoginSuccessInfo;
import com.kidmate.wx.pojo.ReturnValue;
import com.kidmate.wx.pojo.RetMsg;
import com.kidmate.wx.service.IUserService;
import com.kidmate.wx.utils.WeixinConfig;
import com.kidmate.wx.utils.MD5Utils;
import com.kidmate.wx.utils.MyUtils;
import com.kidmate.wx.utils.WeixinUtil;

//@RequestMapping(value = "/user")
@Controller
public class WxUserController {
	private static Logger logger = LoggerFactory
			.getLogger(WxUserController.class);
	@Autowired
	@Resource(name = "wxconfig")
	private WeixinConfig config;
	@Autowired
	@Qualifier("UserService")
	private IUserService userService;

	@Resource(name = "ParentServiceImpl")
	private ParentServiceImpl parentServiceImpl;
	@Resource(name = "KmParentDAO")
	private KmParentDAO kmParentDAO;

	/**
	 * 小程序登录入口
	 * 
	 * @param source
	 *            1:接口调用来源：3000服务号；2000小程序
	 * @param code
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(value = "/{source}/user/login.wx", method = RequestMethod.POST)
	public void login_wx_xcx(@PathVariable(value = "source") int source,
			@RequestBody String data, HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String ip = MyUtils.getRemoteHost(request);
		String signature = null, iv = null, encryptedData = null, code = null;
		if (source == 2000) {
			JSONObject param = JSONObject.fromObject(data);
			System.out.println("======2000====");
			code = param.getString("code");
			signature = param.getString("signature");
			encryptedData = param.getString("encryptedData");
			iv = param.getString("iv");
			System.out.println("-------data----");
			System.out.println(data);
			System.out.println("-------code----");
			System.out.println(code);
			System.out.println("-------signature----");
			System.out.println(signature);
			System.out.println("-------encryptedData----");
			System.out.println(encryptedData);
			System.out.println("-------iv----");
			System.out.println(iv);
		} else if (source == 3000) {
			System.out.println("======3000====");
			code = request.getParameter("code");
			signature = request.getParameter("signature");
			iv = request.getParameter("iv");
			encryptedData = request.getParameter("encryptedData");
			System.out.println(data.toString());
			System.out.println("code:" + code);
			System.out.println("signature:" + signature);
			System.out.println("iv:" + iv);
			System.out.println("encryptedData:" + encryptedData);
		}
		JSONObject result = userService.login(code, source, signature,
				encryptedData, iv, ip);
		PrintWriter out = response.getWriter();
		System.out.println("login_wx_xcx==return:");
		System.out.println(JSONObject.fromObject(result).toString());
		// out.print(JSONObject.fromObject(result).toString());
		out.print(result);
		out.close();
		out = null;
	}

	@RequestMapping(value = "/{source}/user/vip.wx", method = RequestMethod.POST)
	public void getUserInfo(@PathVariable(value = "source") int source,
			@RequestBody String data, HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		ReturnValue result = new ReturnValue();
		// logger.info("---new---login--");
		result.setStatus(200);
		TKmUser kmUser = new TKmUser();
		logger.info("config.isDevelop()--" + config.isDevelop());
		try {
			long viptime = parentServiceImpl.getVipTime(kmUser);
		} catch (TException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		PrintWriter out = response.getWriter();
		logger.info("ret:" + JSONObject.fromObject(result).toString());
		out.print(JSONObject.fromObject(result).toString());
		out.close();
		out = null;
	}

}
