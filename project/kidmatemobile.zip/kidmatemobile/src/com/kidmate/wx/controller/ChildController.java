package com.kidmate.wx.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.thrift.TException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kidmate.kmservice.TKmChild;
import com.kidmate.kmservice.TKmException;
import com.kidmate.kmservice.TKmUser;
import com.kidmate.service.impl.ParentServiceImpl;
import com.kidmate.wx.model.History;
import com.kidmate.wx.pojo.ReturnValue;
import com.kidmate.wx.pojo.WxTimeStatistics;
import com.kidmate.wx.service.impl.EquipmentService;
import com.kidmate.wx.utils.MD5Utils;
import com.kidmate.wx.utils.WeixinConfig;
@Controller
@RequestMapping(value="/child")
public class ChildController {
	
	@Autowired
	@Resource(name = "wxconfig")
	private WeixinConfig wxconfig;
	
	@Resource(name="ParentServiceImpl")
	private ParentServiceImpl parentServiceImpl;
	@Resource(name="EquipmentService")
	private EquipmentService equipmentService;
	
	private static Logger logger = LoggerFactory.getLogger(ChildController.class);
	@RequestMapping(value="/child.wx/{method}", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	public void updatechild(@PathVariable(value = "method") String method,
			@ModelAttribute("child")TKmChild saveChild,
			@RequestParam(value = "userid") long userid,
			@RequestParam(value = "sign") String sign,
			@RequestParam(value = "authToken") String authToken,
			HttpServletRequest request, HttpServletResponse response){
		logger.info("--------child.wx-----------");
		PrintWriter out =null;
		ReturnValue value = new ReturnValue();
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
//			logger.info("---child----"+saveChild);
//			logger.info("--user--"+UserSignUtils.getSignUser(userid, sign, wxconfig.getVersion()));
			TKmUser user = MD5Utils.signUser(userid, sign, authToken,wxconfig.getVersion());
//			tKmChild.setName(name);
			TKmChild child = parentServiceImpl.saveChild(user, saveChild);
//			TKmChild child = saveChild;
			
//			TKmChild child = parentServiceImpl.getChildList(user).get(0);
//			logger.info("saveChild--"+child);
			if (child != null){
				String info = MD5Utils.createChildInfo(sign, userid, child.id,
						System.currentTimeMillis());
				value.setExtras(info);
				value.setStatus(200);
			} else {
				value.setStatus(400);
			}
			value.setContent(child);
		} catch (UnsupportedEncodingException e) {
			value.setStatus(400);
			e.printStackTrace();
		} catch (IOException e) {
			value.setStatus(400);
			e.printStackTrace();
		} catch (TKmException e) {
			e.why.contains("孩子姓名已存在");
			value.setStatus(300);
			e.printStackTrace();
		} catch (TException e) {
			e.printStackTrace();
			value.setStatus(400);
		}
		out.print(JSONObject.fromObject(value));
		if(out!=null){
			out.close();
			out = null;
		}
		
	}
	
	/**
	 * 获取孩子最近X日使用情况
	 * @author san void
	 */
	@RequestMapping(value="/child.wx/{childid}/{method}/{dayCount}")
	public void getChildTimeStatistics(@RequestParam(value = "userid") long userid,
			@RequestParam(value = "sign") String sign,
			@RequestParam(value = "authToken") String authToken,
			@PathVariable(value = "method") String method,
			@PathVariable(value = "childid")long childId,
			@PathVariable(value = "dayCount")int dayCount,
			HttpServletRequest request, HttpServletResponse response){
		logger.info("----获取孩子最近X日使用情况-==1--");
		PrintWriter out =null;
		TKmUser user = MD5Utils.signUser(userid, sign, authToken,wxconfig.getVersion());
		ReturnValue value=new ReturnValue();
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			if("CHART".equals(method.toUpperCase())){
				List<WxTimeStatistics> list = equipmentService.getChildTimeStatistics(user, childId, dayCount);
//				logger.info("----获取孩子最近X日使用情况==2---");
				value.setStatus(200);
				value.setContent(list);
			}else if ("TOP".equals(method.toUpperCase())) {
				value.setStatus(200);
				long equipId = Long.parseLong(request.getParameter("equipId"));
				List<History> list = equipmentService.getChildAppUsageStatistics(user, childId, equipId, dayCount,5);
				value.setContent(list);
//				logger.info("----获取孩子最近X日使用情况==3---");
			}else {
				value.setStatus(400);
			}
			out.print(JSONObject.fromObject(value));
		} catch (TException e) {
			e.printStackTrace();
			value.setStatus(400);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			value.setStatus(400);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			value.setStatus(400);
			e.printStackTrace();
		}finally{
			if(out!=null){
				out.close();
				out = null;
			}
		}
		
	}
	@RequestMapping(value = "/qrcode.wx/{parentId}/{childId}")
	public void getQRcode(@RequestParam(value = "userid") long userid,
			@RequestParam(value = "sign") String sign,
			@RequestParam(value = "authToken") String authToken,
			@PathVariable(value = "parentId") long parentId,
			@PathVariable(value = "childId") long childId,
			HttpServletRequest request, HttpServletResponse response) {
		logger.info("------qrcode-----");
		PrintWriter out = null;
		ReturnValue result = new ReturnValue();
		result.setStatus(200);
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			String info = MD5Utils.createChildInfo4Wx((authToken+sign).substring(0,32), parentId, childId,
					System.currentTimeMillis());
			result.setContent(info);
			logger.info("qrcode_str:" + info);
			out.print(JSONObject.fromObject(result).toString());
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result.setStatus(400);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result.setStatus(400);
		}
		out.close();
		out = null;
	}
}
