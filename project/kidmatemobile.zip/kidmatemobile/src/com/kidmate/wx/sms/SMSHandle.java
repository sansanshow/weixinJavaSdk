package com.kidmate.wx.sms;

import java.net.URLEncoder;

import org.apache.log4j.Logger;

import com.bjdata.util.SecurityUtils;
import com.bjdata.util.StringUtils;
import com.kidmate.wx.utils.MyUtils;
import com.kidmate.wx.utils.PropertyManager;


public class SMSHandle {
	private static final Logger logger = Logger.getLogger(SMSHandle.class);
	private static SMSHandle smsHandle = null;
	private static final String posturl = "http://202.85.221.72:9885/c123/";

	public static SMSHandle getInstance() {
		if (smsHandle == null) {
			smsHandle = new SMSHandle();
		}
		return smsHandle;
	}
	 /**
     * 
     * @param mobiles 多个以,分割
     * @param msg 
     * @return 
     * 100            发送成功
     * 101            验证失败
     * 102            短信不足
     * 103            操作失败
     * 104            非法字符
     * 105            内容过多
     * 106            号码过多
     * 107            频率过快
     * 108            号码内容空
     * 109            账号冻结
     * 110            禁止频繁单条发送
     * 111            系统暂定发送
     * 112            子号不正确
     * 120            系统升级
     */
    public int sendSMS(String mobiles,String msg){
        mobiles = StringUtils.replace(mobiles.trim(), "，", ",");
        String rs = doSendSMS(mobiles, msg);
        if(rs == null)
            rs = "99";
        if(rs.trim().equals("100")){
            return 0;//成功
        }else{
            try {
                return Integer.parseInt(rs.trim());//其他错误
            } catch (Exception e) {
                return 99;
            }
            
        }
    }
    
    
    /**
     * 
     * @param mobiles 多个以,分割
     * @param msg
     * @return
     */
    public String doSendSMS(String mobiles,String msg) {
        try {
            msg = "【苗苗】"+msg;
            String md5pass = SecurityUtils.md5ByHex(PropertyManager.getProperty("mobile.yueliang.pass")).toLowerCase();
            String url =PropertyManager.getProperty("mobile.yueliang.url") + "sendsms?uid="+PropertyManager.getProperty("mobile.yueliang.user")+"&pwd="+md5pass+"&mobile="+mobiles.trim()+"&content="+URLEncoder.encode(msg,"GBK");
            System.out.println(url);
            return MyUtils.getHTMLByUrl(url,null); 
        } catch (Exception e) {
            logger.info("发生异常，导致发送失败");
            e.printStackTrace();
            return "99";
        }
    }
}
