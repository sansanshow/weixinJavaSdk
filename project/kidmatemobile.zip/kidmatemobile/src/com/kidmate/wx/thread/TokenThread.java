package com.kidmate.wx.thread;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kidmate.wx.pojo.AccessToken;
import com.kidmate.wx.pojo.JsapiTicket;
import com.kidmate.wx.utils.PropertyManager;
import com.kidmate.wx.utils.WeixinUtil;


/**
 * 定时获取微信access_token的线程
 * 
 * @author liuyq
 * @date 2013-05-02
 */
public class TokenThread implements Runnable {
	private static Logger log = LoggerFactory.getLogger(TokenThread.class);
	// 第三方用户唯一凭证
	public static String appid = PropertyManager.getProperty("appid");
	// 第三方用户唯一凭证密钥
	public static String appsecret = PropertyManager.getProperty("appsecret");
	public static AccessToken accessToken = null;
	public static JsapiTicket jsapi_ticket = null;

	public void run() {
		while (true) {
			log.info("线程启动");
			try {
				accessToken = WeixinUtil.getAccessToken(appid, appsecret);
				jsapi_ticket=WeixinUtil.getJsApiTicket(accessToken.getToken());
				log.info("获取jsapi_ticket成功，有效时长{}秒 jsapi_ticket:{}", jsapi_ticket.getExpiresIn(), jsapi_ticket.getTicket());
				if (null != accessToken) {
					log.info("获取access_token成功，有效时长{}秒 token:{}", accessToken.getExpiresIn(), accessToken.getToken());
					// 休眠7000秒
					Thread.sleep((accessToken.getExpiresIn() - 200) * 1000);
				} else {
					// 如果access_token为null，60秒后再获取
					log.info("access_token为null，60秒后再获取");
					Thread.sleep(60 * 1000);
				}
			} catch (InterruptedException e) {
				try {
					Thread.sleep(60 * 1000);
				} catch (InterruptedException e1) {
					log.error("{}", e1);
				}
				log.error("{}", e);
			}
		}
	}
}