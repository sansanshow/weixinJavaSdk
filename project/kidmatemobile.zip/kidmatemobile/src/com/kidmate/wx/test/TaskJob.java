package com.kidmate.wx.test;

import org.springframework.stereotype.Service;

@Service
public class TaskJob {
	public void job1() {  
      System.out.println("..............taskJob");  
    }  
}
