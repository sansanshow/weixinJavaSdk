package com.kidmate.wx.test;

import java.util.Date;

import com.kidmate.wx.sms.SMSHandle;
import com.kidmate.wx.utils.MD5Utils;
import com.kidmate.wx.utils.MyUtils;
import com.kidmate.wx.utils.PropertyManager;
import com.kidmate.wx.utils.WeixinUtil;

public class Test {
	public static void main(String[] args) {

//		System.out.println(SMSHandle.getInstance().sendSMS(
//				"18235445764",
//				"您的短信验证码是：123456,【"
//						+ MyUtils.formatDate("yyyy-MM-dd HH:mm:ss", new Date())
//						+ "】"));
//		System.out.println(WeixinUtil.getAccessToken(PropertyManager.getProperty("appid"), PropertyManager.getProperty("appsecret")));

		
		//		getMeidia();
//		MyUtils.parseStringTimeToLong("6:00");\
//		System.out.println(MD5Utils.md5ByHex("2F56FCDB7650DC813E2EE977A151D9FB"));
		long timestamp=1484363085891L;
		System.out.println(timestamp);
		System.out.println(timestamp << 5);
		System.out.println(MD5Utils.md5ByHex("F5748545D9BCC88B291C81528A9B7525") + "2F56FCDB7650DC813E2EE977A151D9FB" + (timestamp << 5));
		System.out.println(MD5Utils.md5ByHex(MD5Utils.md5ByHex("F5748545D9BCC88B291C81528A9B7525") + "2F56FCDB7650DC813E2EE977A151D9FB" + (timestamp << 5)));
	}
	
	public static void getMeidia(){
		String accessToken = WeixinUtil.getAccessToken(PropertyManager.getProperty("appid"), PropertyManager.getProperty("appsecret")).getToken();
//		String accessToken = "7-T6euUb4iSzMx_Eeyia9BKYHB2djO6vPDn2m2u5iz7pa0sR_iTfBrmzSM8uLYv7tVU-RcZ770mZV3fb8mA2dc1GoySHgPu_kfVdXoTz--YUuReVSkSdDoQ4HyqCLRdqOCBfADASGF";
		System.out.println(WeixinUtil.getPermanentMedia2(accessToken, "image", 0, 5));
	}
}
