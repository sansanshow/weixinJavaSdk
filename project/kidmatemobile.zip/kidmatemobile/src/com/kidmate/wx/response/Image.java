package com.kidmate.wx.response;

public class Image {
	private String MediaId;

	public Image() {
		// TODO Auto-generated constructor stub
	}

	public Image(String mediaId) {
		super();
		MediaId = mediaId;
	}

	public String getMediaId() {
		return MediaId;
	}

	public void setMediaId(String mediaId) {
		MediaId = mediaId;
	}

}
