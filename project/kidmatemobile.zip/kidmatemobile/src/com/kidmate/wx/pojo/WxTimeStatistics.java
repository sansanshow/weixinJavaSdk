package com.kidmate.wx.pojo;

public class WxTimeStatistics {
	private String time;
	private double avgDuration;
	private double selfDuration;

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public double getAvgDuration() {
		return avgDuration;
	}

	public void setAvgDuration(double avgDuration) {
		this.avgDuration = avgDuration;
	}

	public double getSelfDuration() {
		return selfDuration;
	}

	public void setSelfDuration(double selfDuration) {
		this.selfDuration = selfDuration;
	}

}
