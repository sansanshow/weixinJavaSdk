package com.kidmate.wx.pojo;

public class JsapiTicket {
	// 获取到的ticket
	private String ticket;
	// 凭证有效时间，单位：秒
	private int expiresIn;

	public String getTicket() {
		return ticket;
	}

	public void setTicket(String ticket) {
		this.ticket = ticket;
	}

	public int getExpiresIn() {
		return expiresIn;
	}

	public void setExpiresIn(int expiresIn) {
		this.expiresIn = expiresIn;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "JsapiTicket:[ticket:" + ticket + ",expiresIn:" + expiresIn + "]";
	}
}
