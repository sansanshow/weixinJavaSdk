package com.kidmate.wx.pojo;

import com.kidmate.kmservice.TKmUser;

public class ReturnValue {
	private int status;
	private int type;
	private TKmUser user;
	private String openid;
	private Object content;
	private Object extras;

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public TKmUser getUser() {
		return user;
	}

	public void setUser(TKmUser user) {
		this.user = user;
	}

	public String getOpenid() {
		return openid;
	}

	public void setOpenid(String openid) {
		this.openid = openid;
	}

	public Object getContent() {
		return content;
	}

	public void setContent(Object content) {
		this.content = content;
	}

	public Object getExtras() {
		return extras;
	}

	public void setExtras(Object extras) {
		this.extras = extras;
	}

}
