package com.kidmate.wx.pojo;

/**
 * 菜单
 * 
 * @author liufeng
 * @date 2013-08-08
 */
public class WxMenu {
	private Button[] button;

	public Button[] getButton() {
		return button;
	}

	public void setButton(Button[] button) {
		this.button = button;
	}
}