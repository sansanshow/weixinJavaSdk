package com.kidmate.wx.pojo;

import com.kidmate.kmservice.TKmUser;

public class RetMsg {
	private String status;
	private TKmUser user;
	private String viewName;
	private Object content;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	public TKmUser getUser() {
		return user;
	}

	public void setUser(TKmUser user) {
		this.user = user;
	}

	public String getViewName() {
		return viewName;
	}

	public void setViewName(String viewName) {
		this.viewName = viewName;
	}

	public Object getContent() {
		return content;
	}

	public void setContent(Object content) {
		this.content = content;
	}

}
