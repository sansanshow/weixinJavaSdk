package com.kidmate.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class KmProductClass {
	private Long id ;               // 产品分类Id
	private String name;            // 产品分类名称
    private String description;  	//-- 分类描述
    private String remark ; 		//	-- 小编点评
	private String link ; 			//-- 产品链接
	private String image;             //产品图片
	private String tags;  			//-- 分类或标签
	private Date createtime; 		//	-- 创建时间
	private Long   kmbysort; 		    //	-- 排序
	private String status;
	
	public KmProductClass(){}

	public KmProductClass(Long id, String name, String description
			, String remark, String link, String tags,String image,
			Date createtime, String status,Long kmbysort) {
           this.id=id;
        	this.name=name;
        	this.description=description;
        	this.remark=remark;
        	this.link=link;
        	this.image=image;
        	this.tags=tags;
        	this.kmbysort=kmbysort;
        	this.createtime=createtime;
        	this.status=status;
	}
	@Id
	@GeneratedValue
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getTags() {
		return tags;
	}
	public void setTags(String tags) {
		this.tags = tags;
	}
	public Date getCreatetime() {
		return createtime;
	}
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public long getKmbysort() {
		return kmbysort;
	}

	public void setKmbysort(long kmbysort) {
		this.kmbysort = kmbysort;
	}
	
	
	
}
