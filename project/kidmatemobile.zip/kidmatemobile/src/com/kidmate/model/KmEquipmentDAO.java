package com.kidmate.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import org.hibernate.Hibernate;
import org.hibernate.LockMode;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * A data access object (DAO) providing persistence and search support for
 * KmEquipment entities. Transaction control of the save(), update() and
 * delete() operations can directly support Spring container-managed
 * transactions or they can be augmented to handle user-managed Spring
 * transactions. Each of these methods provides additional information for how
 * to configure it for the desired type of transaction control.
 * 
 * @see com.kidmate.model.KmEquipment
 * @author MyEclipse Persistence Tools
 */

@Entity
public class KmEquipmentDAO extends HibernateDaoSupport {
	private static final Logger log = LoggerFactory
			.getLogger(KmEquipmentDAO.class);
	// property constants
	public static final String PARENTID = "parentid";
	public static final String EQUIPMENTTYPE = "equipmenttype";
	public static final String ALIAS = "alias";
	public static final String MAC = "mac";
	public static final String SIGN = "sign";
	public static final String REGSOURCE = "regsource";
	public static final String REGIP = "regip";
	public static final String LASTIP = "lastip";
	public static final String STATUS = "status";

	protected void initDao() {
		// do nothing
	}
	
	public List<KmEquipment> findByChildID(long childid) {
		//TODO 
		String sql = "select * from km_equipment where id in (select equipmentid from km_child_equipment where childid=? and status!='0') and status='1' order by id asc";
		Session session = getSessionFactory().openSession();
		SQLQuery query = session.createSQLQuery(sql).addEntity(KmEquipment.class);
		query.setParameter(0, childid, Hibernate.LONG);
		List<KmEquipment> results = query.list();
		session.close();
		return results;
	}

	public void save(KmEquipment transientInstance) {
		log.debug("saving KmEquipment instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(KmEquipment persistentInstance) {
		log.debug("deleting KmEquipment instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public KmEquipment findById(java.lang.Long id) {
		log.debug("getting KmEquipment instance with id: " + id);
		try {
			KmEquipment instance = (KmEquipment) getHibernateTemplate().get(
					"com.kidmate.model.KmEquipment", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(KmEquipment instance) {
		log.debug("finding KmEquipment instance by example");
		try {
			List results = getHibernateTemplate().findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding KmEquipment instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from KmEquipment as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List findByParentid(Object parentid) {
		return findByProperty(PARENTID, parentid);
	}

	public List findByEquipmenttype(Object equipmenttype) {
		return findByProperty(EQUIPMENTTYPE, equipmenttype);
	}

	public List findByAlias(Object alias) {
		return findByProperty(ALIAS, alias);
	}

	public List findByMac(Object mac) {
		return findByProperty(MAC, mac);
	}

	public List findBySign(Object sign) {
		return findByProperty(SIGN, sign);
	}

	public List findByRegsource(Object regsource) {
		return findByProperty(REGSOURCE, regsource);
	}

	public List findByRegip(Object regip) {
		return findByProperty(REGIP, regip);
	}

	public List findByLastip(Object lastip) {
		return findByProperty(LASTIP, lastip);
	}

	public List findByStatus(Object status) {
		return findByProperty(STATUS, status);
	}

	public List findAll() {
		log.debug("finding all KmEquipment instances");
		try {
			String queryString = "from KmEquipment";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public KmEquipment merge(KmEquipment detachedInstance) {
		log.debug("merging KmEquipment instance");
		try {
			KmEquipment result = (KmEquipment) getHibernateTemplate().merge(
					detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(KmEquipment instance) {
		log.debug("attaching dirty KmEquipment instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(KmEquipment instance) {
		log.debug("attaching clean KmEquipment instance");
		try {
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public static KmEquipmentDAO getFromApplicationContext(
			ApplicationContext ctx) {
		return (KmEquipmentDAO) ctx.getBean("KmEquipmentDAO");
	}
}