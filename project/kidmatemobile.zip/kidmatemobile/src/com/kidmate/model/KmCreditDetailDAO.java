package com.kidmate.model;

import java.util.Date;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.LockMode;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * A data access object (DAO) providing persistence and search support for
 * KmCreditDetail entities. Transaction control of the save(), update() and
 * delete() operations can directly support Spring container-managed
 * transactions or they can be augmented to handle user-managed Spring
 * transactions. Each of these methods provides additional information for how
 * to configure it for the desired type of transaction control.
 * 
 * @see com.kidmate.model.KmCreditDetail
 * @author MyEclipse Persistence Tools
 */

public class KmCreditDetailDAO extends HibernateDaoSupport {
	private static final Logger log = LoggerFactory
			.getLogger(KmCreditDetailDAO.class);
 public static final String PID= "pid";
	protected void initDao() {
		// do nothing
	}

	public void save(KmCreditDetail transientInstance) {
		log.debug("saving KmCreditDetail instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

   public KmCreditDetail findById(java.lang.Long id) {
		log.debug("getting KmCreditDetail instance with id: " + id);
		try {
			KmCreditDetail instance = (KmCreditDetail) getHibernateTemplate()
					.get("com.kidmate.model.KmCreditDetail", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(KmCreditDetail instance) {
		log.debug("finding KmCreditDetail instance by example");
		try {
			List results = getHibernateTemplate().findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding KmCreditDetail instance with property: "
				+ propertyName + ", value: " + value);
		try {
			String queryString = "from KmCreditDetail as model where model."
					+ propertyName + "= ?  order by createtime desc";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	/**
	 * @param creditType
	 * @param time
	 * @return
	 */
	public List findByCretim(long userid,long creditType,Date time){
		String sql = "select * from km_credit_detail where pid=? and typeid=? and createTime>? ";
		Session session = getSessionFactory().openSession();
		SQLQuery query = session.createSQLQuery(sql).addEntity(KmCreditDetail.class);
		query.setParameter(0, userid, Hibernate.LONG);
		query.setParameter(1, creditType, Hibernate.LONG);
		query.setParameter(2, time,Hibernate.DATE);
		List<KmCreditDetail> results = query.list();
		session.close();
		return results;
	}
	
	
	public List findByUserId(Object value){
		return this.findByProperty(PID, value);
	}
	public List findAll() {
		log.debug("finding all KmCreditDetail instances");
		try {
			String queryString = "from KmCreditDetail";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}



	

	public static KmCreditDetailDAO getFromApplicationContext(
			ApplicationContext ctx) {
		return (KmCreditDetailDAO) ctx.getBean("KmCreditDetailDAO");
	}
}