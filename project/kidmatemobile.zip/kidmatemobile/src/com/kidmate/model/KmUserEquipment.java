package com.kidmate.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * KmUserEquipment entity. @author MyEclipse Persistence Tools
 */

@Entity
public class KmUserEquipment implements java.io.Serializable {

	// Fields

	private Long id;
	private Long userid;
	private Long equipmentid;
	private Integer relationtype;
	private String status;

	// Constructors

	/** default constructor */
	public KmUserEquipment() {
	}

	/** minimal constructor */
	public KmUserEquipment(Long id) {
		this.id = id;
	}

	/** full constructor */
	public KmUserEquipment(Long id, Long userid, Long equipmentid,
			Integer relationtype, String status) {
		this.id = id;
		this.userid = userid;
		this.equipmentid = equipmentid;
		this.relationtype = relationtype;
		this.status = status;
	}

	// Property accessors

	@Id
	@GeneratedValue
	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getUserid() {
		return this.userid;
	}

	public void setUserid(Long userid) {
		this.userid = userid;
	}

	public Long getEquipmentid() {
		return this.equipmentid;
	}

	public void setEquipmentid(Long equipmentid) {
		this.equipmentid = equipmentid;
	}

	public Integer getRelationtype() {
		return this.relationtype;
	}

	public void setRelationtype(Integer relationtype) {
		this.relationtype = relationtype;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}