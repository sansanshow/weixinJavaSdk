package com.kidmate.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * KmAppUsage entity. @author MyEclipse Persistence Tools
 */

@Entity
public class KmAppUsage implements java.io.Serializable {

	// Fields

	private Long id;
	private Long equipmentid;
	private Long childid;
	private Long appid;
	private Long wifiid;
	private String ip;
	private Long locationid;
	private Date createtime;
	private Long duration;
	private String status;

	// Constructors

	/** default constructor */
	public KmAppUsage() {
	}

	/** minimal constructor */
	public KmAppUsage(Long id) {
		this.id = id;
	}

	/** full constructor */
	public KmAppUsage(Long id, Long equipmentid, Long childid, Long appid,
			Long wifiid, String ip, Long locationid, Date createtime,
			Long duration, String status) {
		this.id = id;
		this.equipmentid = equipmentid;
		this.childid = childid;
		this.appid = appid;
		this.wifiid = wifiid;
		this.ip = ip;
		this.locationid = locationid;
		this.createtime = createtime;
		this.duration = duration;
		this.status = status;
	}

	// Property accessors

	@Id
	@GeneratedValue
	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getEquipmentid() {
		return this.equipmentid;
	}

	public void setEquipmentid(Long equipmentid) {
		this.equipmentid = equipmentid;
	}

	public Long getChildid() {
		return this.childid;
	}

	public void setChildid(Long childid) {
		this.childid = childid;
	}

	public Long getAppid() {
		return this.appid;
	}

	public void setAppid(Long appid) {
		this.appid = appid;
	}

	public Long getWifiid() {
		return this.wifiid;
	}

	public void setWifiid(Long wifiid) {
		this.wifiid = wifiid;
	}

	public String getIp() {
		return this.ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public Long getLocationid() {
		return this.locationid;
	}

	public void setLocationid(Long locationid) {
		this.locationid = locationid;
	}

	public Date getCreatetime() {
		return this.createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public Long getDuration() {
		return this.duration;
	}

	public void setDuration(Long duration) {
		this.duration = duration;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}