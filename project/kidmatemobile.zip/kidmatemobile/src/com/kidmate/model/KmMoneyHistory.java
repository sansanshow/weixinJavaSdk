package com.kidmate.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * KmMoneyHistory entity. @author MyEclipse Persistence Tools
 */

@Entity
public class KmMoneyHistory implements java.io.Serializable {

	// Fields

	private Long id;
	private Long userid;
	private Double money;
	private String remark;
	private String ip;
	private Date createtime;

	// Constructors

	/** default constructor */
	public KmMoneyHistory() {
	}

	/** minimal constructor */
	public KmMoneyHistory(Long id) {
		this.id = id;
	}

	/** full constructor */
	public KmMoneyHistory(Long id, Long userid, Double money, String remark,
			String ip, Date createtime) {
		this.id = id;
		this.userid = userid;
		this.money = money;
		this.remark = remark;
		this.ip = ip;
		this.createtime = createtime;
	}

	// Property accessors

	@Id
	@GeneratedValue
	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getUserid() {
		return this.userid;
	}

	public void setUserid(Long userid) {
		this.userid = userid;
	}

	public Double getMoney() {
		return this.money;
	}

	public void setMoney(Double money) {
		this.money = money;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getIp() {
		return this.ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public Date getCreatetime() {
		return this.createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

}