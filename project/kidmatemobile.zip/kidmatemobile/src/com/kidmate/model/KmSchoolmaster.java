package com.kidmate.model;

import java.util.Date;

/**
 * KmSchoolmaster entity. @author MyEclipse Persistence Tools
 */

public class KmSchoolmaster implements java.io.Serializable {

	// Fields

	private long id;
	private String name;
	private String schoolname;
	private String phonenumber;
	private Date createtime;
	private String status;

	// Constructors

	/** default constructor */
	public KmSchoolmaster() {
	}

	/** full constructor */
	public KmSchoolmaster(String name, String schoolname, String phonenumber,
			Date createtime, String status) {
		this.name = name;
		this.schoolname = schoolname;
		this.phonenumber = phonenumber;
		this.createtime = createtime;
		this.status = status;
	}

	// Property accessors

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSchoolname() {
		return this.schoolname;
	}

	public void setSchoolname(String schoolname) {
		this.schoolname = schoolname;
	}

	public String getPhonenumber() {
		return this.phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public Date getCreatetime() {
		return this.createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}