package com.kidmate.model;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class KmProductClassDao extends HibernateDaoSupport {
private static final Log log = LogFactory.getLog(KmProductClassDao.class);
	
	
	public void save(KmProductClass transientInstance) {
		log.debug("saving KmProductClass instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}
	public void delete(KmProductClass persistentInstance) {
		log.debug("deleting KmProductClass instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}
	public List findByProperty(String propertyName, Object value) {
		log.debug("finding KmProductClass instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from KmProductClass as model where model."
					+ propertyName + "= ? order by model.createtime desc";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}
	
	public List findAll() {
		log.debug("finding all KmChild instances");
		try {
			String queryString = "from KmProductClass as model where model.status='1' order by  model.kmbysort ";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}
	
	public void attachDirty(KmProductClass instance) {
		log.debug("attaching dirty KmProductClass instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}
	
	public List<KmProductClass> findByChannelPage(int size,int page,long channelid){
		Session session = null;
		try {
			String sql = " select * from km_rss k  where 1=1 and k.channelid="+channelid+"  and k.status='1' order by k.createtime desc";
			session = getSessionFactory().openSession();
			Query query = null;
			query = session.createSQLQuery(sql).addEntity(KmProductClass.class);
			query.setFirstResult(size * (page - 1));
			query.setMaxResults(size);
			List<KmProductClass> kmProductClass = query.list();
			return kmProductClass;
		} catch (RuntimeException re) {
			re.printStackTrace();
			log.error("find by findPfOperateLogForPage failed", re);
			throw re;
		} finally {
			if (session != null)
				session.close();
		}
	
	}
//  分页加条件查询
	public List<KmProductClass> findByFiltPage(KmProductClass kmpa,int size, int page){
		Session session = null;
		try {
			String sql = generteSql(kmpa,true);
			session = getSessionFactory().openSession();
			Query query = null;
			query = session.createSQLQuery(sql).addEntity(KmProductClass.class);
			query.setFirstResult(size * (page - 1));
			query.setMaxResults(size);
			List<KmProductClass> kmProductClass = query.list();
			return kmProductClass;
		} catch (RuntimeException re) {
			re.printStackTrace();
			log.error("find by findPfOperateLogForPage failed", re);
			throw re;
		} finally {
			if (session != null)
				session.close();
		}
		
	}
	public String generteSql(KmProductClass pflog,boolean flag){
		   StringBuffer sb=new StringBuffer();
		     if(flag){
		    	 sb.append(" select * from km_Product_Class k  where 1=1  and k.status='1' and k.channelid in ( select  id from km_rss_channel where  status='1') ");
		     }else{
		    	 sb.append("  select count(*) from Km_Product_Class  k  where 1=1 and k.status='1' and k.channelid in ( select  id from km_rss_channel where  status='1') ");
		     }
		      
			if(pflog!=null){
				
//				if(!StringUtils.isEmpty(pflog.getAuthor())&&pflog.getAuthor()!="")
//					sb.append(" and author ").append(" like  "+pflog.getAuthor());
//				
//				if(!StringUtils.isEmpty(pflog.getTitle())&&pflog.getTitle()!="")
//					sb.append(" and title").append(" like  '"+pflog.getTitle() +"' ");
			}
			
				sb.append(" order by k.id desc");
			
			logger.info("findFbbOperateLogForPage: sql:"+sb.toString());
			return sb.toString();
		   
	}
	public KmProductClass findById(java.lang.Long id) {
		log.debug("getting KmProductClass instance with id: " + id);
		try {
			KmProductClass instance = (KmProductClass) getHibernateTemplate().get(
					"com.kdma.kmmodel.KmProductClass", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
	
	public int countByFilter(KmProductClass kmProductClass){
		Session session=null;
		int count=0;
		try{
			String sql=generteSql(kmProductClass,false);
			session = getSessionFactory().openSession();
			SQLQuery query = session.createSQLQuery(sql);
			
			count = ((Number)query.uniqueResult()).intValue(); 
		}catch(RuntimeException re){
			log.error("find by  getParentCount ", re);
			count=0;
			throw re;
		}finally{
			if(session!=null)
				session.close();
		}
		return count;
	}
	public static KmProductClassDao getFromApplicationContext(ApplicationContext ctx) {
		return (KmProductClassDao) ctx.getBean("KmProductClassDao");
	}
}
