package com.kidmate.model;

import java.util.List;

import javax.persistence.Entity;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;




@Entity
public class KmRssDao extends HibernateDaoSupport{
	private static final Log log = LogFactory.getLog(KmRssDao.class);
	
	
	public void save(KmRss transientInstance) {
		log.debug("saving KmRss instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}
	public void delete(KmRss persistentInstance) {
		log.debug("deleting KmRss instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}
	public List findByProperty(String propertyName, Object value) {
		log.debug("finding KmRss instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from KmRss as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}
	public List findAll() {
		log.debug("finding all KmChild instances");
		try {
			String queryString = "from KmRss";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}
	
	public void attachDirty(KmRss instance) {
		log.debug("attaching dirty KmRss instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}
//  分页加条件查询
	public List<KmRss> findByFiltPage(KmRss kmpa,int size, int page){
		Session session = null;
		try {
			String sql = generteSql(kmpa,true);
			session = getSessionFactory().openSession();
			Query query = null;
			query = session.createSQLQuery(sql).addEntity(KmRss.class);
			query.setFirstResult(size * (page - 1));
			query.setMaxResults(size);
			List<KmRss> KmRss = query.list();
			return KmRss;
		} catch (RuntimeException re) {
			re.printStackTrace();
			log.error("find by findPfOperateLogForPage failed", re);
			throw re;
		} finally {
			if (session != null)
				session.close();
		}
		
	}
	
	public List<KmRss> findByChannelPage(int size,int page){
		Session session = null;
		try {
			String sql = " select * from km_rss k  where 1=1 and k.channelid in (select id from km_rss_channel where title='教育' )  and k.status='1' order by k.id desc";
			session = getSessionFactory().openSession();
			Query query = null;
			query = session.createSQLQuery(sql).addEntity(KmRss.class);
			query.setFirstResult(size * (page - 1));
			query.setMaxResults(size);
			List<KmRss> KmRss = query.list();
			return KmRss;
		} catch (RuntimeException re) {
			re.printStackTrace();
			log.error("find by findPfOperateLogForPage failed", re);
			throw re;
		} finally {
			if (session != null)
				session.close();
		}
	
	}
	public String generteSql(KmRss pflog,boolean flag){
		   StringBuffer sb=new StringBuffer();
		     if(flag){
		    	 sb.append("  select * from km_rss k  where 1=1 ");
		     }else{
		    	 sb.append("  select count(*) from km_rss  k  where 1=1 ");
		     }
		      
			if(pflog!=null){
				
				if(!StringUtils.isEmpty(pflog.getAuthor())&&pflog.getAuthor()!="")
					sb.append(" and author ").append(" like  "+pflog.getAuthor());
				
				if(!StringUtils.isEmpty(pflog.getTitle())&&pflog.getTitle()!="")
					sb.append(" and title").append(" like  '"+pflog.getTitle() +"' ");
			}
			
				sb.append(" order by k.createtime desc");
			
			logger.info("findFbbOperateLogForPage: sql:"+sb.toString());
			return sb.toString();
		   
	}
	
	public int countByFilter(KmRss kmRss){
		Session session=null;
		int count=0;
		try{
			String sql=generteSql(kmRss,false);
			session = getSessionFactory().openSession();
			SQLQuery query = session.createSQLQuery(sql);
			
			count = ((Number)query.uniqueResult()).intValue(); 
		}catch(RuntimeException re){
			log.error("find by  getParentCount ", re);
			count=0;
			throw re;
		}finally{
			if(session!=null)
				session.close();
		}
		return count;
	}
	public static KmRssDao getFromApplicationContext(ApplicationContext ctx) {
		return (KmRssDao) ctx.getBean("KmRssDao");
	}
}
