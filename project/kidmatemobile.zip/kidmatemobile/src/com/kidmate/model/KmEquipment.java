package com.kidmate.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * KmEquipment entity. @author MyEclipse Persistence Tools
 */

@Entity
public class KmEquipment implements java.io.Serializable {

	// Fields

	private Long id;
	private Long parentid;
	private String equipmenttype;
	private String alias;
	private String mac;
	private String sign;
	private Integer regsource;
	private String regip;
	private String lastip;
	private Date createtime;
	private Date lastupdate;
	
	private  String token;
    private  String pushMagic;
    private  String udid;
    private  String unlockToken;
    private  String topic;
    
	private String status;

	// Constructors

	/** default constructor */
	public KmEquipment() {
	}

	/** minimal constructor */
	public KmEquipment(Long id) {
		this.id = id;
	}

	/** full constructor */
	public KmEquipment(Long id, Long parentid, String equipmenttype,
			String alias, String mac, String sign, Integer regsource,
			String token, String pushMagic, String udid,String unlockToken,
			String regip, String lastip, Date createtime, Date lastupdate,
			String status,String topic) {
		this.id = id;
		this.parentid = parentid;
		this.equipmenttype = equipmenttype;
		this.alias = alias;
		this.mac = mac;
		this.sign = sign;
		this.regsource = regsource;
		this.regip = regip;
		this.lastip = lastip;
		this.createtime = createtime;
		this.lastupdate = lastupdate;
		this.status = status;
		this.token=token;
		this.topic=topic;
		this.pushMagic=pushMagic;
		this.udid=udid;
		this.unlockToken=unlockToken;
		
	}

	// Property accessors

	@Id
	@GeneratedValue
	public Long getId() {
		return this.id;
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getParentid() {
		return this.parentid;
	}

	public void setParentid(Long parentid) {
		this.parentid = parentid;
	}

	public String getEquipmenttype() {
		return this.equipmenttype;
	}

	public void setEquipmenttype(String equipmenttype) {
		this.equipmenttype = equipmenttype;
	}

	public String getAlias() {
		return this.alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getMac() {
		return this.mac;
	}

	public void setMac(String mac) {
		this.mac = mac;
	}

	public String getSign() {
		return this.sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public Integer getRegsource() {
		return this.regsource;
	}

	public void setRegsource(Integer regsource) {
		this.regsource = regsource;
	}

	public String getRegip() {
		return this.regip;
	}

	public void setRegip(String regip) {
		this.regip = regip;
	}

	public String getLastip() {
		return this.lastip;
	}

	public void setLastip(String lastip) {
		this.lastip = lastip;
	}

	public Date getCreatetime() {
		return this.createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public Date getLastupdate() {
		return this.lastupdate;
	}

	public void setLastupdate(Date lastupdate) {
		this.lastupdate = lastupdate;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getPushMagic() {
		return pushMagic;
	}

	public void setPushMagic(String pushMagic) {
		this.pushMagic = pushMagic;
	}

	public String getUdid() {
		return udid;
	}

	public void setUdid(String udid) {
		this.udid = udid;
	}

	public String getUnlockToken() {
		return unlockToken;
	}

	public void setUnlockToken(String unlockToken) {
		this.unlockToken = unlockToken;
	}
	
	

}