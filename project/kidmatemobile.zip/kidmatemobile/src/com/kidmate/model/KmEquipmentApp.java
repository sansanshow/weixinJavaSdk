package com.kidmate.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * KmEquipmentApp entity. @author MyEclipse Persistence Tools
 */

@Entity
public class KmEquipmentApp implements java.io.Serializable {

	// Fields

	private Long id;
	private Long equipmentid;
	private Long appid;
	private String version;
	private Date createtime;
	private String status;

	// Constructors

	/** default constructor */
	public KmEquipmentApp() {
	}

	/** minimal constructor */
	public KmEquipmentApp(Long id) {
		this.id = id;
	}

	/** full constructor */
	public KmEquipmentApp(Long id, Long equipmentid, Long appid,
			String version, Date createtime, String status) {
		this.id = id;
		this.equipmentid = equipmentid;
		this.appid = appid;
		this.version = version;
		this.createtime = createtime;
		this.status = status;
	}

	// Property accessors

	@Id
	@GeneratedValue
	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getEquipmentid() {
		return this.equipmentid;
	}

	public void setEquipmentid(Long equipmentid) {
		this.equipmentid = equipmentid;
	}

	public Long getAppid() {
		return this.appid;
	}

	public void setAppid(Long appid) {
		this.appid = appid;
	}

	public String getVersion() {
		return this.version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public Date getCreatetime() {
		return this.createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}