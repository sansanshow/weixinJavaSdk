package com.kidmate.model;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class KmProductDao extends HibernateDaoSupport{
private static final Log log = LogFactory.getLog(KmProductDao.class);
	
	
	public void save(KmProduct transientInstance) {
		log.debug("saving KmProduct instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}
	public void delete(KmProduct persistentInstance) {
		log.debug("deleting KmProduct instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}
	public List findByProperty(String propertyName, Object value) {
		log.debug("finding KmProduct instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from KmProduct as model where model."
					+ propertyName + "= ? order by model.createtime desc";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}
	
	public List findAll() {
		log.debug("finding all KmChild instances");
		try {
			String queryString = "from KmProduct";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}
	
	public void attachDirty(KmProduct instance) {
		log.debug("attaching dirty KmProduct instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}
	
	public List<KmProduct> findByCategoryPage(int size,int page,long cid){
		Session session = null;
		try {
			String sql = " select * from km_Product k  where 1=1 and k.cid="+cid+"  and k.status='1' order by k.createtime desc";
			session = getSessionFactory().openSession();
			Query query = null;
			query = session.createSQLQuery(sql).addEntity(KmProduct.class);
			query.setFirstResult(size * (page - 1));
			query.setMaxResults(size);
			List<KmProduct> KmProduct = query.list();
			return KmProduct;
		} catch (RuntimeException re) {
			re.printStackTrace();
			log.error("find by findPfOperateLogForPage failed", re);
			throw re;
		} finally {
			if (session != null)
				session.close();
		}
	
	}
	
	public List<KmProduct> findBylistCaPage(int size,int page,List cid){
		Session session = null;
		try {
			String sql = " select * from km_Product k  where 1=1 and k.cid in (:pn)  and k.status='1' order by k.createtime desc";
			session = getSessionFactory().openSession();
			Query query = null;
			query = session.createSQLQuery(sql).addEntity(KmProduct.class);
			query.setParameterList("pn", cid);
			query.setFirstResult(size * (page - 1));
			query.setMaxResults(size);
			List<KmProduct> KmProduct = query.list();
			return KmProduct;
		} catch (RuntimeException re) {
			re.printStackTrace();
			log.error("find by findPfOperateLogForPage failed", re);
			throw re;
		} finally {
			if (session != null)
				session.close();
		}
	
	}
	
//  分页加条件查询
	public List<KmProduct> findByFiltPage(KmProduct kmpa,int size, int page){
		Session session = null;
		try {
			String sql = generteSql(kmpa,true);
			session = getSessionFactory().openSession();
			Query query = null;
			query = session.createSQLQuery(sql).addEntity(KmProduct.class);
			query.setFirstResult(size * (page - 1));
			query.setMaxResults(size);
			List<KmProduct> kmProduct = query.list();
			return kmProduct;
		} catch (RuntimeException re) {
			re.printStackTrace();
			log.error("find by findPfOperateLogForPage failed", re);
			throw re;
		} finally {
			if (session != null)
				session.close();
		}
		
	}
	public String generteSql(KmProduct pflog,boolean flag){
		   StringBuffer sb=new StringBuffer();
		     if(flag){
		    	 sb.append(" select * from km_Product k  where 1=1  and k.status='1' and k.cid in ( select  id from km_product_class where  status='1') ");
		     }else{
		    	 sb.append("  select count(*) from km_Product  k  where 1=1 and k.status='1' and k.cid in ( select  id from km_product_class where  status='1') ");
		     }
		      
			if(pflog!=null){
				

			}
			
				sb.append(" order by k.id desc");
			
			logger.info("findFbbOperateLogForPage: sql:"+sb.toString());
			return sb.toString();
		   
	}
	public KmProduct findById(java.lang.Long id) {
		log.debug("getting KmProduct instance with id: " + id);
		try {
			KmProduct instance = (KmProduct) getHibernateTemplate().get(
					"com.kdma.kmmodel.KmProduct", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
	
	public int countByFilter(KmProduct kmProduct){
		Session session=null;
		int count=0;
		try{
			String sql=generteSql(kmProduct,false);
			session = getSessionFactory().openSession();
			SQLQuery query = session.createSQLQuery(sql);
			
			count = ((Number)query.uniqueResult()).intValue(); 
		}catch(RuntimeException re){
			log.error("find by  getParentCount ", re);
			count=0;
			throw re;
		}finally{
			if(session!=null)
				session.close();
		}
		return count;
	}
	public static KmProductDao getFromApplicationContext(ApplicationContext ctx) {
		return (KmProductDao) ctx.getBean("KmProductDao");
	}
}
