package com.kidmate.model;

import java.io.Serializable;
import java.util.Date;

public class KmGuardian implements Serializable {
   
	private Long id;
	private Long parentId; // 主家长id
	private Long cparentId; // 次
	private Long childId;
	private String status;
	private Date createtime;
	private String type;
	
	public KmGuardian(){
		
	}
	
   public KmGuardian(Long id,Long parentId, Long cparentId ,Long childId, 
		   String status ,String type,Date createtime){
		this.id=id;
		this.parentId=parentId;
		this.cparentId=cparentId;
		
		this.childId=childId;
		this.status=status;
		this.type=type;
		this.createtime=createtime;
	}
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getParentId() {
		return parentId;
	}
	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
	public Long getCparentId() {
		return cparentId;
	}
	public void setCparentId(Long cparentId) {
		this.cparentId = cparentId;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public Long getChildId() {
		return childId;
	}

	public void setChildId(Long childId) {
		this.childId = childId;
	}
	
	
	
}
