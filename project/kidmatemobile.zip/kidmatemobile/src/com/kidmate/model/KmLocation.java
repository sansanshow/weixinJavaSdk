package com.kidmate.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * KmLocation entity. @author MyEclipse Persistence Tools
 */

@Entity
public class KmLocation implements java.io.Serializable {

	// Fields

	private Long id;
	private Long equipmentid;
	private Double longitude;
	private Double latitude;
	private Date createtime;

	// Constructors

	/** default constructor */
	public KmLocation() {
	}

	/** minimal constructor */
	public KmLocation(Long id) {
		this.id = id;
	}

	/** full constructor */
	public KmLocation(Long id, Long equipmentid, Double longitude,
			Double latitude, Date createtime) {
		this.id = id;
		this.equipmentid = equipmentid;
		this.longitude = longitude;
		this.latitude = latitude;
		this.createtime = createtime;
	}

	// Property accessors

	@Id
	@GeneratedValue
	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getEquipmentid() {
		return this.equipmentid;
	}

	public void setEquipmentid(Long equipmentid) {
		this.equipmentid = equipmentid;
	}

	public Double getLongitude() {
		return this.longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Double getLatitude() {
		return this.latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Date getCreatetime() {
		return this.createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

}