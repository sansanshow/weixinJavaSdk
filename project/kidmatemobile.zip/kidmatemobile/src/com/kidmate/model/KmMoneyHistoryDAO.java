package com.kidmate.model;

import java.util.Date;
import java.util.List;
import javax.persistence.Entity;
import org.hibernate.LockMode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * A data access object (DAO) providing persistence and search support for
 * KmMoneyHistory entities. Transaction control of the save(), update() and
 * delete() operations can directly support Spring container-managed
 * transactions or they can be augmented to handle user-managed Spring
 * transactions. Each of these methods provides additional information for how
 * to configure it for the desired type of transaction control.
 * 
 * @see com.kidmate.model.KmMoneyHistory
 * @author MyEclipse Persistence Tools
 */

@Entity
public class KmMoneyHistoryDAO extends HibernateDaoSupport {
	private static final Logger log = LoggerFactory
			.getLogger(KmMoneyHistoryDAO.class);
	// property constants
	public static final String USERID = "userid";
	public static final String MONEY = "money";
	public static final String REMARK = "remark";
	public static final String IP = "ip";

	protected void initDao() {
		// do nothing
	}

	public void save(KmMoneyHistory transientInstance) {
		log.debug("saving KmMoneyHistory instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(KmMoneyHistory persistentInstance) {
		log.debug("deleting KmMoneyHistory instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public KmMoneyHistory findById(java.lang.Long id) {
		log.debug("getting KmMoneyHistory instance with id: " + id);
		try {
			KmMoneyHistory instance = (KmMoneyHistory) getHibernateTemplate()
					.get("com.kidmate.model.KmMoneyHistory", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(KmMoneyHistory instance) {
		log.debug("finding KmMoneyHistory instance by example");
		try {
			List results = getHibernateTemplate().findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding KmMoneyHistory instance with property: "
				+ propertyName + ", value: " + value);
		try {
			String queryString = "from KmMoneyHistory as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List findByUserid(Object userid) {
		return findByProperty(USERID, userid);
	}

	public List findByMoney(Object money) {
		return findByProperty(MONEY, money);
	}

	public List findByRemark(Object remark) {
		return findByProperty(REMARK, remark);
	}

	public List findByIp(Object ip) {
		return findByProperty(IP, ip);
	}

	public List findAll() {
		log.debug("finding all KmMoneyHistory instances");
		try {
			String queryString = "from KmMoneyHistory";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public KmMoneyHistory merge(KmMoneyHistory detachedInstance) {
		log.debug("merging KmMoneyHistory instance");
		try {
			KmMoneyHistory result = (KmMoneyHistory) getHibernateTemplate()
					.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(KmMoneyHistory instance) {
		log.debug("attaching dirty KmMoneyHistory instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(KmMoneyHistory instance) {
		log.debug("attaching clean KmMoneyHistory instance");
		try {
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public static KmMoneyHistoryDAO getFromApplicationContext(
			ApplicationContext ctx) {
		return (KmMoneyHistoryDAO) ctx.getBean("KmMoneyHistoryDAO");
	}
}