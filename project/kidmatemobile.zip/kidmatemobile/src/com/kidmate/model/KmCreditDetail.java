package com.kidmate.model;

import java.util.Date;

/**
 * KmCreditDetail entity. @author MyEclipse Persistence Tools
 */

public class KmCreditDetail implements java.io.Serializable {

	// Fields

	private Long id;
	private Long pid;
	private Long credit;
	private Long creditchange;
	private Long typeid;
	private Date createtime;
	private String status;

	// Constructors

	/** default constructor */
	public KmCreditDetail() {
	}

	/** full constructor */
	public KmCreditDetail(Long pid, Long credit, Long creditchange,
			Long typeid, Date createtime, String status) {
		this.pid = pid;
		this.credit = credit;
		this.creditchange = creditchange;
		this.typeid = typeid;
		this.createtime = createtime;
		this.status = status;
	}

	// Property accessors

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getPid() {
		return this.pid;
	}

	public void setPid(Long pid) {
		this.pid = pid;
	}

	public Long getCredit() {
		return this.credit;
	}

	public void setCredit(Long credit) {
		this.credit = credit;
	}

	public Long getCreditchange() {
		return this.creditchange;
	}

	public void setCreditchange(Long creditchange) {
		this.creditchange = creditchange;
	}

	public Long getTypeid() {
		return this.typeid;
	}

	public void setTypeid(Long typeid) {
		this.typeid = typeid;
	}

	public Date getCreatetime() {
		return this.createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}