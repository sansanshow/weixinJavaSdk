package com.kidmate.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class KmRssChannel  implements Serializable{
	private Long id;
	private String name;
	private String title;
	private String description;
	private String author;
	private String link;
	private String linkmode;
	private Date createtime;
	private String status;

	public KmRssChannel() {

	}

	public KmRssChannel(long id, String name, String title, String description,
			String author, String link, String linkmode, Date createtime,
			String status) {
      this.id=id;
      this.name=name;
      this.title=title;
      this.description=description;
      this.author=author;
      this.link=link;
      this.linkmode=linkmode;
      this.createtime=createtime;
      this.status=status;
	}

	@Id
	@GeneratedValue
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getLinkmode() {
		return linkmode;
	}

	public void setLinkmode(String linkmode) {
		this.linkmode = linkmode;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
