package com.kidmate.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * KmWifi entity. @author MyEclipse Persistence Tools
 */

@Entity
public class KmWifi implements java.io.Serializable {

	// Fields

	private Long id;
	private Long equipmentid;
	private String wifiname;
	private String wifissid;
	private String ip;
	private Date createtime;

	// Constructors

	/** default constructor */
	public KmWifi() {
	}

	/** minimal constructor */
	public KmWifi(Long id) {
		this.id = id;
	}

	/** full constructor */
	public KmWifi(Long id, Long equipmentid, String wifiname, String wifissid,
			String ip, Date createtime) {
		this.id = id;
		this.equipmentid = equipmentid;
		this.wifiname = wifiname;
		this.wifissid = wifissid;
		this.ip = ip;
		this.createtime = createtime;
	}

	// Property accessors

	@Id
	@GeneratedValue
	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getEquipmentid() {
		return this.equipmentid;
	}

	public void setEquipmentid(Long equipmentid) {
		this.equipmentid = equipmentid;
	}

	public String getWifiname() {
		return this.wifiname;
	}

	public void setWifiname(String wifiname) {
		this.wifiname = wifiname;
	}

	public String getWifissid() {
		return this.wifissid;
	}

	public void setWifissid(String wifissid) {
		this.wifissid = wifissid;
	}

	public String getIp() {
		return this.ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public Date getCreatetime() {
		return this.createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

}