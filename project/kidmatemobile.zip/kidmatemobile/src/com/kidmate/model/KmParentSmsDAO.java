package com.kidmate.model;

import java.util.Date;
import java.util.List;
import javax.persistence.Entity;
import org.hibernate.LockMode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * A data access object (DAO) providing persistence and search support for
 * KmParentSms entities. Transaction control of the save(), update() and
 * delete() operations can directly support Spring container-managed
 * transactions or they can be augmented to handle user-managed Spring
 * transactions. Each of these methods provides additional information for how
 * to configure it for the desired type of transaction control.
 * 
 * @see com.kidmate.model.KmParentSms
 * @author MyEclipse Persistence Tools
 */

@Entity
public class KmParentSmsDAO extends HibernateDaoSupport {
	private static final Logger log = LoggerFactory
			.getLogger(KmParentSmsDAO.class);
	// property constants
	public static final String MSG = "msg";
	public static final String MSGTYPE = "msgtype";
	public static final String MOBILES = "mobiles";
	public static final String STATUS = "status";
	public static final String FUNCTIONNAME = "functionname";
	public static final String OPENID = "openid";
	public static final String VERIFY_CODE = "verifyCode";

	protected void initDao() {
		// do nothing
	}

	public void save(KmParentSms transientInstance) {
		log.debug("saving KmParentSms instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(KmParentSms persistentInstance) {
		log.debug("deleting KmParentSms instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public KmParentSms findById(java.lang.Long id) {
		log.debug("getting KmParentSms instance with id: " + id);
		try {
			KmParentSms instance = (KmParentSms) getHibernateTemplate().get(
					"com.kidmate.model.KmParentSms", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(KmParentSms instance) {
		log.debug("finding KmParentSms instance by example");
		try {
			List results = getHibernateTemplate().findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding KmParentSms instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from KmParentSms as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List findByMsg(Object msg) {
		return findByProperty(MSG, msg);
	}

	public List findByMsgtype(Object msgtype) {
		return findByProperty(MSGTYPE, msgtype);
	}

	public List findByMobiles(Object mobiles) {
		return findByProperty(MOBILES, mobiles);
	}

	public List findByStatus(Object status) {
		return findByProperty(STATUS, status);
	}

	public List findByFunctionname(Object functionname) {
		return findByProperty(FUNCTIONNAME, functionname);
	}

	public List findByOpenid(Object openid) {
		return findByProperty(OPENID, openid);
	}

	public List findByVerifyCode(Object verifyCode) {
		return findByProperty(VERIFY_CODE, verifyCode);
	}

	public List findAll() {
		log.debug("finding all KmParentSms instances");
		try {
			String queryString = "from KmParentSms";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public KmParentSms merge(KmParentSms detachedInstance) {
		log.debug("merging KmParentSms instance");
		try {
			KmParentSms result = (KmParentSms) getHibernateTemplate().merge(
					detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(KmParentSms instance) {
		log.debug("attaching dirty KmParentSms instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(KmParentSms instance) {
		log.debug("attaching clean KmParentSms instance");
		try {
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public static KmParentSmsDAO getFromApplicationContext(
			ApplicationContext ctx) {
		return (KmParentSmsDAO) ctx.getBean("KmParentSmsDAO");
	}
}