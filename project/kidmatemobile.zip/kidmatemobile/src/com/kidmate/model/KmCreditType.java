package com.kidmate.model;

import java.util.Date;


/**
 * KmCreditType entity. @author MyEclipse Persistence Tools
 */

public class KmCreditType  implements java.io.Serializable {


    // Fields    

     private long id;
     private String description;
     private long credit;
     private String name;
     private Date createtime;
     private String status;


    // Constructors

    /** default constructor */
    public KmCreditType() {
    }

    
    /** full constructor */
    public KmCreditType(String description, long credit, String name, Date createtime, String status) {
        this.description = description;
        this.credit = credit;
        this.name = name;
        this.createtime = createtime;
        this.status = status;
    }

   
    // Property accessors

    public long getId() {
        return this.id;
    }
    
    public void setId(long id) {
        this.id = id;
    }

    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }

    public long getCredit() {
        return this.credit;
    }
    
    public void setCredit(long credit) {
        this.credit = credit;
    }

    public String getName() {
        return this.name;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public Date getCreatetime() {
        return this.createtime;
    }
    
    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public String getStatus() {
        return this.status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
   








}