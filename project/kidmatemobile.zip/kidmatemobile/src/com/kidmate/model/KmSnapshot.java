package com.kidmate.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class KmSnapshot  implements java.io.Serializable{
    
	private Long id;
	private Long equipmentid;
	private String url;
	private Double longitude;
	private Double latitude;
    private String addr;
	private Date createtime;
	private String status;
	
	public KmSnapshot(){
		
	};
	
	public KmSnapshot(Long id){
		this.id=id;
	}
	
	
	public KmSnapshot(Long id, Long equipmentid,String url, Double longitude, Double latitude,
			String addr, Date createtime, String status) {
		this.id = id;
		this.equipmentid=equipmentid;
		this.url = url;
		this.longitude = longitude;
		this.latitude = latitude;
		this.addr = addr;
		this.createtime = createtime;
		this.status = status;
	}
	
	
	
	@Id
	@GeneratedValue
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public Date getCreatetime() {
		return createtime;
	}
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public Long getEquipmentid() {
		return equipmentid;
	}

	public void setEquipmentid(Long equipmentid) {
		this.equipmentid = equipmentid;
	}
	
	
	
	
}
