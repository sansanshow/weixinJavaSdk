package com.kidmate.model;

import java.util.Date;
import java.util.List;
import javax.persistence.Entity;
import org.hibernate.LockMode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * A data access object (DAO) providing persistence and search support for
 * KmParent entities. Transaction control of the save(), update() and delete()
 * operations can directly support Spring container-managed transactions or they
 * can be augmented to handle user-managed Spring transactions. Each of these
 * methods provides additional information for how to configure it for the
 * desired type of transaction control.
 * 
 * @see com.kidmate.model.KmParent
 * @author MyEclipse Persistence Tools
 */

@Entity
public class KmParentDAO extends HibernateDaoSupport {
	private static final Logger log = LoggerFactory
			.getLogger(KmParentDAO.class);
	// property constants
	public static final String MOBILE = "mobile";
	public static final String USERNAME = "username";
	public static final String PASSWORD = "password";
	public static final String SIGN = "sign";
	public static final String NAME = "name";
	public static final String HEAD = "head";
	public static final String LASTLOGINIP = "lastloginip";
	public static final String OPENACCOUNTID = "openaccountid";
	public static final String MD5TOKEN = "md5token";
	public static final String SOURCEID = "sourceid";
	public static final String TOKEN = "token";
	public static final String REGSOURCE = "regsource";
	public static final String REGIP = "regip";
	public static final String PHONETYPE = "phonetype";
	public static final String PHONEMAC = "phonemac";
	public static final String GROUPTYPE = "grouptype";
	public static final String STATUS = "status";
	public static final String INVITECODE = "invitecode";
	public static final String WXOPENID = "wxopenid";

	protected void initDao() {
		// do nothing
	}

	public void save(KmParent transientInstance) {
		log.debug("saving KmParent instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(KmParent persistentInstance) {
		log.debug("deleting KmParent instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public KmParent findById(java.lang.Long id) {
		log.debug("getting KmParent instance with id: " + id);
		try {
			KmParent instance = (KmParent) getHibernateTemplate().get(
					"com.kidmate.model.KmParent", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(KmParent instance) {
		log.debug("finding KmParent instance by example");
		try {
			List results = getHibernateTemplate().findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding KmParent instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from KmParent as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List findByMobile(Object mobile) {
		return findByProperty(MOBILE, mobile);
	}

	public List findByUsername(Object username) {
		return findByProperty(USERNAME, username);
	}

	public List findByPassword(Object password) {
		return findByProperty(PASSWORD, password);
	}

	public List findBySign(Object sign) {
		return findByProperty(SIGN, sign);
	}

	public List findByName(Object name) {
		return findByProperty(NAME, name);
	}

	public List findByHead(Object head) {
		return findByProperty(HEAD, head);
	}

	public List findByLastloginip(Object lastloginip) {
		return findByProperty(LASTLOGINIP, lastloginip);
	}

	public List findByOpenaccountid(Object openaccountid) {
		return findByProperty(OPENACCOUNTID, openaccountid);
	}

	public List findByMd5token(Object md5token) {
		return findByProperty(MD5TOKEN, md5token);
	}

	public List findBySourceid(Object sourceid) {
		return findByProperty(SOURCEID, sourceid);
	}

	public List findByToken(Object token) {
		return findByProperty(TOKEN, token);
	}

	public List findByRegsource(Object regsource) {
		return findByProperty(REGSOURCE, regsource);
	}

	public List findByRegip(Object regip) {
		return findByProperty(REGIP, regip);
	}

	public List findByPhonetype(Object phonetype) {
		return findByProperty(PHONETYPE, phonetype);
	}

	public List findByPhonemac(Object phonemac) {
		return findByProperty(PHONEMAC, phonemac);
	}

	public List findByGrouptype(Object grouptype) {
		return findByProperty(GROUPTYPE, grouptype);
	}

	public List findByStatus(Object status) {
		return findByProperty(STATUS, status);
	}

	public List findByInvitecode(Object invitecode) {
		return findByProperty(INVITECODE, invitecode);
	}

	public List findByWxopenid(Object wxopenid) {
		return findByProperty(WXOPENID, wxopenid);
	}

	public List findAll() {
		log.debug("finding all KmParent instances");
		try {
			String queryString = "from KmParent";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public KmParent merge(KmParent detachedInstance) {
		log.debug("merging KmParent instance");
		try {
			KmParent result = (KmParent) getHibernateTemplate().merge(
					detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(KmParent instance) {
		log.debug("attaching dirty KmParent instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(KmParent instance) {
		log.debug("attaching clean KmParent instance");
		try {
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public static KmParentDAO getFromApplicationContext(ApplicationContext ctx) {
		return (KmParentDAO) ctx.getBean("KmParentDAO");
	}
}