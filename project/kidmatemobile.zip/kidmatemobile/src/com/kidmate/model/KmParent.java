package com.kidmate.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * KmParent entity. @author MyEclipse Persistence Tools
 */

@Entity
public class KmParent implements java.io.Serializable {

	// Fields

	private Long id;
	private String mobile;
	private String username;
	private String password;
	private String sign;
	private String name;
	private String head;
	private Date lastlogintime;
	private String lastloginip;
	private String openaccountid;
	private String md5token;
	private Long sourceid;
	private String token;
	private Short regsource;
	private Date regtime;
	private String regip;
	private String phonetype;
	private String phonemac;
	private Date vip;
	private Integer grouptype;
	private String status;
	private String invitecode;
	private String wxopenid;
    private String channel;
	// Constructors

	/** default constructor */
	public KmParent() {
	}

	/** minimal constructor */
	public KmParent(Long id) {
		this.id = id;
	}

	/** full constructor */
	public KmParent(Long id, String mobile, String username, String password,
			String sign, String name, String head, Date lastlogintime,
			String lastloginip, String openaccountid, String md5token,
			Long sourceid, String token, Short regsource, Date regtime,
			String regip, String phonetype, String phonemac, Date vip,
			Integer grouptype, String status, String invitecode, String wxopenid,String channel) {
		this.id = id;
		this.mobile = mobile;
		this.username = username;
		this.password = password;
		this.sign = sign;
		this.name = name;
		this.head = head;
		this.lastlogintime = lastlogintime;
		this.lastloginip = lastloginip;
		this.openaccountid = openaccountid;
		this.md5token = md5token;
		this.sourceid = sourceid;
		this.token = token;
		this.regsource = regsource;
		this.regtime = regtime;
		this.regip = regip;
		this.phonetype = phonetype;
		this.phonemac = phonemac;
		this.vip = vip;
		this.grouptype = grouptype;
		this.status = status;
		this.invitecode = invitecode;
		this.wxopenid = wxopenid;
		this.channel=channel;
	}

	// Property accessors

	@Id
	@GeneratedValue
	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMobile() {
		return this.mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSign() {
		return this.sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHead() {
		return this.head;
	}

	public void setHead(String head) {
		this.head = head;
	}

	public Date getLastlogintime() {
		return this.lastlogintime;
	}

	public void setLastlogintime(Date lastlogintime) {
		this.lastlogintime = lastlogintime;
	}

	public String getLastloginip() {
		return this.lastloginip;
	}

	public void setLastloginip(String lastloginip) {
		this.lastloginip = lastloginip;
	}

	public String getOpenaccountid() {
		return this.openaccountid;
	}

	public void setOpenaccountid(String openaccountid) {
		this.openaccountid = openaccountid;
	}

	public String getMd5token() {
		return this.md5token;
	}

	public void setMd5token(String md5token) {
		this.md5token = md5token;
	}

	public Long getSourceid() {
		return this.sourceid;
	}

	public void setSourceid(Long sourceid) {
		this.sourceid = sourceid;
	}

	public String getToken() {
		return this.token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public Short getRegsource() {
		return this.regsource;
	}

	public void setRegsource(Short regsource) {
		this.regsource = regsource;
	}

	public Date getRegtime() {
		return this.regtime;
	}

	public void setRegtime(Date regtime) {
		this.regtime = regtime;
	}

	public String getRegip() {
		return this.regip;
	}

	public void setRegip(String regip) {
		this.regip = regip;
	}

	public String getPhonetype() {
		return this.phonetype;
	}

	public void setPhonetype(String phonetype) {
		this.phonetype = phonetype;
	}

	public String getPhonemac() {
		return this.phonemac;
	}

	public void setPhonemac(String phonemac) {
		this.phonemac = phonemac;
	}

	public Date getVip() {
		return this.vip;
	}

	public void setVip(Date vip) {
		this.vip = vip;
	}

	public Integer getGrouptype() {
		return this.grouptype;
	}

	public void setGrouptype(Integer grouptype) {
		this.grouptype = grouptype;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getInvitecode() {
		return this.invitecode;
	}

	public void setInvitecode(String invitecode) {
		this.invitecode = invitecode;
	}

	public String getWxopenid() {
		return this.wxopenid;
	}

	public void setWxopenid(String wxopenid) {
		this.wxopenid = wxopenid;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	

}