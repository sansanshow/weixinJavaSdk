package com.kidmate.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class KmRss  implements Serializable{
	private Long id;
	private Long channelId;
	private String title;
	private String description;
	private Date pubdate;
	private String link;
	private String category;
	private String author;
	private Date createtime;
	private String status;
	
	public KmRss(){
		
	}

	public KmRss(Long id, Long channelId, String title, String description,
			Date pubdate, String link, String category, String author,
			Date createtime, String status) {
         this.id=id;
         this.channelId=channelId;
         this.title=title;
         this.description=description;
         this.pubdate=pubdate;
         this.link=link;
         this.category=category;
         this.author=author;
         this.createtime=createtime;
         this.status=status;
	}
	@Id
	@GeneratedValue
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public Long getChannelId() {
		return channelId;
	}

	public void setChannelId(Long channelId) {
		this.channelId = channelId;
	}

	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getPubdate() {
		return pubdate;
	}
	public void setPubdate(Date pubdate) {
		this.pubdate = pubdate;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public Date getCreatetime() {
		return createtime;
	}
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	
	
}
