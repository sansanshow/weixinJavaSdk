package com.kidmate.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * KmParentSms entity. @author MyEclipse Persistence Tools
 */

@Entity
public class KmParentSms implements java.io.Serializable {

	// Fields

	private Long id;
	private String msg;
	private Integer msgtype;
	private String mobiles;
	private Date createtime;
	private Date sendtime;
	private String status;
	private String functionname;
	private String openid;
	private String verifyCode;

	// Constructors

	/** default constructor */
	public KmParentSms() {
	}

	/** minimal constructor */
	public KmParentSms(Long id) {
		this.id = id;
	}

	/** full constructor */
	public KmParentSms(Long id, String msg, Integer msgtype, String mobiles,
			Date createtime, Date sendtime, String status, String functionname,
			String openid, String verifyCode) {
		this.id = id;
		this.msg = msg;
		this.msgtype = msgtype;
		this.mobiles = mobiles;
		this.createtime = createtime;
		this.sendtime = sendtime;
		this.status = status;
		this.functionname = functionname;
		this.openid = openid;
		this.verifyCode = verifyCode;
	}

	// Property accessors

	@Id
	@GeneratedValue
	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMsg() {
		return this.msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Integer getMsgtype() {
		return this.msgtype;
	}

	public void setMsgtype(Integer msgtype) {
		this.msgtype = msgtype;
	}

	public String getMobiles() {
		return this.mobiles;
	}

	public void setMobiles(String mobiles) {
		this.mobiles = mobiles;
	}

	public Date getCreatetime() {
		return this.createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public Date getSendtime() {
		return this.sendtime;
	}

	public void setSendtime(Date sendtime) {
		this.sendtime = sendtime;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFunctionname() {
		return this.functionname;
	}

	public void setFunctionname(String functionname) {
		this.functionname = functionname;
	}

	public String getOpenid() {
		return this.openid;
	}

	public void setOpenid(String openid) {
		this.openid = openid;
	}

	public String getVerifyCode() {
		return this.verifyCode;
	}

	public void setVerifyCode(String verifyCode) {
		this.verifyCode = verifyCode;
	}

}