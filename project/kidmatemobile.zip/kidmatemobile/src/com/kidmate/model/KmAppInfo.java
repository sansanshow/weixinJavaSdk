package com.kidmate.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * KmAppInfo entity. @author MyEclipse Persistence Tools
 */

@Entity
public class KmAppInfo implements java.io.Serializable {

	// Fields

	private Long id;
	private String name;
	private String packagename;
	private String icon;
	private String fromtype;
	private String categoryid;
	private String categoryname;
	private Date createtime;
	private String status;

	// Constructors

	/** default constructor */
	public KmAppInfo() {
	}

	/** minimal constructor */
	public KmAppInfo(Long id) {
		this.id = id;
	}

	/** full constructor */
	public KmAppInfo(Long id, String name, String packagename, String icon,
			String fromtype, String categoryid, String categoryname,
			Date createtime, String status) {
		this.id = id;
		this.name = name;
		this.packagename = packagename;
		this.icon = icon;
		this.fromtype = fromtype;
		this.categoryid = categoryid;
		this.categoryname = categoryname;
		this.createtime = createtime;
		this.status = status;
	}

	// Property accessors

	@Id
	@GeneratedValue
	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPackagename() {
		return this.packagename;
	}

	public void setPackagename(String packagename) {
		this.packagename = packagename;
	}

	public String getIcon() {
		return this.icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public String getFromtype() {
		return this.fromtype;
	}

	public void setFromtype(String fromtype) {
		this.fromtype = fromtype;
	}

	public String getCategoryid() {
		return this.categoryid;
	}

	public void setCategoryid(String categoryid) {
		this.categoryid = categoryid;
	}

	public String getCategoryname() {
		return this.categoryname;
	}

	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}

	public Date getCreatetime() {
		return this.createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}