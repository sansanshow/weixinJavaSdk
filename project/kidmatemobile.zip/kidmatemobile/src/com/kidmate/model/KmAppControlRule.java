package com.kidmate.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * KmAppControlRule entity. @author MyEclipse Persistence Tools
 */

@Entity
public class KmAppControlRule implements java.io.Serializable {

	// Fields

	private Long id;
	private Long parentid;
	private Long childid;
	private Long equipmentid;
	private String controlname;
	private Long appid;
	private Integer starttime;
	private Integer endtime;
	private Integer duration;
	private String exceptapp;
	private Integer repeattype;
	private Date createtime;
	private String status;

	// Constructors

	/** default constructor */
	public KmAppControlRule() {
	}

	/** minimal constructor */
	public KmAppControlRule(Long id) {
		this.id = id;
	}

	/** full constructor */
	public KmAppControlRule(Long id, Long parentid, Long childid,
			Long equipmentid, String controlname, Long appid,
			Integer starttime, Integer endtime, Integer duration,
			String exceptapp, Integer repeattype, Date createtime, String status) {
		this.id = id;
		this.parentid = parentid;
		this.childid = childid;
		this.equipmentid = equipmentid;
		this.controlname = controlname;
		this.appid = appid;
		this.starttime = starttime;
		this.endtime = endtime;
		this.duration = duration;
		this.exceptapp = exceptapp;
		this.repeattype = repeattype;
		this.createtime = createtime;
		this.status = status;
	}

	// Property accessors

	@Id
	@GeneratedValue
	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getParentid() {
		return this.parentid;
	}

	public void setParentid(Long parentid) {
		this.parentid = parentid;
	}

	public Long getChildid() {
		return this.childid;
	}

	public void setChildid(Long childid) {
		this.childid = childid;
	}

	public Long getEquipmentid() {
		return this.equipmentid;
	}

	public void setEquipmentid(Long equipmentid) {
		this.equipmentid = equipmentid;
	}

	public String getControlname() {
		return this.controlname;
	}

	public void setControlname(String controlname) {
		this.controlname = controlname;
	}

	public Long getAppid() {
		return this.appid;
	}

	public void setAppid(Long appid) {
		this.appid = appid;
	}

	public Integer getStarttime() {
		return this.starttime;
	}

	public void setStarttime(Integer starttime) {
		this.starttime = starttime;
	}

	public Integer getEndtime() {
		return this.endtime;
	}

	public void setEndtime(Integer endtime) {
		this.endtime = endtime;
	}

	public Integer getDuration() {
		return this.duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public String getExceptapp() {
		return this.exceptapp;
	}

	public void setExceptapp(String exceptapp) {
		this.exceptapp = exceptapp;
	}

	public Integer getRepeattype() {
		return this.repeattype;
	}

	public void setRepeattype(Integer repeattype) {
		this.repeattype = repeattype;
	}

	public Date getCreatetime() {
		return this.createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}