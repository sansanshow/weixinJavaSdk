package com.kidmate.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import org.hibernate.Hibernate;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

@Entity
public class KmSnapshotDAO  extends HibernateDaoSupport{
	private static final Logger log = LoggerFactory
			.getLogger(KmLocationDAO.class);
	public static final String URL="url";
	public static final String ADDR = "addr";
	public static final String LONGITUDE = "longitude";
	public static final String LATITUDE = "latitude";
	public static final String STATUS = "status";
	public static final String EQUIPMENTID = "equipmentid";
	public static final String CREATETIME = "createtime";
	
	protected void initDao() {
		// do nothing
	}
	
	public void save(KmSnapshot transientInstance) {
		log.debug("saving KmSnapshotinstance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(KmSnapshot persistentInstance) {
		log.debug("deleting KmSnapshot instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public KmSnapshot findById(java.lang.Long id) {
		log.debug("getting KmSnapshot instance with id: " + id);
		try {
			KmSnapshot instance = (KmSnapshot) getHibernateTemplate().get(
					"com.kidmate.model.KmSnapshot", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
	
	public List findAll() {
		log.debug("finding all KmSnapshot instances");
		try {
			String queryString = "from KmSnapshot";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public KmSnapshot merge(KmSnapshot detachedInstance) {
		log.debug("merging KmSnapshot instance");
		try {
			KmSnapshot result = (KmSnapshot) getHibernateTemplate().merge(
					detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(KmSnapshot instance) {
		log.debug("attaching dirty KmSnapshot instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(KmSnapshot instance) {
		log.debug("attaching clean KmSnapshot instance");
		try {
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}
	
	
	public List<KmSnapshot> findKmSnapshot(long equipmentid, int page, int size) {
		//TODO k.equipmentid,k.url,k.longitude,k.latitude,k.addr,k.createtime
		//System.out.println("long equipmentid="+equipmentid);
		//String hql = "from KmSnapshot k where equipmentid=? order by id desc";  and k.status='1' 
		String sql="select id,equipmentid,url,longitude,latitude,addr,createtime ,status from km_snapshot  k where k.equipmentid=?   and status='1'  order by k.createtime desc";
		Session session = getSessionFactory().openSession();
		SQLQuery query=session.createSQLQuery(sql).addEntity(KmSnapshot.class);
		//Query query = session.createQuery(hql);
		query.setParameter(0, equipmentid, Hibernate.LONG);
		query.setFirstResult((page-1)*size);
		query.setMaxResults(size);
		List<KmSnapshot> results = query.list();
		session.close();
		return results;
	}
	
	
	public int delSnapshot(long equipmentid,List<Long> snapsPhotoId) {
		//TODO 
		String sql = "update km_snapshot set status='0'  where equipmentid =? and id in (:pn)";
		Session session = getSessionFactory().openSession();
		SQLQuery query = session.createSQLQuery(sql).addEntity(KmAppInfo.class);
		query.setParameter(0, equipmentid);
		query.setParameterList("pn", snapsPhotoId);
		int size=query.executeUpdate();
		session.close();
		return size;
	}
	
	
	public static KmSnapshotDAO getFromApplicationContext(ApplicationContext ctx) {
		return (KmSnapshotDAO) ctx.getBean("KmSnapshotDao");
	}
	
}
