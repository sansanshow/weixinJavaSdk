package com.kidmate.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * KmChildEquipment entity. @author MyEclipse Persistence Tools
 */

@Entity
public class KmChildEquipment implements java.io.Serializable {

	// Fields

	private Long id;
	private Long childid;
	private Long equipmentid;
	private Integer relationtype;
	private String status;

	// Constructors

	/** default constructor */
	public KmChildEquipment() {
	}

	/** minimal constructor */
	public KmChildEquipment(Long id) {
		this.id = id;
	}

	/** full constructor */
	public KmChildEquipment(Long id, Long childid, Long equipmentid,
			Integer relationtype, String status) {
		this.id = id;
		this.childid = childid;
		this.equipmentid = equipmentid;
		this.relationtype = relationtype;
		this.status = status;
	}

	// Property accessors

	@Id
	@GeneratedValue
	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getChildid() {
		return this.childid;
	}

	public void setChildid(Long childid) {
		this.childid = childid;
	}

	public Long getEquipmentid() {
		return this.equipmentid;
	}

	public void setEquipmentid(Long equipmentid) {
		this.equipmentid = equipmentid;
	}

	public Integer getRelationtype() {
		return this.relationtype;
	}

	public void setRelationtype(Integer relationtype) {
		this.relationtype = relationtype;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}