package com.kidmate.model;

import java.util.Date;


/**
 * KmCredit entity. @author MyEclipse Persistence Tools
 */

public class KmCredit  implements java.io.Serializable {


    // Fields    

     private Long id;
     private Long pid;
     private Long credit;
     private Date updatetime;
     private String status;


    // Constructors

    /** default constructor */
    public KmCredit() {
    }

    
    /** full constructor */
    public KmCredit(Long pid, Long credit, Date updatetime, String status) {
        this.pid = pid;
        this.credit = credit;
        this.updatetime = updatetime;
        this.status = status;
    }

   
    // Property accessors

    public Long getId() {
        return this.id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }

    public Long getPid() {
        return this.pid;
    }
    
    public void setPid(Long pid) {
        this.pid = pid;
    }

    public Long getCredit() {
        return this.credit;
    }
    
    public void setCredit(Long credit) {
        this.credit = credit;
    }

    public Date getUpdatetime() {
        return this.updatetime;
    }
    
    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getStatus() {
        return this.status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
   








}