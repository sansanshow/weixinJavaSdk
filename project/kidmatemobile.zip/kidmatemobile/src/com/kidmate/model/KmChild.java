package com.kidmate.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * KmChild entity. @author MyEclipse Persistence Tools
 */

@Entity
public class KmChild implements java.io.Serializable {

	// Fields

	private Long id;
	private Long parentid;
	private String name;
	private String gender;
	private Date birth;
	private Date createtime;
	private String status;

	// Constructors

	/** default constructor */
	public KmChild() {
	}

	/** minimal constructor */
	public KmChild(Long id) {
		this.id = id;
	}

	/** full constructor */
	public KmChild(Long id, Long parentid, String name, String gender,
			Date birth, Date createtime, String status) {
		this.id = id;
		this.parentid = parentid;
		this.name = name;
		this.gender = gender;
		this.birth = birth;
		this.createtime = createtime;
		this.status = status;
	}

	// Property accessors

	@Id
	@GeneratedValue
	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getParentid() {
		return this.parentid;
	}

	public void setParentid(Long parentid) {
		this.parentid = parentid;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getBirth() {
		return this.birth;
	}

	public void setBirth(Date birth) {
		this.birth = birth;
	}

	public Date getCreatetime() {
		return this.createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}