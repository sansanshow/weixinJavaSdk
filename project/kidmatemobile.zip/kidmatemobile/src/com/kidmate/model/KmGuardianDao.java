package com.kidmate.model;

import java.util.List;

import javax.persistence.Entity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

@Entity
public class KmGuardianDao extends HibernateDaoSupport{
	private static final Logger log = LoggerFactory
			.getLogger(KmGuardianDao.class);
	
	public static final String PARENTID = "parentId";
	public static final String CPARENTID="cparentId";
	public static final String CHILDID="childId";

	public void save(KmGuardian transientInstance) {
		log.debug("saving KmGuardian instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(KmGuardian persistentInstance) {
		log.debug("deleting KmGuardian instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public KmGuardian findById(java.lang.Long id) {
		log.debug("getting KmGuardian instance with id: " + id);
		try {
			KmGuardian instance = (KmGuardian) getHibernateTemplate().get(
					"com.kidmate.model.KmGuardian", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(KmGuardian instance) {
		log.debug("finding KmGuardian instance by example");
		try {
			List results = getHibernateTemplate().findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding KmGuardian instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from KmGuardian as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}
	
	public List findByCpa(Object cparentId) {
		try {
			String queryString = "from KmGuardian as model where model.cparentId=?  and model.status='1'";
			return getHibernateTemplate().find(queryString, cparentId);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}
	public List findByparentId(Object parentId){
		 return findByProperty(PARENTID,parentId);
	}
	public List findByChildId(Object childId){
		return findByProperty(CHILDID,childId);
	}
	public List findAll() {
		log.debug("finding all KmGuardian instances");
		try {
			String queryString = "from KmGuardian";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}
	
	public void attachDirty(KmGuardian instance) {
		log.debug("attaching dirty KmGuardian instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}
	
	public static KmGuardianDao getFromApplicationContext(
			ApplicationContext ctx) {
		return (KmGuardianDao) ctx.getBean("KmGuardianDao");
	}
}
