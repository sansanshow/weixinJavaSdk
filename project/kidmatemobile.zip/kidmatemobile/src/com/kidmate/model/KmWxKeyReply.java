package com.kidmate.model;

import java.util.Date;


/**
 * KmWxKeyReply entity. @author MyEclipse Persistence Tools
 */

public class KmWxKeyReply  implements java.io.Serializable {


    // Fields    

     private Long id;
     private String keyword;
     private String content;
     private Date createtime;
     private Date updatetime;
     private String status;


    // Constructors

    /** default constructor */
    public KmWxKeyReply() {
    }

	/** minimal constructor */
    public KmWxKeyReply(String keyword, String content, Date createtime, Date updatetime) {
        this.keyword = keyword;
        this.content = content;
        this.createtime = createtime;
        this.updatetime = updatetime;
    }
    
    /** full constructor */
    public KmWxKeyReply(String keyword, String content, Date createtime, Date updatetime, String status) {
        this.keyword = keyword;
        this.content = content;
        this.createtime = createtime;
        this.updatetime = updatetime;
        this.status = status;
    }

   
    // Property accessors

    public Long getId() {
        return this.id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }

    public String getKeyword() {
        return this.keyword;
    }
    
    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getContent() {
        return this.content;
    }
    
    public void setContent(String content) {
        this.content = content;
    }

    public Date getCreatetime() {
        return this.createtime;
    }
    
    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return this.updatetime;
    }
    
    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getStatus() {
        return this.status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
   








}