package com.kidmate.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import org.hibernate.Hibernate;
import org.hibernate.LockMode;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * A data access object (DAO) providing persistence and search support for
 * KmAppControlRule entities. Transaction control of the save(), update() and
 * delete() operations can directly support Spring container-managed
 * transactions or they can be augmented to handle user-managed Spring
 * transactions. Each of these methods provides additional information for how
 * to configure it for the desired type of transaction control.
 * 
 * @see com.kidmate.model.KmAppControlRule
 * @author MyEclipse Persistence Tools
 */

@Entity
public class KmAppControlRuleDAO extends HibernateDaoSupport {
	private static final Logger log = LoggerFactory
			.getLogger(KmAppControlRuleDAO.class);
	// property constants
	public static final String PARENTID = "parentid";
	public static final String CHILDID = "childid";
	public static final String EQUIPMENTID = "equipmentid";
	public static final String CONTROLNAME = "controlname";
	public static final String APPID = "appid";
	public static final String STARTTIME = "starttime";
	public static final String ENDTIME = "endtime";
	public static final String DURATION = "duration";
	public static final String EXCEPTAPP = "exceptapp";
	public static final String REPEATTYPE = "repeattype";
	public static final String STATUS = "status";

	protected void initDao() {
		// do nothing
	}

	public List<KmAppControlRule> findEquipmentAllRule(long equipmentId, long childid) {
		//TODO 
		String sql = "select * from km_app_control_rule where equipmentId=? or (equipmentId is null and childid=?) ";
		Session session = getSessionFactory().openSession();
		SQLQuery query = session.createSQLQuery(sql).addEntity(KmAppControlRule.class);
		query.setParameter(0, equipmentId, Hibernate.LONG);
		query.setParameter(1, childid, Hibernate.LONG);
		List<KmAppControlRule> results = query.list();
		session.close();
		return results;
	}
	
	public void save(KmAppControlRule transientInstance) {
		log.debug("saving KmAppControlRule instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(KmAppControlRule persistentInstance) {
		log.debug("deleting KmAppControlRule instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public KmAppControlRule findById(java.lang.Long id) {
		log.debug("getting KmAppControlRule instance with id: " + id);
		try {
			KmAppControlRule instance = (KmAppControlRule) getHibernateTemplate()
					.get("com.kidmate.model.KmAppControlRule", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(KmAppControlRule instance) {
		log.debug("finding KmAppControlRule instance by example");
		try {
			List results = getHibernateTemplate().findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding KmAppControlRule instance with property: "
				+ propertyName + ", value: " + value);
		try {
			String queryString = "from KmAppControlRule as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List findByParentid(Object parentid) {
		return findByProperty(PARENTID, parentid);
	}

	public List findByChildid(Object childid) {
		return findByProperty(CHILDID, childid);
	}

	public List findByEquipmentid(Object equipmentid) {
		return findByProperty(EQUIPMENTID, equipmentid);
	}

	public List findByControlname(Object controlname) {
		return findByProperty(CONTROLNAME, controlname);
	}

	public List findByAppid(Object appid) {
		return findByProperty(APPID, appid);
	}

	public List findByStarttime(Object starttime) {
		return findByProperty(STARTTIME, starttime);
	}

	public List findByEndtime(Object endtime) {
		return findByProperty(ENDTIME, endtime);
	}

	public List findByDuration(Object duration) {
		return findByProperty(DURATION, duration);
	}

	public List findByExceptapp(Object exceptapp) {
		return findByProperty(EXCEPTAPP, exceptapp);
	}

	public List findByRepeattype(Object repeattype) {
		return findByProperty(REPEATTYPE, repeattype);
	}

	public List findByStatus(Object status) {
		return findByProperty(STATUS, status);
	}

	public List findAll() {
		log.debug("finding all KmAppControlRule instances");
		try {
			String queryString = "from KmAppControlRule";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public KmAppControlRule merge(KmAppControlRule detachedInstance) {
		log.debug("merging KmAppControlRule instance");
		try {
			KmAppControlRule result = (KmAppControlRule) getHibernateTemplate()
					.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(KmAppControlRule instance) {
		log.debug("attaching dirty KmAppControlRule instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(KmAppControlRule instance) {
		log.debug("attaching clean KmAppControlRule instance");
		try {
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public static KmAppControlRuleDAO getFromApplicationContext(
			ApplicationContext ctx) {
		return (KmAppControlRuleDAO) ctx.getBean("KmAppControlRuleDAO");
	}
}