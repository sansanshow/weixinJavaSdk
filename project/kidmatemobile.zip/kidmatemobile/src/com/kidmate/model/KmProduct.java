package com.kidmate.model;

import java.io.Serializable;
import java.util.Date;

public class KmProduct implements Serializable{
	private Long id ; 
	private String name;
    private Long cid ;               //分类id
	private String description;  			//-- 产品描述
	private Long price 	; 				//	-- 产品价格
	private String remark ; 				//	-- 小编点评
	private String link ; 				//-- 产品链接
	private String image;             //产品图片
	private String source ; 				//-- 产品来源
	private String tags;  				//-- 分类或标签
	private String prosize;  				//-- app大小
	private Date createtime; 		//	-- 创建时间
	private String status;
	private String taocommand;     //淘口令
	
	public KmProduct(){}

	public KmProduct(Long id, String name,String prosize, Long cid, String description,
			Long price, String remark,String image, String link, String source, String tags,
			Date createtime, String status,String taocommand) {
           this.id=id;
        	this.name=name;
        	this.cid=cid;
        	this.prosize=prosize;
        	this.description=description;
        	this.price=price;
        	this.remark=remark;
        	this.link=link;
        	this.image=image;
        	this.source=source;
        	this.tags=tags;
        	this.createtime=createtime;
        	this.status=status;
        	this.taocommand=taocommand;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getCid() {
		return cid;
	}
	public void setCid(Long cid) {
		this.cid = cid;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Long getPrice() {
		return price;
	}
	public void setPrice(Long price) {
		this.price = price;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getTags() {
		return tags;
	}
	public void setTags(String tags) {
		this.tags = tags;
	}
	public Date getCreatetime() {
		return createtime;
	}
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getProsize() {
		return prosize;
	}

	public void setProsize(String prosize) {
		this.prosize = prosize;
	}

	public String getTaocommand() {
		return taocommand;
	}

	public void setTaocommand(String taocommand) {
		this.taocommand = taocommand;
	} 
	
	
	
	
}
