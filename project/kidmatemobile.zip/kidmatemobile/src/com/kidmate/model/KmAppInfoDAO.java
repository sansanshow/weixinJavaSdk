package com.kidmate.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import org.hibernate.Hibernate;
import org.hibernate.LockMode;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * A data access object (DAO) providing persistence and search support for
 * KmAppInfo entities. Transaction control of the save(), update() and delete()
 * operations can directly support Spring container-managed transactions or they
 * can be augmented to handle user-managed Spring transactions. Each of these
 * methods provides additional information for how to configure it for the
 * desired type of transaction control.
 * 
 * @see com.kidmate.model.KmAppInfo
 * @author MyEclipse Persistence Tools
 */

@Entity
public class KmAppInfoDAO extends HibernateDaoSupport {
	private static final Logger log = LoggerFactory
			.getLogger(KmAppInfoDAO.class);
	// property constants
	public static final String NAME = "name";
	public static final String PACKAGENAME = "packagename";
	public static final String ICON = "icon";
	public static final String FROMTYPE = "fromtype";
	public static final String CATEGORYID = "categoryid";
	public static final String CATEGORYNAME = "categoryname";
	public static final String STATUS = "status";

	protected void initDao() {
		// do nothing
	}

	public List<KmAppInfo> findExistAppInfo(List<String> packList) {
		//TODO 
		String sql = "select * from km_app_info where packagename in (:pn) order by id asc";
		Session session = getSessionFactory().openSession();
		SQLQuery query = session.createSQLQuery(sql).addEntity(KmAppInfo.class);
		query.setParameterList("pn", packList);
		List<KmAppInfo> results = query.list();
		session.close();
		return results;
	}
	
	public List<KmAppInfo> findByIdList(List<Long> idList) {
		//TODO 
		String sql = "select * from km_app_info where id in (:pn) order by id asc";
		Session session = getSessionFactory().openSession();
		SQLQuery query = session.createSQLQuery(sql).addEntity(KmAppInfo.class);
		query.setParameterList("pn", idList);
		List<KmAppInfo> results = query.list();
		session.close();
		return results;
	}
	
	public List<KmAppInfo> findByEquipmentID(long equipmentID) {
		//TODO 
		String sql = "select * from km_app_info where id in (select appid from km_equipment_app where equipmentID=? and status='1') order by id asc";
		Session session = getSessionFactory().openSession();
		SQLQuery query = session.createSQLQuery(sql).addEntity(KmAppInfo.class);
		query.setParameter(0, equipmentID, Hibernate.LONG);
		List<KmAppInfo> results = query.list();
		session.close();
		return results;
	}
	
	public List<KmAppInfo> findByChildID(long childID) {
		//TODO 
		String sql = "select * from km_app_info where id in (select appid from km_equipment_app where equipmentID in (select equipmentID from km_user_equipment where userid=? and status='1') and status='1') order by id asc";
		Session session = getSessionFactory().openSession();
		SQLQuery query = session.createSQLQuery(sql).addEntity(KmAppInfo.class);
		query.setParameter(0, childID, Hibernate.LONG);
		List<KmAppInfo> results = query.list();
		session.close();
		return results;
	}
	
	public void save(KmAppInfo transientInstance) {
		log.debug("saving KmAppInfo instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(KmAppInfo persistentInstance) {
		log.debug("deleting KmAppInfo instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public KmAppInfo findById(java.lang.Long id) {
		log.debug("getting KmAppInfo instance with id: " + id);
		try {
			KmAppInfo instance = (KmAppInfo) getHibernateTemplate().get(
					"com.kidmate.model.KmAppInfo", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(KmAppInfo instance) {
		log.debug("finding KmAppInfo instance by example");
		try {
			List results = getHibernateTemplate().findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding KmAppInfo instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from KmAppInfo as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List findByName(Object name) {
		return findByProperty(NAME, name);
	}

	public List findByPackagename(Object packagename) {
		return findByProperty(PACKAGENAME, packagename);
	}

	public List findByIcon(Object icon) {
		return findByProperty(ICON, icon);
	}

	public List findByFromtype(Object fromtype) {
		return findByProperty(FROMTYPE, fromtype);
	}

	public List findByCategoryid(Object categoryid) {
		return findByProperty(CATEGORYID, categoryid);
	}

	public List findByCategoryname(Object categoryname) {
		return findByProperty(CATEGORYNAME, categoryname);
	}

	public List findByStatus(Object status) {
		return findByProperty(STATUS, status);
	}

	public List findAll() {
		log.debug("finding all KmAppInfo instances");
		try {
			String queryString = "from KmAppInfo";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public KmAppInfo merge(KmAppInfo detachedInstance) {
		log.debug("merging KmAppInfo instance");
		try {
			KmAppInfo result = (KmAppInfo) getHibernateTemplate().merge(
					detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(KmAppInfo instance) {
		log.debug("attaching dirty KmAppInfo instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(KmAppInfo instance) {
		log.debug("attaching clean KmAppInfo instance");
		try {
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public static KmAppInfoDAO getFromApplicationContext(ApplicationContext ctx) {
		return (KmAppInfoDAO) ctx.getBean("KmAppInfoDAO");
	}
}