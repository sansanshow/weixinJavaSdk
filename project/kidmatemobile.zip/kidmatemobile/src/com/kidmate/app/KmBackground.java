package com.kidmate.app;

import org.apache.thrift.TProcessor;
import org.apache.thrift.TProcessorFactory;
import org.apache.thrift.protocol.TCompactProtocol;
import org.apache.thrift.server.TServer;
import org.apache.thrift.server.TThreadedSelectorServer;
import org.apache.thrift.transport.TFramedTransport;
import org.apache.thrift.transport.TNonblockingServerSocket;
import org.apache.thrift.transport.TTransportException;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.kidmate.service.impl.InternalServiceImpl;
import com.kidmate.thread.AppUsageRunnable;
import com.kidmate.thread.MessageSendRunnable;
import com.kidmate.tools.InternalConfig;
import com.kidmate.kmservice.InternalService;


public class KmBackground {
	private static ApplicationContext context = null;
//	private static Scheduler scheduler;
	public static void main(String args[]) throws SchedulerException, ClassNotFoundException, TTransportException {
		setContext(new ClassPathXmlApplicationContext("bg_Context.xml"));
		InternalConfig internalConfig = (InternalConfig) context.getBean("InternalConfig");
		AppUsageRunnable appUsageRunnable = (AppUsageRunnable) context.getBean("AppUsageRunnable");
		Thread appUsageThread = new Thread(appUsageRunnable);
		appUsageThread.start();
		
		MessageSendRunnable messageSendRunnable = (MessageSendRunnable) context.getBean("ParentMessageSendRunnable");
		for (int i=0; i<internalConfig.getParentMessageThreadCount(); i++) {
			Thread messageSendThread = new Thread(messageSendRunnable);
			messageSendThread.start();
		}
		
		messageSendRunnable = (MessageSendRunnable) context.getBean("ChildMessageSendRunnable");
		for (int i=0; i<internalConfig.getChildMessageThreadCount(); i++) {
			Thread messageSendThread = new Thread(messageSendRunnable);
			messageSendThread.start();
		}

		InternalServiceImpl internalServiceImpl = (InternalServiceImpl) context.getBean("InternalServiceImpl");
		TProcessor tprocessor = new InternalService.Processor<InternalService.Iface>(internalServiceImpl);
		// 传输通道 - 非阻塞方式  
        TNonblockingServerSocket tnbSocketTransport = new TNonblockingServerSocket(internalConfig.getPort());
      //多线程半同步半异步
        TThreadedSelectorServer.Args tnbArgs = new TThreadedSelectorServer.Args(tnbSocketTransport);
		tnbArgs.transportFactory(new TFramedTransport.Factory());
		tnbArgs.protocolFactory(new TCompactProtocol.Factory());
		tnbArgs.processorFactory(new TProcessorFactory(tprocessor));
		tnbArgs.selectorThreads(internalConfig.getSelectorThreadCount());
		tnbArgs.workerThreads(internalConfig.getWorkerThreadCount());
		tnbArgs.maxReadBufferBytes = 10*1024*1024;
		// 多线程半同步半异步的服务模型
        TServer server = new TThreadedSelectorServer(tnbArgs);
        server.serve();
        System.out.println("-------start over-----");
	}
	
	public static ApplicationContext getContext() {
		return context;
	}
	
	public static void setContext(ApplicationContext context) {
		KmBackground.context = context;
	}
	
}
