package com.kidmate.app;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import org.apache.thrift.TException;
import org.apache.thrift.TProcessor;
import org.apache.thrift.async.TAsyncClientManager;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.protocol.TCompactProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.protocol.TProtocolFactory;
import org.apache.thrift.transport.TFramedTransport;
import org.apache.thrift.transport.THttpClient;
import org.apache.thrift.transport.TNonblockingServerSocket;
import org.apache.thrift.transport.TNonblockingSocket;
import org.apache.thrift.transport.TNonblockingTransport;
import org.apache.thrift.transport.TSocket;
import org.apache.thrift.transport.TTransport;
import org.apache.thrift.transport.TTransportException;

import com.kidmate.kmservice.InternalService;
import com.kidmate.kmservice.ParentService;
import com.kidmate.kmservice.TKmAppInfo;
import com.kidmate.kmservice.TKmEquipment;
import com.kidmate.kmservice.TKmException;
import com.kidmate.kmservice.TKmUser;
import com.kidmate.service.impl.InternalServiceImpl;
import com.kidmate.tools.SecurityUtils;




public class ClientDemo {
	public static final String SERVER_IP = "192.168.0.222";
	public static final int SERVER_PORT =888 ;
	public static final int TIMEOUT = 50000;
 
	
	public void startClient() {
		TTransport transport = null;
		TKmUser user=new TKmUser();
		user.setUserid(2022);
		try {
			transport = new TFramedTransport(new TSocket(SERVER_IP,
					SERVER_PORT, TIMEOUT));
			// 协议要和服务端一致
			TProtocol protocol = new TCompactProtocol(transport);
			ParentService.Client client = new ParentService.Client(
					protocol);
			transport.open();
			List<TKmEquipment> result = client.getAllEquipment(user);
			System.out.println("-----------"+result.size());
			
		} catch (TTransportException e) {
			e.printStackTrace();
		} catch (TException e) {
			e.printStackTrace();
		} finally {
			if (null != transport) {
				transport.close();
			}
		}
	}
 
//	  public static void starstClient(){
//		  
//		  TTransport transport = null;
//		  TKmUser user=new TKmUser();
//		  user.setUserid(2022);
//			try {
//				TNonblockingTransport transport = new TNonblockingSocket(SERVER_IP,
//						SERVER_PORT, TIMEOUT);
//				// 协议要和服务端一致
//				TProcessor tprocessor = new InternalService.Processor(
//						new InternalServiceImpl());
//				TNonblockingServerSocket tnbSocketTransport = new TNonblockingServerSocket(
//						SERVER_PORT);
//				// TProtocol protocol = new TCompactProtocol(transport);
//				// TProtocol protocol = new TJSONProtocol(transport);
//				Client client = new Client(
//						protocol);
//				transport.open();
//				System.out.println("------open client----");
//				List<TKmEquipment> tkAppInfos = client.getAllEquipment(user);
//			
//				if(tkAppInfos.size()>0 && tkAppInfos!=null){
//				for(int i=0;i<tkAppInfos.size();i++){
//					System.out.println(tkAppInfos.get(i));
//					
//				}
//				}
//			} catch (TTransportException e) {
//				e.printStackTrace();
//			} catch (TException e) {
//				e.printStackTrace();
//			} finally {
//				if (null != transport) {
//					transport.close();
//				}
//			}
//		
//	  }
	  
	
	public static void httpClient(){
		TKmUser user=new TKmUser();
		user.setUserid(2000);
		user.setVer("1.31");
		long time=System.currentTimeMillis();
		user.setTimestamp(time);
		String sign=SecurityUtils.md5ByHex("0B9E77AD8E1D6A11E76216CBD1ACB9B1DD7292D4AB9776DA092399D1D877AEBF" + (time<<5));
		user.setSign(sign);
         String formalUrl = "http://192.168.0.222:888/kidmatemobile/parent.do";
		THttpClient thc = null;
		try {
		    thc = new THttpClient(formalUrl);
		    TProtocol loPFactory = new TBinaryProtocol(thc);
		    ParentService.Client client = new ParentService.Client(loPFactory);
		    List<TKmEquipment> result= client.getAllEquipment(user);
		    System.out.println("-------"+result.size());
		} catch (TTransportException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TKmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	  public static void cmd(){
		// ClientDemo client = new ClientDemo();
			// client.starstClient();
			System.out.println(System.getProperty("os.name"));
			String[] cmdarray = {
					"/bin/sh",
					"openssl",
					"smime",
					"-sign",
					"-in /Users/John/Downloads/mdmtool/kidmate.mobileconfig",
					"-out /Users/John/Downloads/mdmtool/skidmate.mobileconfig",
					"-signer /Users/John/Downloads/mdmtool/1_kidmate.cn_bundle.crt",
					"-inkey /Users/John/Downloads/mdmtool/2_kidmate.cn.key",
					"-certfile /Users/John/Downloads/mdmtool/3_kidmate.cn.pem",
					"-outform der", "-nodetach" };
			String[] ca1 = { "/Users/John/Downloads/mdmtool/openssl.sh",
					"/Users/John/Downloads/mdmtool/kidmate.mobileconfig",
					"/Users/John/Downloads/mdmtool/skidmate.mobileconfig",
					"/Users/John/Downloads/mdmtool/1_kidmate.cn_bundle.crt",
					"/Users/John/Downloads/mdmtool/2_kidmate.cn.key",
					"/Users/John/Downloads/mdmtool/3_kidmate.cn.pem" };
			String cmd = "/Users/John/Downloads/mdmtool/openssl.sh /Users/John/Downloads/mdmtool/kidmate.mobileconfig /Users/John/Downloads/mdmtool/skidmate.mobileconfig /Users/John/Downloads/mdmtool/1_kidmate.cn_bundle.crt /Users/John/Downloads/mdmtool/2_kidmate.cn.key /Users/John/Downloads/mdmtool/3_kidmate.cn.pem";
//			try {
//				// Runtime.getRuntime().exec("/Users/John/Downloads/mdmtool/1.sh");
//				Runtime.getRuntime().exec(cmd);
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
	  }
	  public static void main(String args[]){
		ClientDemo client = new ClientDemo();
		 client.httpClient();

		  
	  }
}
