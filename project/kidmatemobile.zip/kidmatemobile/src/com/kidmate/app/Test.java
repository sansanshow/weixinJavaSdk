package com.kidmate.app;


import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.thrift.TException;

import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.JedisShardInfo;
import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;


import com.kidmate.kmservice.InternalService;
import com.kidmate.model.KmParent;
import com.kidmate.service.IParentUserService;
import com.kidmate.service.impl.EquipmentServiceImpl;
import com.kidmate.service.impl.ParentUserServiceImpl;
import com.kidmate.tools.Constants;
import com.kidmate.tools.FileUtil;
import com.kidmate.tools.InternalServiceUtil;
import com.kidmate.tools.RedisUtil;
import com.taobao.api.ApiException;
import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.domain.CheckVerCodeRequest;
import com.taobao.api.request.OpenSmsCheckvercodeRequest;
import com.taobao.api.request.OpenSmsSendvercodeRequest;
import com.taobao.api.request.OpenSmsSendvercodeRequest.SendVerCodeRequest;
import com.taobao.api.response.OpenSmsCheckvercodeResponse;
import com.taobao.api.response.OpenSmsSendvercodeResponse;


import net.sf.json.JSONObject;

import com.kidmate.tools.SecurityUtils;
import com.kidmate.wx.utils.MD5Utils;
import com.kidmate.wx.utils.WeixinUtil;


public class Test {
	
	 public void goss(){
		 InternalServiceUtil  internalServiceUtil=new InternalServiceUtil();
		  InternalService.Iface iface = internalServiceUtil.borrowInternal();
			try {
				IParentUserService parentUserService=new ParentUserServiceImpl();
			    iface.sendMessge(1, "1000", parentUserService.getAccountId(2051), "{\"type\":\"1\"}", "绑定成功", null);
					//System.out.print("----------------parentId"+parentId+"childID"+childID+"kmEquipment.getId()"+kmEquipment.getId());
			} catch (TException e) {
				e.printStackTrace();
			}
			internalServiceUtil.returnInternal(iface);
	  }	
	 
	 public static void sendMessage(){
		 TaobaoClient client = new DefaultTaobaoClient("http://gw.api.tbsandbox.com/router/rest","23329596", "0c2e64b0bea00152d3913f7a855ec226");
		 OpenSmsSendvercodeRequest req = new OpenSmsSendvercodeRequest();
		 SendVerCodeRequest obj1 = new SendVerCodeRequest();
		 obj1.setExpireTime(123L);
		 obj1.setSessionLimit(123L);
		 obj1.setDeviceLimit(123L);
		 obj1.setDeviceLimitInTime(123L);
		 obj1.setMobileLimit(123L);
		 obj1.setSessionLimitInTime(123L);
		 obj1.setExternalId("12345");
		 obj1.setMobileLimitInTime(123L);
		 obj1.setTemplateId(123L);
		 obj1.setSignatureId(123L);
		 obj1.setSessionId("demo");
		 obj1.setDomain("demo");
		 obj1.setDeviceId("demo");
		 obj1.setMobile("18270822043");
		 obj1.setVerCodeLength(4L);
		 obj1.setSignature("淘宝网");
		 req.setSendVerCodeRequest(obj1);
		 OpenSmsSendvercodeResponse rsp;
		try {
			rsp = client.execute(req);
			 System.out.println(rsp.getBody());
		} catch (ApiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(MD5Utils.md5ByHex4Sign("oGaupFOMEd61BsB-6sSFDJbcF8AEWuzQe3xjok8y7Vvdl4v_7vbK0j_YV1auarSxVf6xfmBhucyLqcOphttxYfgtgBoBMV20tAlJCZUB1hE", "D9626DEBA85256D4445C7F309C119F17", 1471490634301L));
		System.out.println(SecurityUtils.md5ByHex("FF6B68941EC91D2A8DBD9DC2C3426833" + (1471491810314L<<5)));
	 }
	 public static void checkMessage(){
		 TaobaoClient client = new DefaultTaobaoClient("http://gw.api.taobao.com/router/rest", "23329596", "0c2e64b0bea00152d3913f7a855ec226");
		   OpenSmsCheckvercodeRequest req = new OpenSmsCheckvercodeRequest();
		   CheckVerCodeRequest obj1 = new CheckVerCodeRequest();
		   obj1.setDomain("demo");
		   obj1.setCheckFailLimit(123L);
		   obj1.setCheckSuccessLimit(123L);
		   obj1.setVerCode("demo");
		   obj1.setMobile("18270822043");
		   req.setCheckVerCodeRequest(obj1);
		   OpenSmsCheckvercodeResponse rsp;
		  
		try {
			rsp = client.execute(req);
			 System.out.println(rsp.getBody());
		} catch (ApiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
	 public static HttpURLConnection getHttpConnection(String tokenurl) throws IOException{
		 URL url = new URL(tokenurl);
         HttpURLConnection connection = (HttpURLConnection)url.openConnection();
         connection.setDoInput(true);
         connection.setDoOutput(true);
         connection.setRequestMethod("POST");
         connection.setUseCaches(false);
         connection.setInstanceFollowRedirects(true);
         connection.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
         connection.connect();
         return connection;
	 }
	 
	
	public static byte[] readInputStream(InputStream inStream) throws Exception{
		ByteArrayOutputStream outStream = new ByteArrayOutputStream();
		//创建一个Buffer字符串
		byte[] buffer = new byte[5000];
		//每次读取的字符串长度，如果为-1，代表全部读取完毕
		int len = 0;
		//使用一个输入流从buffer里把数据读取出来
		while( (len=inStream.read(buffer)) != -1 ){
			//用输出流往buffer里写入数据，中间参数代表从哪个位置开始读，len代表读取的长度
			outStream.write(buffer, 0, len);
		}
		//关闭输入流
		inStream.close();
		//把outStream里的数据写入内存
		return outStream.toByteArray();
	}

	 
	 
	   public static void main(String args[]){
		   String token_url="https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=";
		   String token=WeixinUtil.getAccessToken("wx365c10c5232278d3","eac1dd18813e6f8df303bae40692509b").getToken();
		   token_url=token_url+token;
		    System.out.println(token_url);
		    String action_info="{\"scene\":{\"scene_str\": \"http:\\\\www.baidu.com\"}}";
		    try {
		    	 HttpURLConnection connection =getHttpConnection(token_url);
	            DataOutputStream out = new DataOutputStream(connection.getOutputStream());
	            JSONObject obj = new JSONObject();
	             
	           // {"expire_seconds": 604800, "action_name": "QR_SCENE", "action_info": {"scene": {"scene_str": 123}}}
	            obj.put("expire_seconds", 604800);
	            obj.put("action_name", "QR_SCENE");
	            obj.put("action_info", action_info);
	            out.writeBytes(obj.toString());
	            out.flush();
	            out.close();
	             
	            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	            String lines;
	            StringBuffer sbf = new StringBuffer();
	             while ((lines = reader.readLine()) != null) {
	                    lines = new String(lines.getBytes(), "utf-8");
	                    sbf.append(lines);
	                }
	                System.out.println(sbf);
	                reader.close();
	                // 断开连接
	                connection.disconnect();
	                JSONObject jsonObject = JSONObject.fromObject(sbf.toString());
	                String ticket=jsonObject.getString("ticket");
	                String baidurul="https://www.baidu.com/img/bd_logo1.png";
	               String ticktUrl= "https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=";
	            
	               ticktUrl=ticktUrl+ticket;
	               System.out.println("ticket=="+ticktUrl);
	               HttpURLConnection connection1 =getHttpConnection(ticktUrl);
	               InputStream inStream = connection1.getInputStream();
	       		//得到图片的二进制数据，以二进制封装得到数据，具有通用性
	       		byte[] data = readInputStream(inStream);
	       		//new一个文件对象用来保存图片，默认保存当前工程根目录
	       		File imageFile = new File("D:\\BeautyGirl.jpg");
	       		//创建输出流
	       		FileOutputStream outStream = new FileOutputStream(imageFile);
	       		//写入数据
	       		outStream.write(data);
	       		//关闭输出流
	       		outStream.close();
	       
	        } catch (MalformedURLException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        } catch (IOException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        } catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
		 
	 }
	   
	  
}