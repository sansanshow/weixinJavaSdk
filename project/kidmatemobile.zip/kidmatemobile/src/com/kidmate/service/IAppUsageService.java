package com.kidmate.service;

import java.util.List;

import org.apache.thrift.TException;

import redis.clients.jedis.ShardedJedis;

import com.kidmate.kmservice.TKmAppUsage;
import com.kidmate.kmservice.TKmAppUsageStatistics;
import com.kidmate.kmservice.TKmTimeStatistics;
import com.kidmate.kmservice.TKmUser;

public interface IAppUsageService {
	
	public boolean addAppUsage(long equipmentId, TKmAppUsage tKmAppUsage, String ip, ShardedJedis shardedJedis);
	
	public TKmAppUsage getTheLatestAppUsage(long equipmentId, ShardedJedis shardedJedis);
	
	public TKmAppUsage getTheLatestNotSysAppUsage(long equipmentId, ShardedJedis shardedJedis);
	
	public List<TKmAppUsageStatistics> getAppUsageStatistics(long childid, long equipmentId);
	
	public long getChildAvgUsageTime(long birth, long date);
	
	public long getChildUsageTime(long childid, long date);
	
	public List<TKmTimeStatistics> getChildTimeStatistics(long parentid, long childid, int dayCount) throws TException ;

	public List<TKmAppUsageStatistics> getChildAppUsageStatistics(long parentid, long childid, int dayCount, int topX) throws TException ;
	
	public List<TKmAppUsage> getEquipmentAppUsageStatistics(long equipmentid, int page, int size, int ordertype) throws TException ;
}
