package com.kidmate.service;

import java.util.List;

import com.kidmate.kmservice.TKmPosition;
import com.kidmate.kmservice.TKmUser;
import com.kidmate.kmservice.TKmWifi;

public interface IPositionService {
	public long updatePosition(long equipmentid, TKmPosition position);
	public long updateWifi(long equipmentid, TKmWifi wifi, String ip);
	public TKmPosition getLatestPosition(long equipmentid);
	
	public List<TKmPosition> getPositionList(long equipmentid, int page, int size);
}
