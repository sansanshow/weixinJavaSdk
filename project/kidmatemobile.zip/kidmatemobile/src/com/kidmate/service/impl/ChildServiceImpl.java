package com.kidmate.service.impl;
import java.nio.ByteBuffer;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.thrift.TException;

import redis.clients.jedis.ShardedJedisPool;

import com.kidmate.kmservice.ChildService;
import com.kidmate.kmservice.InternalService;
import com.kidmate.kmservice.TKmAppInfo;
import com.kidmate.kmservice.TKmAppInfoUpload;
import com.kidmate.kmservice.TKmAppUsage;
import com.kidmate.kmservice.TKmControlRuleInfo;
import com.kidmate.kmservice.TKmException;
import com.kidmate.kmservice.TKmPosition;
import com.kidmate.kmservice.TKmSnapshot;
import com.kidmate.kmservice.TKmUser;
import com.kidmate.kmservice.TKmWifi;
import com.kidmate.service.IAppInfoService;
import com.kidmate.service.IChildUserService;
import com.kidmate.service.IControlService;
import com.kidmate.service.IEquipmentService;
import com.kidmate.service.IPositionService;
import com.kidmate.servlet.BaseTServlet;
import com.kidmate.tools.ExceptionUtil;
import com.kidmate.tools.InternalServiceUtil;
import com.kidmate.tools.SecurityUtils;
public class ChildServiceImpl implements ChildService.Iface{
	private ShardedJedisPool shardedJedisPool;
	private IEquipmentService equipmentService;
	private IAppInfoService appInfoService;
	private IControlService controlService;
	private InternalServiceUtil internalServiceUtil;
	private IPositionService positionService;
	private IChildUserService childUserService;// 6-1  zz
	
	private static Logger logger = Logger.getLogger(ChildServiceImpl.class);
	@Override
	public TKmUser login(String mac, String sign, long timestamp, String qrcode,
			String version, int source, String phonename) throws TKmException, TException {
		// TODO Auto-generated method stub
		if (Math.abs(System.currentTimeMillis()-timestamp)>120000) {
			ExceptionUtil.throwDefaultKmException("时间过期，请刷新");
		}
		if (!sign.equals(SecurityUtils.md5ByHex(mac + qrcode + (timestamp<<3)))) {
			ExceptionUtil.throwDefaultKmException("校验有误");
		}
		return equipmentService.bindEquipment(mac, BaseTServlet.clientip.get(), qrcode, source, phonename);
	}
  
	@Override
	public TKmUser loginIos(String mac, String sign, long timestamp,
			String qrcode, String version, int source, String phonename)
			throws TKmException, TException {
		// TODO Auto-generated method stub
		if (Math.abs(System.currentTimeMillis()-timestamp)>120000) {
			ExceptionUtil.throwDefaultKmException("时间过期，请刷新");
		}
		if (!sign.equals(SecurityUtils.md5ByHex(mac + qrcode + (timestamp<<3)))) {
			ExceptionUtil.throwDefaultKmException("校验有误");
		}
		return equipmentService.bindEquipment(mac, BaseTServlet.clientip.get(), qrcode, 1000, phonename);
	}
	@Override
	public List<TKmAppInfo> getAllBindApp(TKmUser user) throws TException {
		equipmentService.verifyUserSign(user, true);
		return appInfoService.getAllAppInfo(user.getUserid());
	}

	@Override
	public List<TKmAppInfo> bindApp(TKmUser user, List<Long> appIdList)
			throws TException {
		equipmentService.verifyUserSign(user, true);
		return appInfoService.bindToEquipment(user.getUserid(), appIdList);
	}
	
	@Override
	public long updatePosition(TKmUser user, TKmPosition position)
			throws TKmException, TException {
		// TODO Auto-generated method stub
		equipmentService.verifyUserSign(user, true);
		return positionService.updatePosition(user.getUserid(), position);
	}

	@Override
	public long updateWifi(TKmUser user, TKmWifi wifi) throws TKmException,
			TException {
		// TODO Auto-generated method stub
		equipmentService.verifyUserSign(user, true);
		return positionService.updateWifi(user.getUserid(), wifi, BaseTServlet.clientip.get());
	}
	
	@Override
	public List<TKmAppInfo> checkExistApp(TKmUser user, List<String> packageList)
			throws TKmException, TException {
		// TODO Auto-generated method stub
		equipmentService.verifyUserSign(user, true);
		return appInfoService.checkExistApp(packageList);
	}

	@Override
	public List<TKmAppInfo> addAppInfo(TKmUser user,
			List<TKmAppInfoUpload> appInfoUploadList) throws TKmException,
			TException {
		// TODO Auto-generated method stub
		equipmentService.verifyUserSign(user, true);
		return appInfoService.addNewAppInfo(user.getUserid(), appInfoUploadList);
	}

	@Override
	public boolean unInstallApp(TKmUser user, long appid) throws TKmException,
			TException {
		// TODO Auto-generated method stub
		equipmentService.verifyUserSign(user, true);
		return appInfoService.unInstallApp(user, appid);
	}

	@Override
	public boolean updateAppUsage(TKmUser user, long appid, long wifiid, long positionid) throws TKmException,
			TException {
		// TODO Auto-generated method stub
		equipmentService.verifyUserSign(user, true);
		InternalService.Iface iface = internalServiceUtil.borrowInternal();
		iface.addAppUsage(user.getUserid(), appid, wifiid, positionid, System.currentTimeMillis(), BaseTServlet.clientip.get());
		internalServiceUtil.returnInternal(iface);
		return true;
	}

	@Override
	public boolean updateHistoryAppUsage(TKmUser user,
			List<TKmAppUsage> appUsageList) throws TKmException, TException {
		// TODO Auto-generated method stub
		equipmentService.verifyUserSign(user, true);
		InternalService.Iface iface = internalServiceUtil.borrowInternal();
		String ip = BaseTServlet.clientip.get();
		for (TKmAppUsage appUsage:appUsageList) {
			iface.addAppUsage(user.getUserid(), appUsage.getAppid(), appUsage.getWifiid(), appUsage.getPositionid(), appUsage.getTime(), ip);
		}
		internalServiceUtil.returnInternal(iface);
		return true;
	}
	
	@Override
	public List<TKmControlRuleInfo> getAllControlRuleInfo(TKmUser user)
			throws TException {
		// TODO Auto-generated method stub
		equipmentService.verifyUserSign(user, true);
		return controlService.getEquipmentControlRuleList(user.getUserid());
	}
	
	@Override
	public void updateLockStatus(TKmUser user, String status)
			throws TKmException, TException {
		// TODO Auto-generated method stub
		equipmentService.verifyUserSign(user, true);
		equipmentService.updateLockStatus(user, status);
	}
	//longitude 经度  latitude 纬度
	@Override
	public void uploadSnapshot(TKmUser user,TKmSnapshot  snapshot )
			throws TKmException, TException {
		equipmentService.verifyUserSign(user, true);
		childUserService.uploadSnapshot(user, snapshot);
	}
	//
	@Override
	public boolean installApp(TKmUser user, long appid) throws TKmException,
			TException {
		equipmentService.verifyUserSign(user, true);
		return appInfoService.InstallApp(user, appid);
	}
	@Override
	public boolean isIosExist(TKmUser user) throws TKmException, TException {
		// TODO Auto-generated method stub
		equipmentService.verifyUserSign(user, true);
		return equipmentService.isIosExist(user.getUserid());
	}
	public ShardedJedisPool getShardedJedisPool() {
		return shardedJedisPool;
	}

	public void setShardedJedisPool(ShardedJedisPool shardedJedisPool) {
		this.shardedJedisPool = shardedJedisPool;
	}

	public IEquipmentService getEquipmentService() {
		return equipmentService;
	}

	public void setEquipmentService(IEquipmentService equipmentService) {
		this.equipmentService = equipmentService;
	}

	public IAppInfoService getAppInfoService() {
		return appInfoService;
	}

	public void setAppInfoService(IAppInfoService appInfoService) {
		this.appInfoService = appInfoService;
	}

	public InternalServiceUtil getInternalServiceUtil() {
		return internalServiceUtil;
	}

	public void setInternalServiceUtil(InternalServiceUtil internalServiceUtil) {
		this.internalServiceUtil = internalServiceUtil;
	}

	public IControlService getControlService() {
		return controlService;
	}

	public void setControlService(IControlService controlService) {
		this.controlService = controlService;
	}

	public IPositionService getPositionService() {
		return positionService;
	}

	public void setPositionService(IPositionService positionService) {
		this.positionService = positionService;
	}
	

	public IChildUserService getChildUserService() {
		return childUserService;
	}

	public void setChildUserService(IChildUserService childUserService) {
		this.childUserService = childUserService;
	}

	

	

	

}
