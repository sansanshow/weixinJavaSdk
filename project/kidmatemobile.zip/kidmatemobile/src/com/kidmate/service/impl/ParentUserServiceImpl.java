package com.kidmate.service.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

import net.sf.json.JSONObject;

import org.apache.log4j.Logger;
import org.apache.thrift.TException;

import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;


import com.kidmate.kmservice.InternalService;
import com.kidmate.kmservice.TKmCredit;
import com.kidmate.kmservice.TKmException;
import com.kidmate.kmservice.TKmProduct;
import com.kidmate.kmservice.TKmProductClass;
import com.kidmate.kmservice.TKmSnapshot;
import com.kidmate.kmservice.TKmUser;
import com.kidmate.model.KmAppControlRule;
import com.kidmate.model.KmAppControlRuleDAO;
import com.kidmate.model.KmCreditDAO;
import com.kidmate.model.KmCreditDetailDAO;
import com.kidmate.model.KmParent;
import com.kidmate.model.KmParentDAO;
import com.kidmate.model.KmProduct;
import com.kidmate.model.KmProductClass;
import com.kidmate.model.KmProductClassDao;
import com.kidmate.model.KmProductDao;
import com.kidmate.service.ICreditService;
import com.kidmate.service.IParentUserService;
import com.kidmate.tools.Config;
import com.kidmate.tools.Constants;
import com.kidmate.tools.ExceptionUtil;
import com.kidmate.tools.SecurityUtils;
import com.kidmate.tools.TimeUtil;
import com.kidmate.wx.utils.WeixinUtil;
import com.taobao.api.ApiException;
import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.domain.Userinfos;
import com.taobao.api.request.OpenAccountTokenApplyRequest;
import com.taobao.api.request.OpenAccountTokenValidateRequest;
import com.taobao.api.request.OpenimUsersAddRequest;
import com.taobao.api.request.OpenimUsersUpdateRequest;
import com.taobao.api.response.OpenAccountTokenApplyResponse;
import com.taobao.api.response.OpenAccountTokenValidateResponse;
import com.taobao.api.response.OpenimUsersAddResponse;
import com.taobao.api.response.OpenimUsersUpdateResponse;

public class ParentUserServiceImpl implements IParentUserService{

	private Config config;
	private KmParentDAO kmParentDAO;
	private ShardedJedisPool shardedJedisPool;
	private Random random = new Random();
	private KmProductDao kmProductDao;
	private KmProductClassDao kmProductClassDao;
	private ICreditService   creditServiceImpl;
	private static Logger logger = Logger.getLogger(ParentUserServiceImpl.class);
	
	@Override
	public String getVerifyUserSign(long userid) {
		String sign = null;
		ShardedJedis shardedJedis = shardedJedisPool.getResource();
		if (shardedJedis.hexists(Constants.PARENTSIGN, String.valueOf(userid))){
			sign = shardedJedis.hget(Constants.PARENTSIGN, String.valueOf(userid));
		} else {
			KmParent kmParent = kmParentDAO.findById(userid);
			if (kmParent!=null) {
				sign = kmParent.getMd5token() + kmParent.getSign();
				shardedJedis.hset(Constants.PARENTSIGN, String.valueOf(userid), sign);
			}
		}
		shardedJedisPool.returnResource(shardedJedis);
		return sign;
	}
	
	@Override
	public boolean verifyUserSign(TKmUser user, boolean mustLogin)
			throws TKmException {
		// TODO Auto-generated method stub
		if(user.getUserid()==2000 ){
			logger.info("-----------进入2000的演示用户---------");
			return true;
		}
		if (Math.abs(System.currentTimeMillis()-user.getTimestamp())>120000) {
			ExceptionUtil.throwDefaultKmException("时间过期，请刷新");
		}
		String sign = null;
		ShardedJedis shardedJedis = shardedJedisPool.getResource();
		if (shardedJedis.hexists(Constants.PARENTSIGN, String.valueOf(user.getUserid()))){
			sign = shardedJedis.hget(Constants.PARENTSIGN, String.valueOf(user.getUserid()));
		} else {
			KmParent kmParent = kmParentDAO.findById(user.getUserid());
			if (kmParent!=null) {
				sign = kmParent.getMd5token() + kmParent.getSign();
				shardedJedis.hset(Constants.PARENTSIGN, String.valueOf(user.getUserid()), sign);
			}
		}
		shardedJedisPool.returnResource(shardedJedis);
		String s= sign + (user.getTimestamp()<<5);
		if (sign==null || !SecurityUtils.md5ByHex(sign + (user.getTimestamp()<<5)).equals(user.getSign())) {
			if (mustLogin) {
				ExceptionUtil.throwUnloginKmException();
			} else {
				user.setUserid(0);
			}
		}
		return true;
	}
	
	@Override
	public String getAccountId(long parentid) {
		// TODO Auto-generated method stub
		String accountId = null;
		ShardedJedis shardedJedis = shardedJedisPool.getResource();
		if (shardedJedis.hexists(Constants.PARENTACCOUNT,
				String.valueOf(parentid))) {  
			    accountId = shardedJedis.hget(Constants.PARENTACCOUNT,
					String.valueOf(parentid));
		} else{
			KmParent kmParent = kmParentDAO.findById(parentid);
			if (kmParent != null) {
				//accountId =(config.isDevelop()?"test":""+ String.valueOf(kmParent.getId())
				accountId = kmParent.getOpenaccountid();
				if (accountId.equals(kmParent.getId().toString())) {
					if (config.isDevelop()) {
						accountId = "test" + kmParent.getId();
					} else {
						accountId = String.valueOf(kmParent.getId());
					}
				}
				shardedJedis.hset(Constants.PARENTACCOUNT,String.valueOf(parentid), accountId);
			}
		}
		shardedJedisPool.returnResource(shardedJedis);
		return accountId;
	}
	
	@Override
	public String loginPw(String mobile, String password) throws TException {
		// TODO Auto-generated method stub
		if ("true".equals(config.getParentAudit())) {
			if (mobile.equals("18019360618") && password.equals(config.getParentCode())) {
				TaobaoClient client = new DefaultTaobaoClient(config.getTaoBaoServerUrl(), config.getParentAppkey(), config.getParentAppSec());
				OpenAccountTokenApplyRequest req = new OpenAccountTokenApplyRequest();
				req.setTokenTimestamp(System.currentTimeMillis());
				req.setOpenAccountId(4398047671988L);
//				req.setLoginStateExpireIn(45L);
				try {
					OpenAccountTokenApplyResponse rsp = client.execute(req);
					JSONObject json = JSONObject.fromObject(rsp.getBody());
					if (json.containsKey("open_account_token_apply_response")) {
						json = json.getJSONObject("open_account_token_apply_response");
						if (json.containsKey("data")) {
							json = json.getJSONObject("data");
							if (json.containsKey("data")) {
								String token = json.getString("data");
								return token;
							}
						}
					}
				} catch (ApiException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					ExceptionUtil.throwDefaultKmException("系统繁忙");
				}
			}
		} else {
			ExceptionUtil.throwDefaultKmException("用户名或者密码错误");
		}
		return null;
	}
	
	@Override
	public TKmUser login(String authToken, int source, String ip,String invitecode) throws TException {
		// TODO Auto-generated method stub
		TaobaoClient client = new DefaultTaobaoClient(config.getTaoBaoServerUrl(), config.getParentAppkey(), config.getParentAppSec());
		OpenAccountTokenValidateRequest req = new OpenAccountTokenValidateRequest();
		req.setParamToken(authToken);
		OpenAccountTokenValidateResponse rsp = null;
		try {
			String domain_id = null;
			String open_account_id = null;
			String mobile = null;
			long timestamp = System.currentTimeMillis();
			rsp = client.execute(req);
			JSONObject json = JSONObject.fromObject(rsp.getBody());
			if (json.containsKey("open_account_token_validate_response")) {
				json = json.getJSONObject("open_account_token_validate_response");
				if (json.containsKey("data")) {
					json = json.getJSONObject("data");
					if (json.containsKey("successful")) {
						boolean suc = json.getBoolean("successful");
						if (suc) {
							if (json.containsKey("timestamp")) {
								timestamp = json.getLong("timestamp");
							}
							if (json.containsKey("open_account_id")) {
								open_account_id = json.getString("open_account_id");
							}
							if (json.containsKey("data") && json.getJSONObject("data").containsKey("open_account_id"))  {
								open_account_id = json.getJSONObject("data").getString("open_account_id");
							}
							if (json.containsKey("data") && json.getJSONObject("data").containsKey("ext")) {
								json = json.getJSONObject("data").getJSONObject("ext");
								if (json.containsKey("open_account")) {
									json = json.getJSONObject("open_account");
									if (json.containsKey("mobile")) {
										mobile = json.getString("mobile");
									}
									if (json.containsKey("id")) {
										open_account_id = json.getString("id");
									}
									if (json.containsKey("domain_id")) {
										domain_id = json.getString("domain_id");
									}
								}
							}
						}
					}
				}
			}
			if (mobile!=null && mobile.length()!=0 || "4398047671988".equals(open_account_id)) {
				List<KmParent> kmParentList = null;
				if (mobile!=null && mobile.length()!=0) {
					kmParentList = kmParentDAO.findByMobile(mobile);
				} else { 
					kmParentList = kmParentDAO.findByOpenaccountid(open_account_id);
				}
			    String md5token = SecurityUtils.md5ByHex(authToken);
				String signature = SecurityUtils.md5ByHex("#$wrt" + random.nextInt(10000000) + System.currentTimeMillis() + random.nextInt(10000000));
				KmParent kmParent = null;
				if (kmParentList != null && kmParentList.size()>0) {
					kmParent = kmParentList.get(0);
					kmParent.setLastlogintime(new Date(timestamp));
					kmParent.setLastloginip(ip);
					kmParent.setOpenaccountid(open_account_id);
					kmParent.setMd5token(md5token);
					kmParent.setSign(signature);
					kmParentDAO.attachDirty(kmParent);
				} else {
					kmParent = new KmParent();
					kmParent.setMobile(mobile);
					kmParent.setStatus("1");
					kmParent.setSourceid(Long.valueOf(source));
					kmParent.setRegtime(new Date(timestamp));
					kmParent.setRegip(ip);
					kmParent.setLastlogintime(new Date(timestamp));
					kmParent.setLastloginip(ip);
					Calendar cal = Calendar.getInstance();
					// 新注册用户，赠送7天VIP
					cal.setTime(new Date());
					cal.add(Calendar.DATE,7);
					if(invitecode!=null && invitecode.length()>0) {
						List<KmParent> kps=kmParentDAO.findByInvitecode(invitecode);
						if(kps!=null&&kps.size()>0){
                          creditServiceImpl.saveKmCredit(kps.get(0).getId(), 3, 0);//3表示邀请好友登入获得的积分类型。
							cal.add(Calendar.DATE,7);
						}
						
					}
					kmParent.setVip(cal.getTime());
					kmParent.setOpenaccountid(open_account_id);
					kmParent.setMd5token(md5token);
					kmParent.setSign(signature);			
					kmParentDAO.save(kmParent);
				}
				if (kmParent != null) {
					TKmUser kmUser = new TKmUser();
					kmUser.setSign(signature);
					kmUser.setUserid(kmParent.getId());
					if (kmParent.getVip() != null) {
						kmUser.setTimestamp(kmParent.getVip().getTime());
					}
					ShardedJedis shardedJedis = shardedJedisPool.getResource();
					shardedJedis.hset(Constants.PARENTSIGN, String.valueOf(kmParent.getId()), kmParent.getMd5token() + kmParent.getSign());
					shardedJedisPool.returnResource(shardedJedis);
					
					return kmUser;
				}
			} else {
					return null;
			}	
			
		} catch (ApiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("-----parent   login"+rsp.getBody());
		return null;
	}
	
	@Override
	public TKmUser loginWx(String accessToken, String opendId, String unionid,
			int source, String ip) throws TException {
		boolean flag = false;
		boolean isNew = false;
		if (source == 2000) {// 小程序入口
			logger.info("--------------小程序入口");
			flag = true;
		} else {// 微信入口
			logger.info("--------------微信登入");
			String url = "https://api.weixin.qq.com/sns/auth?access_token=ACCESS_TOKEN&openid=OPENID ";
			String requestUrl = url.replace("ACCESS_TOKEN", accessToken)
					.replace("OPENID", opendId);
			JSONObject jsonObject = WeixinUtil.httpRequest(requestUrl, "GET",
					null);
			logger.info("--------------微信登入" + jsonObject.getString("errcode"));

			try {
				if (jsonObject.getString("errcode").equals("0")) {
					String useUrl = "https://api.weixin.qq.com/sns/userinfo?access_token=ACCESS_TOKEN&openid=OPENID&lang=zh_CN ";
					String requestuse = useUrl.replace("ACCESS_TOKEN",
							accessToken).replace("OPENID", opendId);
					JSONObject jsonUser = WeixinUtil.httpRequest(requestuse,
							"GET", null);
					if (jsonUser.getString("unionid").equals(unionid))
						flag = true;
					logger.info("===============flag==" + flag + " unionid=="
							+ unionid + "-----=="
							+ jsonUser.getString("unionid"));
				} else {
					ExceptionUtil.throwDefaultKmException("微信登入失败");
				}
			} catch (Exception e) {
				ExceptionUtil.throwUnauthorizedKmException();
			}
		}

		List<KmParent> kmParentList = null;
		KmParent kmParent = null;
		try {
			if (unionid != null && unionid.length() != 0 && flag) {
				kmParentList = kmParentDAO.findByWxopenid(unionid);
				String md5token = SecurityUtils.md5ByHex(accessToken);
				String signature = SecurityUtils.md5ByHex("#$wrt"
						+ random.nextInt(10000000) + System.currentTimeMillis()
						+ random.nextInt(10000000));
				long timestamp = System.currentTimeMillis();
				if (kmParentList != null && kmParentList.size() > 0) {
					kmParent = kmParentList.get(0);
					kmParent.setLastlogintime(new Date(timestamp));
					kmParent.setLastloginip(ip);
					kmParent.setOpenaccountid(String.valueOf(kmParent.getId()));
					kmParent.setMd5token(md5token);
					kmParent.setSign(signature);
					kmParent.setStatus("1");
					kmParentDAO.attachDirty(kmParent);
				} else {
					kmParent = new KmParent();
					kmParent.setWxopenid(unionid);
					kmParent.setStatus("1");
					kmParent.setSourceid(Long.valueOf(source));
					kmParent.setRegtime(new Date(timestamp));
					kmParent.setRegip(ip);
					kmParent.setLastlogintime(new Date(timestamp));
					kmParent.setLastloginip(ip);
					Calendar cal = Calendar.getInstance();
					// 新注册用户，赠送7天VIP
					cal.setTime(new Date());
					cal.add(Calendar.DATE, 7);
					kmParent.setVip(cal.getTime());
					kmParent.setMd5token(md5token);
					kmParent.setSign(signature);
					kmParentDAO.save(kmParent);
					if (kmParent.getId() != null) {
						kmParent.setOpenaccountid(String.valueOf(kmParent
								.getId()));
					} else {
						kmParent.setOpenaccountid("0");
					}
					kmParentDAO.attachDirty(kmParent);
					isNew = true;

				}
				TaobaoClient client = new DefaultTaobaoClient(
						config.getTaoBaoServerUrl(), config.getParentAppkey(),
						config.getParentAppSec());
				// TODO im添加账号
				List<Userinfos> userinfoList = new ArrayList<Userinfos>();
				Userinfos userinfo = new Userinfos();
				userinfo.setUserid((config.isDevelop() ? "test" : "")
						+ String.valueOf(kmParent.getId()));
				userinfo.setPassword(signature);
				System.out.println("password==============="
						+ userinfo.getPassword() + "userinfo=="
						+ userinfo.getUserid());
				userinfoList.add(userinfo);
				if (kmParent != null) {
					try {
						if (isNew) {
							// TODO im添加账号
							OpenimUsersAddRequest req = new OpenimUsersAddRequest();
							req.setUserinfos(userinfoList);
							OpenimUsersAddResponse rsp = client.execute(req);
							System.out.println("---------------is new");
						}
						// TODO im修改密码
						OpenimUsersUpdateRequest req = new OpenimUsersUpdateRequest();
						req.setUserinfos(userinfoList);
						OpenimUsersUpdateResponse rsp = client.execute(req);
					} catch (Exception e) {
						ExceptionUtil.throwDefaultKmException("IM信息更新有误");
					}
					TKmUser kmUser = new TKmUser();
					kmUser.setSign(signature);
					kmUser.setUserid(kmParent.getId());
					if (kmParent.getVip() != null) {
						kmUser.setTimestamp(kmParent.getVip().getTime());
					}
					ShardedJedis shardedJedis = shardedJedisPool.getResource();
					shardedJedis.hset(Constants.UNIONID,
							String.valueOf(unionid + "" + kmParent.getId()),
							kmParent.getSign());
					shardedJedis.hset(Constants.PARENTSIGN,
							String.valueOf(kmParent.getId()),
							kmParent.getMd5token() + kmParent.getSign());
					shardedJedisPool.returnResource(shardedJedis);
					return kmUser;
				}
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("----------opendId" + opendId);
		return null;
	}

	@Override
	public long getVipTime(long userid) {
		// TODO Auto-generated method stub
		KmParent kmParent = kmParentDAO.findById(userid);
		if (kmParent!=null && kmParent.getVip()!=null) {
			return kmParent.getVip().getTime();
		}
		return 0;
	}
	
	@Override
	public TKmUser getTkmUserByUnionid(long parentId,String accessToken, String opendId, String unionid, int source,
			String ip) throws TException {
		// TODO Auto-generated method stub
		ShardedJedis shardedJedis = shardedJedisPool.getResource();
		String sign=null;
		if(shardedJedis.hexists(Constants.UNIONID, String.valueOf(unionid+""+parentId))){
			sign=shardedJedis.hget(Constants.UNIONID,String.valueOf(unionid+""+parentId));
		};
		shardedJedisPool.returnResource(shardedJedis);
		 
		 TKmUser kmUser = new TKmUser();
		 if (sign != null) {
				kmUser.setSign(sign);
				kmUser.setUserid(parentId);
				kmUser.setTimestamp(this.getVipTime(parentId));
		 }else{
			 return this.loginWx(accessToken, opendId, unionid, source, ip);
		 }
		 return  kmUser;
	}

	@Override
	public List<TKmProductClass> getProductClass(int page, int size) {
		// TODO Auto-generated method stub
		List<TKmProductClass> tKmClass=new ArrayList<TKmProductClass>();
		List<KmProductClass> kPClass=kmProductClassDao.findAll();
		System.out.println("--------------+KmProductClass==="+kPClass.size());
		for(KmProductClass kc:kPClass){
			TKmProductClass tKmPro=new TKmProductClass();
			tKmPro.setId(kc.getId());
			File file=new File(config.getImageUrl() + "/"+"product");
			if(!file.exists()){
				file.mkdirs();
			}
			if(kc.getImage()!=null){
				if(kc.getImage().indexOf("http")==-1){
					tKmPro.setImgurl(config.getImageUrl() + "/"+"product"+"/"+kc.getImage());
				}else{
					tKmPro.setImgurl(kc.getImage());
				}
			}
				
			
			if(kc.getLink()!=null){
				tKmPro.setLink(kc.getLink());
			}
			tKmPro.setName(kc.getName());
			//tKmPro.setTime(kc.getCreatetime().getTime());
			//tKmPro.setTags(kc.getTags());
			if(kc.getName().equals("适龄应用推荐")||kc.getName().equals("培训机构推荐")){
				    size=3;
				if(kc.getName().equals("培训机构推荐")){
				    size=2;
				}
				List<KmProduct> kProducts=kmProductDao.findByCategoryPage(size, page, kc.getId());
				System.out.println("----------------kProducts=="+kProducts.size());
				List<TKmProduct> tkmpros=new ArrayList<TKmProduct>();
				for(KmProduct kp:kProducts){
					TKmProduct a=new TKmProduct();
					a.setId(kp.getId());
					a.setCid(kp.getCid());
//					if(kp.getPrice()!=null)
//					a.setPrice(kp.getPrice());
//					if(kp.getDescription()!=null)
					a.setProdescription(kp.getDescription());
					a.setTags(kp.getTags());
					a.setName(kp.getName());
					a.setLink(kp.getLink());
					if(kp.getImage()!=null){
						if(kp.getImage().indexOf("http")==-1){
						a.setImgurl(config.getImageUrl() + "/"+"product"+"/"+kp.getImage());
						}else{
							a.setImgurl(kp.getImage());
						}
					}
					//System.out.println("=a.getImgurl()========="+a.getImgurl());
					tkmpros.add(a);
				}
				tKmPro.setTkmProducts(tkmpros);
			}
				
			tKmClass.add(tKmPro);	
		}
		System.out.println("----------------TKmProductClass=="+tKmClass.size());
		return tKmClass;
	}

	@Override
	public List<TKmProduct> getProduct(long cid, int page, int size) {
		// TODO Auto-generated method stub
		List<TKmProduct> tkmProducts=new ArrayList<TKmProduct>();
		List<KmProduct> products=kmProductDao.findByCategoryPage(size, page, cid);
	    System.out.println("----------------getProduct"+products.size());
		String imagePath=config.getImageUrl() + "/"+"product"+"/";
		File f=new File(imagePath);
		if(!f.exists()){
			f.mkdirs();
		}
		for(KmProduct proc:products){
			TKmProduct tkmProduct=new TKmProduct();
			tkmProduct.setId(proc.getId());
			tkmProduct.setCid(proc.getCid());
			tkmProduct.setName(proc.getName());
			if(proc.getTags()!=null){
				tkmProduct.setTags(proc.getTags());
			}
			if(proc.getDescription()!=null){
				tkmProduct.setProdescription(proc.getDescription());
			}
			if(proc.getPrice()!=null){
				tkmProduct.setPrice(proc.getPrice());
			}
			if(proc.getImage()!=null){
				if(proc.getImage().indexOf("http")==-1){
					tkmProduct.setImgurl(imagePath+proc.getImage());
				}else{
					tkmProduct.setImgurl(proc.getImage());
				}
			}
			if(proc.getRemark()!=null){
				tkmProduct.setProreamark(proc.getRemark());
			}
			if(proc.getLink()!=null){
				tkmProduct.setLink(proc.getLink());
			}
			if(proc.getCreatetime()==null){
				tkmProduct.setTime(System.currentTimeMillis());
			}else{
				tkmProduct.setTime(proc.getCreatetime().getTime());
			}
			if(proc.getProsize()!=null){
				tkmProduct.setProsize(proc.getProsize());
			}
			if(proc.getTaocommand()!=null){
				tkmProduct.setTaocommand(proc.getTaocommand());
			}
			tkmProducts.add(tkmProduct);
		}
		logger.info("-----------------+tkmProducts="+tkmProducts.size());
		return tkmProducts;
	}
	
	@Override
	public List<TKmProduct> getListProducts(List cid, int page, int size) {
		List<TKmProduct> tkmProducts=new ArrayList<TKmProduct>();
		List<KmProduct> products=kmProductDao.findBylistCaPage(size, page, cid);
	    System.out.println("----------------getProduct"+products.size());
		String imagePath=config.getImageUrl() + "/"+"product"+"/";
		File f=new File(imagePath);
		if(!f.exists()){
			f.mkdirs();
		}
		for(KmProduct proc:products){
			TKmProduct tkmProduct=new TKmProduct();
			tkmProduct.setId(proc.getId());
			tkmProduct.setCid(proc.getCid());
			tkmProduct.setName(proc.getName());
			if(proc.getTags()!=null){
				tkmProduct.setTags(proc.getTags());
			}
			if(proc.getDescription()!=null){
				tkmProduct.setProdescription(proc.getDescription());
			}
			if(proc.getRemark()!=null){
				tkmProduct.setProreamark(proc.getRemark());
			}
			if(proc.getPrice()!=null){
				tkmProduct.setPrice(proc.getPrice());
			}
			if(proc.getImage()!=null){
				if(proc.getImage().indexOf("http")==-1){
					tkmProduct.setImgurl(imagePath+proc.getImage());
				}else{
					tkmProduct.setImgurl(proc.getImage());
				}
				
			}
			if(proc.getLink()!=null){
				tkmProduct.setLink(proc.getLink());
			}
			if(proc.getCreatetime()==null){
				tkmProduct.setTime(System.currentTimeMillis());
			}else{
				tkmProduct.setTime(proc.getCreatetime().getTime());
			}
			if(proc.getProsize()!=null){
				tkmProduct.setProsize(proc.getProsize());
			}
			if(proc.getTaocommand()!=null){
				tkmProduct.setTaocommand(proc.getTaocommand());
			}
			tkmProducts.add(tkmProduct);
		}
		logger.info("-----------------+tkmProduct    alls="+tkmProducts.size());
		return tkmProducts;
	}

	
	  
	public Config getConfig() {
		return config;
	}
	public void setConfig(Config config) {
		this.config = config;
	}
	public KmParentDAO getKmParentDAO() {
		return kmParentDAO;
	}
	public void setKmParentDAO(KmParentDAO kmParentDAO) {
		this.kmParentDAO = kmParentDAO;
	}
	public ShardedJedisPool getShardedJedisPool() {
		return shardedJedisPool;
	}
	public void setShardedJedisPool(ShardedJedisPool shardedJedisPool) {
		this.shardedJedisPool = shardedJedisPool;
	}

	public KmProductDao getKmProductDao() {
		return kmProductDao;
	}

	public void setKmProductDao(KmProductDao kmProductDao) {
		this.kmProductDao = kmProductDao;
	}

	public KmProductClassDao getKmProductClassDao() {
		return kmProductClassDao;
	}

	public void setKmProductClassDao(KmProductClassDao kmProductClassDao) {
		this.kmProductClassDao = kmProductClassDao;
	}

	public ICreditService getCreditServiceImpl() {
		return creditServiceImpl;
	}

	public void setCreditServiceImpl(ICreditService creditServiceImpl) {
		this.creditServiceImpl = creditServiceImpl;
	}

	


  
}
