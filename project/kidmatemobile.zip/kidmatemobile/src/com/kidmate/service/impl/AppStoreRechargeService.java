package com.kidmate.service.impl;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.log4j.Logger;
import org.apache.thrift.TException;

import com.kidmate.model.KmMoneyHistory;
import com.kidmate.model.KmMoneyHistoryDAO;
import com.kidmate.model.KmParent;
import com.kidmate.model.KmParentDAO;
import com.kidmate.tools.Constants;
import com.kidmate.tools.ExceptionUtil;


import net.sf.json.JSONArray;
import net.sf.json.JSONObject;


public class AppStoreRechargeService {
	private static Logger logger = Logger.getLogger(AppStoreRechargeService.class);
	
	private KmMoneyHistoryDAO kmMoneyHistoryDAO;
	private KmParentDAO kmParentDAO; 
	
	private static final String url_sandbox="https://sandbox.itunes.apple.com/verifyReceipt";  
	private static final String url_verify="https://buy.itunes.apple.com/verifyReceipt";
	
	private class TrustAnyTrustManager implements X509TrustManager {  
        
        public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {  
        }  
      
        public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {  
        }  
      
        public X509Certificate[] getAcceptedIssuers() {  
            return new X509Certificate[]{};  
        }  
    } 
	
	private class TrustAnyHostnameVerifier implements HostnameVerifier {  
        public boolean verify(String hostname, SSLSession session) {  
            return true;  
        }  
    }
	
	public String buyAppVerify(String receipt,String verifyUrl)  
    {  
       String url=verifyUrl;  
       String buyCode=receipt; // getBASE64(receipt);  
       try{  
           SSLContext sc = SSLContext.getInstance("SSL");  
           sc.init(null, new TrustManager[]{new TrustAnyTrustManager()}, new java.security.SecureRandom());  
           URL console = new URL(url);  
           HttpsURLConnection conn = (HttpsURLConnection) console.openConnection();  
           conn.setSSLSocketFactory(sc.getSocketFactory());  
           conn.setHostnameVerifier(new TrustAnyHostnameVerifier());  
           conn.setRequestMethod("POST");  
           conn.setRequestProperty("content-type", "text/json");  
           conn.setRequestProperty("Proxy-Connection", "Keep-Alive");  
           conn.setDoInput(true);
           conn.setDoOutput(true);
           BufferedOutputStream hurlBufOus=new BufferedOutputStream(conn.getOutputStream());  
             
           String str= String.format(Locale.CHINA,"{\"receipt-data\":\"" + buyCode+"\"}");  
           hurlBufOus.write(str.getBytes());  
           hurlBufOus.flush();  
                     
            InputStream is = conn.getInputStream();  
            BufferedReader reader=new BufferedReader(new InputStreamReader(is));  
            String line = null;  
            StringBuffer sb = new StringBuffer();  
            while((line = reader.readLine()) != null){  
              sb.append(line);  
            }
            return sb.toString();  
       }catch(Exception ex)  
       {  
           ex.printStackTrace();  
       }  
       return null;  
    } 
	
	public int appStoreRecharge(long userid, String receipt, boolean sandbox) throws TException {
		logger.info(receipt);
//		boolean isExists = false;
		String verifyResult=null;
//		if(!isExists){ 
			String verifyUrl=url_verify;	//url_sandbox url_verify
			if (sandbox)
				verifyUrl = url_sandbox;
			verifyResult=buyAppVerify(receipt, verifyUrl);
			if(verifyResult==null){
				
			}else{
				logger.info(verifyResult);
				JSONObject job = JSONObject.fromObject(verifyResult);  
                String states=job.getString("status");  
                if(states.equals("0"))//验证成功  
                {
                	if(job.containsKey("receipt")) {
                		job = job.getJSONObject("receipt");
                	}
                	if (job.containsKey("in_app")) {
                		JSONArray coinArray=job.getJSONArray("in_app");
	                    for (int i=0; i<coinArray.size(); i++ ) {
		                    JSONObject coinJson = coinArray.getJSONObject(i);
		                    //产品ID  
		                    String product_id=coinJson.getString("product_id");
		                    //数量  
		                    String quantity=coinJson.getString("quantity");  
		                    //跟苹果的服务器验证成功  
		                    String transaction_id = coinJson.getString("transaction_id");
		                   
		                    String remark = "product_id:" + product_id + ";quantity:" + quantity + ";transaction_id:" +transaction_id;
		                    List<KmMoneyHistory> kmMoneyHistoryList = kmMoneyHistoryDAO.findByRemark(remark);
		                    if (kmMoneyHistoryList==null || kmMoneyHistoryList.size()==0) {
		                    	KmMoneyHistory kmMoneyHistory = new KmMoneyHistory();
		                    	kmMoneyHistory.setCreatetime(new Date());
		                    	kmMoneyHistory.setUserid(userid);
		                    	kmMoneyHistory.setRemark(remark);
		                    	kmMoneyHistoryDAO.save(kmMoneyHistory);
		                    	
		                    	KmParent kmParent = kmParentDAO.findById(userid);
		                    	if (kmParent!=null) {
		                    		Date vip = kmParent.getVip();
		                    		if (vip == null||vip.getTime()<new Date().getTime()) {
		                    			vip = new Date();
		                    		}
		                    		Calendar cal = Calendar.getInstance();
		                    		cal.setTime(vip);
		                    		if (product_id.equals("cn.kidmate.vip.month1"))
		                    			cal.add(Calendar.MONTH, 1);
		                    		else if (product_id.equals("cn.kidmate.vip.month3"))
		                    			cal.add(Calendar.MONTH, 3);
		                    		else if (product_id.equals("cn.kidmate.vip.month6"))
		                    			cal.add(Calendar.MONTH, 6);
		                    		else if (product_id.equals("cn.kidmate.vip.month12"))
		                    			cal.add(Calendar.MONTH, 12);
		                    		vip = cal.getTime();
		                    		kmParent.setVip(vip);
		                    		kmParentDAO.attachDirty(kmParent);
		                    	}
		                    } 
//		                    else {
//		                    	ExceptionUtil.throwDefaultKmException("请勿重复调用");
//		                    }
	                    }
                	} 
                    //保存到数据库  
                    return Constants.OP_SUC;
                    
                }else{  
                    //账单无效  
                    if (states.equals("21007") && !sandbox) {
                    	appStoreRecharge(userid, receipt, true);
                    } else {
                    	ExceptionUtil.throwDefaultKmException("校验有误");
                    }
                }
			}
//		}
		return 0;
	}

	public KmMoneyHistoryDAO getKmMoneyHistoryDAO() {
		return kmMoneyHistoryDAO;
	}

	public void setKmMoneyHistoryDAO(KmMoneyHistoryDAO kmMoneyHistoryDAO) {
		this.kmMoneyHistoryDAO = kmMoneyHistoryDAO;
	}

	public KmParentDAO getKmParentDAO() {
		return kmParentDAO;
	}

	public void setKmParentDAO(KmParentDAO kmParentDAO) {
		this.kmParentDAO = kmParentDAO;
	}
}
