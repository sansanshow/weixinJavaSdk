package com.kidmate.service.impl;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.thrift.TException;
import org.springframework.stereotype.Service;

import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

import com.kidmate.kmservice.TKmAppInfo;
import com.kidmate.kmservice.TKmAppInfoUpload;
import com.kidmate.kmservice.TKmException;
import com.kidmate.kmservice.TKmUser;
import com.kidmate.model.KmAppInfo;
import com.kidmate.model.KmAppInfoDAO;
import com.kidmate.model.KmEquipmentApp;
import com.kidmate.model.KmEquipmentAppDAO;
import com.kidmate.service.IAppInfoService;
import com.kidmate.tools.Config;
import com.kidmate.tools.Constants;
import com.kidmate.tools.FileUtil;
import com.kidmate.tools.MdmUtils;
import com.kidmate.tools.RedisUtil;
import com.kidmate.tools.SerializeUtil;

public class AppInfoServiceImpl implements IAppInfoService{
	private KmAppInfoDAO kmAppInfoDAO;
	private KmEquipmentAppDAO kmEquipmentAppDAO;
	private ShardedJedisPool shardedJedisPool;
	private Config config;
	private RedisUtil redisUtil;
	private static Logger logger = Logger.getLogger(AppInfoServiceImpl.class);
	@Override
	public List<TKmAppInfo> getAppInfoByIds(List<Long> appIDList)
			throws TException {
		List<TKmAppInfo> tKmAppInfoList = new ArrayList<TKmAppInfo>();
		if (appIDList==null || appIDList.size()==0) {
			return tKmAppInfoList;
		}
		List<KmAppInfo> kmAppInfoList =new ArrayList<KmAppInfo>();
		KmAppInfo kmin=null;
		ShardedJedis shardedJedis = null;
		for (long appid : appIDList) {
			kmin = redisUtil.hgetObject(shardedJedis, Constants.APP_INFOMATION,String.valueOf(appid));
			if (kmin != null) {
				kmAppInfoList.add(kmin);
			}else{
				kmin=kmAppInfoDAO.findById(appid);
				if (kmin != null) {
					kmAppInfoList.add(kmin);
					redisUtil.hsetObject(shardedJedis,Constants.APP_INFOMATION, String.valueOf(appid),kmin);
                }
			}

		}
		//List<KmAppInfo> kmAppInfoList = kmAppInfoDAO.findByIdList(appIDList);	
		for (KmAppInfo kmAppInfo:kmAppInfoList) {
			TKmAppInfo tKmAppInfo = new TKmAppInfo();
			tKmAppInfo.setId(kmAppInfo.getId());
			tKmAppInfo.setName(kmAppInfo.getName());
			tKmAppInfo.setPackagename(kmAppInfo.getPackagename());
			tKmAppInfo.setUrl(config.getImageUrl() + "/" + kmAppInfo.getIcon());
			tKmAppInfoList.add(tKmAppInfo);
		}
		return tKmAppInfoList;
	}
	
	@Override
	public List<TKmAppInfo> checkExistApp(List<String> packageList)
			throws TException {
		// TODO Auto-generated method stub
		List<KmAppInfo> kmAppInfoList = kmAppInfoDAO.findExistAppInfo(packageList);
		List<TKmAppInfo> tKmAppInfoList = new ArrayList<TKmAppInfo>();
		for (KmAppInfo kmAppInfo:kmAppInfoList) {
			TKmAppInfo tKmAppInfo = new TKmAppInfo();
			tKmAppInfo.setId(kmAppInfo.getId());
			tKmAppInfo.setName(kmAppInfo.getName());
			tKmAppInfo.setPackagename(kmAppInfo.getPackagename());
			tKmAppInfo.setUrl(config.getImageUrl() + "/" + kmAppInfo.getIcon());
			tKmAppInfoList.add(tKmAppInfo);
		}
		return tKmAppInfoList;
	}

	public List<TKmAppInfo> getAllAppInfo(long equipmentID) throws TException{
		List<KmAppInfo> kmAppInfoList = kmAppInfoDAO.findByEquipmentID(equipmentID);
		List<TKmAppInfo> tKmAppInfoList = new ArrayList<TKmAppInfo>();
		for (KmAppInfo kmAppInfo:kmAppInfoList) {
			TKmAppInfo tKmAppInfo = new TKmAppInfo();
			tKmAppInfo.setId(kmAppInfo.getId());
			tKmAppInfo.setName(kmAppInfo.getName());
			tKmAppInfo.setPackagename(kmAppInfo.getPackagename());
			tKmAppInfo.setUrl(config.getImageUrl() + "/" + kmAppInfo.getIcon());
			tKmAppInfoList.add(tKmAppInfo);
		}
		return tKmAppInfoList;
	}
	
	public List<TKmAppInfo> getAllChildAppInfo(long childid) throws TException{
		List<KmAppInfo> kmAppInfoList = kmAppInfoDAO.findByChildID(childid);
		List<TKmAppInfo> tKmAppInfoList = new ArrayList<TKmAppInfo>();
		for (KmAppInfo kmAppInfo:kmAppInfoList) {
			TKmAppInfo tKmAppInfo = new TKmAppInfo();
			tKmAppInfo.setId(kmAppInfo.getId());
			tKmAppInfo.setName(kmAppInfo.getName());
			tKmAppInfo.setPackagename(kmAppInfo.getPackagename());
			tKmAppInfo.setUrl(config.getImageUrl() + "/" + kmAppInfo.getIcon());
			tKmAppInfoList.add(tKmAppInfo);
		}
		return tKmAppInfoList;
	}
	
	@Override
	public List<TKmAppInfo> addNewAppInfo(long userid, List<TKmAppInfoUpload> appInfoUploadList) throws TException {
		// TODO Auto-generated method stub
		
		List<String> packageList = new ArrayList<String>();
		for (TKmAppInfoUpload tKmAppInfoUpload:appInfoUploadList) {
			packageList.add(tKmAppInfoUpload.getPackagename());
		}
		List<KmAppInfo> kmAppInfoList = kmAppInfoDAO.findExistAppInfo(packageList);
		List<TKmAppInfo> tKmAppInfoList = new ArrayList<TKmAppInfo>();
		Set<String> packageSet = new HashSet<String>();
		for (KmAppInfo kmAppInfo:kmAppInfoList) {
			TKmAppInfo tKmAppInfo = new TKmAppInfo();
			tKmAppInfo.setId(kmAppInfo.getId());
			tKmAppInfo.setName(kmAppInfo.getName());
			tKmAppInfo.setPackagename(kmAppInfo.getPackagename());
			tKmAppInfo.setUrl(config.getImageUrl() + "/" + kmAppInfo.getIcon());
			tKmAppInfoList.add(tKmAppInfo);
			packageSet.add(kmAppInfo.getPackagename());
		}
		for (TKmAppInfoUpload tKmAppInfoUpload:appInfoUploadList) {
			if (!packageSet.contains(tKmAppInfoUpload.getPackagename())) {
				KmAppInfo kmAppInfo = new KmAppInfo();
				kmAppInfo.setName(tKmAppInfoUpload.getName());
				kmAppInfo.setPackagename(tKmAppInfoUpload.getPackagename());
				kmAppInfo.setFromtype("0");
				if (tKmAppInfoUpload.getIcon() == null) {
					String src = "https://itunes.apple.com/lookup?bundleId="
							+ tKmAppInfoUpload.getPackagename();
					ByteBuffer byBu = null;
					try {
						String imgSrc = MdmUtils.getImgUrl(src);
						if (imgSrc == null) {
							byBu = null;
						} else {
							byBu = MdmUtils.getImageFromNetByUrl(imgSrc);
						}
					} catch (Exception e) {
						byBu = null;
					}
					tKmAppInfoUpload.setIcon(byBu);
				}
                String name = FileUtil.saveFile(tKmAppInfoUpload.bufferForIcon(),config.getImagePath());
				kmAppInfo.setIcon(name);
                kmAppInfoDAO.save(kmAppInfo);
				TKmAppInfo tKmAppInfo = new TKmAppInfo();
				tKmAppInfo.setId(kmAppInfo.getId());
				tKmAppInfo.setName(kmAppInfo.getName());
				tKmAppInfo.setPackagename(kmAppInfo.getPackagename());
				if (kmAppInfo.getIcon()==null || kmAppInfo.getIcon().indexOf("http://")!=-1)
					tKmAppInfo.setUrl(kmAppInfo.getIcon());
				else
					tKmAppInfo.setUrl(config.getImageUrl() + "/" +kmAppInfo.getIcon());
				tKmAppInfoList.add(tKmAppInfo);
				packageSet.add(kmAppInfo.getPackagename());
			}
		}
		
		return tKmAppInfoList;
	}

	@Override
	public List<TKmAppInfo> bindToEquipment(long equipmentID,
			List<Long> appIDList) throws TException {
		// TODO Auto-generated method stub
		
		List<KmEquipmentApp> kmEquipmentAppList = kmEquipmentAppDAO.findByEquipmentid(equipmentID);
		for (KmEquipmentApp kmEquipmentApp:kmEquipmentAppList) {
			if (appIDList.contains(kmEquipmentApp.getAppid())) {
				if (!kmEquipmentApp.getStatus().equals("1")) {
					kmEquipmentApp.setStatus("1");
					kmEquipmentAppDAO.attachDirty(kmEquipmentApp);
				}
				appIDList.remove(kmEquipmentApp.getAppid());
			}
		}
		for (Long appid:appIDList) {
			KmEquipmentApp kmEquipmentApp = new KmEquipmentApp();
			kmEquipmentApp.setAppid(appid);
			kmEquipmentApp.setCreatetime(new Date());
			kmEquipmentApp.setEquipmentid(equipmentID);
			kmEquipmentApp.setStatus("1");
			kmEquipmentAppDAO.save(kmEquipmentApp);
		}
		return getAllAppInfo(equipmentID);
	}

	public KmAppInfoDAO getKmAppInfoDAO() {
		return kmAppInfoDAO;
	}

	public void setKmAppInfoDAO(KmAppInfoDAO kmAppInfoDAO) {
		this.kmAppInfoDAO = kmAppInfoDAO;
	}

	public KmEquipmentAppDAO getKmEquipmentAppDAO() {
		return kmEquipmentAppDAO;
	}

	public void setKmEquipmentAppDAO(KmEquipmentAppDAO kmEquipmentAppDAO) {
		this.kmEquipmentAppDAO = kmEquipmentAppDAO;
	}

	public ShardedJedisPool getShardedJedisPool() {
		return shardedJedisPool;
	}

	public void setShardedJedisPool(ShardedJedisPool shardedJedisPool) {
		this.shardedJedisPool = shardedJedisPool;
	}

	public Config getConfig() {
		return config;
	}

	public void setConfig(Config config) {
		this.config = config;
	}

	@Override
	public boolean unInstallApp(TKmUser user, long appid) throws TKmException {
		// TODO Auto-generated method stub
		KmEquipmentApp kmEquipmentApp = new KmEquipmentApp();
		kmEquipmentApp.setAppid(appid);
		kmEquipmentApp.setEquipmentid(user.userid);
		
		List<KmEquipmentApp> eas = kmEquipmentAppDAO.findByExample(kmEquipmentApp);
		if(eas != null && eas.size()>0 ){
			for(KmEquipmentApp kmEquips: eas){
				kmEquips.setStatus("0");
				kmEquipmentAppDAO.attachDirty(kmEquips);
			}
			return true;
		}
		return false;
	}

	@Override
	public boolean InstallApp(TKmUser user, long appid) throws TKmException {
		KmEquipmentApp kmEquipmentApp = new KmEquipmentApp();
		kmEquipmentApp.setAppid(appid);
		kmEquipmentApp.setEquipmentid(user.userid);
		
		List<KmEquipmentApp> eas = kmEquipmentAppDAO.findByExample(kmEquipmentApp);
		if(eas != null && eas.size()>0 ){
			for(KmEquipmentApp kmEquips: eas){
				kmEquips.setStatus("1");
				kmEquipmentAppDAO.attachDirty(kmEquips);
			}
			return true;
		}
		return false;
	}

	public RedisUtil getRedisUtil() {
		return redisUtil;
	}

	public void setRedisUtil(RedisUtil redisUtil) {
		this.redisUtil = redisUtil;
	}

	

}
