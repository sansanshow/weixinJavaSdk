package com.kidmate.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.kidmate.kmservice.TKmPosition;
import com.kidmate.kmservice.TKmWifi;
import com.kidmate.model.KmLocation;
import com.kidmate.model.KmLocationDAO;
import com.kidmate.model.KmWifi;
import com.kidmate.model.KmWifiDAO;
import com.kidmate.service.IPositionService;

public class PositionServiceImpl implements IPositionService {

	private KmLocationDAO kmLocationDAO;
	private KmWifiDAO kmWifiDAO;
	@Override
	public long updatePosition(long equipmentid, TKmPosition position) {
		// TODO Auto-generated method stub
		KmLocation kmLocation = new KmLocation();
		kmLocation.setEquipmentid(equipmentid);
		kmLocation.setLatitude(position.getLatitude());
		kmLocation.setLongitude(position.getLongitude());
		kmLocation.setCreatetime(new Date());
		kmLocationDAO.save(kmLocation);
		return kmLocation.getId();
	}

	@Override
	public long updateWifi(long equipmentid, TKmWifi wifi, String ip) {
		// TODO Auto-generated method stub
		KmWifi kmWifi = new KmWifi();
		kmWifi.setEquipmentid(equipmentid);
		kmWifi.setIp(ip);
		kmWifi.setWifiname(wifi.getWifiname());
		kmWifi.setWifissid(wifi.getWifissid());
		kmWifiDAO.save(kmWifi);
		return kmWifi.getId();
	}

	@Override
	public TKmPosition getLatestPosition(long equipmentid) {
		// TODO Auto-generated method stub
		TKmPosition tKmPosition = new TKmPosition();
		KmLocation kmLocation = kmLocationDAO.findLatestLocatiom(equipmentid);
		if (kmLocation != null) {
			tKmPosition.setId(kmLocation.getId());
			tKmPosition.setTime(kmLocation.getCreatetime().getTime());
			tKmPosition.setLatitude(kmLocation.getLatitude());
			tKmPosition.setLongitude(kmLocation.getLongitude());
		}
		return tKmPosition;
	}

	public List<TKmPosition> getPositionList(long equipmentid, int page, int size){
		List<TKmPosition> tKmPositionList = new ArrayList<TKmPosition>();
		List<KmLocation> kmLocationList = kmLocationDAO.findLatestLocatiom(equipmentid, page, size);
		for (KmLocation kmLocation : kmLocationList) {
			TKmPosition tKmPosition = new TKmPosition();
			tKmPosition.setId(kmLocation.getId());
			tKmPosition.setTime(kmLocation.getCreatetime().getTime());
			tKmPosition.setLatitude(kmLocation.getLatitude());
			tKmPosition.setLongitude(kmLocation.getLongitude());
			tKmPositionList.add(tKmPosition);
		}
		return tKmPositionList;
	}
	
	public KmWifiDAO getKmWifiDAO() {
		return kmWifiDAO;
	}

	public void setKmWifiDAO(KmWifiDAO kmWifiDAO) {
		this.kmWifiDAO = kmWifiDAO;
	}

	public KmLocationDAO getKmLocationDAO() {
		return kmLocationDAO;
	}

	public void setKmLocationDAO(KmLocationDAO kmLocationDAO) {
		this.kmLocationDAO = kmLocationDAO;
	}

}
