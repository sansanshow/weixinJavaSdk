package com.kidmate.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.kidmate.kmservice.TKmCredit;
import com.kidmate.kmservice.TKmException;
import com.kidmate.model.KmCredit;
import com.kidmate.model.KmCreditDAO;
import com.kidmate.model.KmCreditDetail;
import com.kidmate.model.KmCreditDetailDAO;
import com.kidmate.model.KmCreditTypeDAO;
import com.kidmate.model.KmParent;
import com.kidmate.model.KmParentDAO;
import com.kidmate.model.KmRss;
import com.kidmate.model.KmRssChan;
import com.kidmate.model.KmRssChannelDao;
import com.kidmate.model.KmRssDao;
import com.kidmate.service.ICreditService;
import com.kidmate.service.IKmRssService;
import com.kidmate.tools.ConfigUtils;
import com.kidmate.tools.Constants;
import com.kidmate.tools.CreditTypeUtil;
import com.kidmate.tools.ExceptionUtil;
import com.kidmate.tools.SecurityUtils;
import com.kidmate.tools.SerializeUtil;
import com.kidmate.tools.StringUtils;
import com.kidmate.tools.TimeUtil;



import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;


/*
 * creditType ==1：表示签到,2表示邀请好友  3表示分享后好友通过分享登入
 */
public class CreditServiceImpl  implements ICreditService{
	private KmCreditDAO kmCreditDao;
	private KmCreditDetailDAO kmCreditDetailDao;
	private KmCreditTypeDAO kmCreditTypeDao;
	private ShardedJedisPool shardedJedisPool;
	private KmParentDAO kmParentDAO;
	private KmRssChannelDao  kmRssChannelDao;
	private KmRssDao  kmRssDao;
	private static Logger logger = Logger.getLogger(CreditServiceImpl .class);
	@Override
	public List<TKmCredit> saveKmCredit(long userid, long creditType,
			long userCredit) {
		// //1表示签到,2表示分享好友，3表示分享后好友凭分享码登入，四表示兑换vip
		ShardedJedis shardedJedis = shardedJedisPool.getResource();
	    List<TKmCredit>  tKmcre=new ArrayList<TKmCredit>();
		TKmCredit tc=new TKmCredit();
		String credit=null;
		long score=0;
		Date time=TimeUtil.getToday();
		if(creditType==1 || creditType==2){  //1表示签到,2表示分享好友
			List creditDetail=kmCreditDetailDao.findByCretim(userid,creditType, time);
			if(creditDetail.size()>0 && creditType==1){
				//System.out.print(b)
				return tKmcre;  //这种类型的积分已经获取过了不能在获取
			}else if(creditDetail.size()>=3 && creditType==2){
				return tKmcre;  //分享超过了三次不在获得积分
			}
			
		}
		
		if(shardedJedis.hexists(Constants.CREDIT, String.valueOf(userid+Constants.CREDIT))){
			credit=shardedJedis.hget(Constants.CREDIT,String.valueOf(userid+Constants.CREDIT));
			score=Long.parseLong(credit)+Long.parseLong(ConfigUtils.getConfig("CREDITSCORE"+creditType));
			//credit=String.valueOf(Long.parseLong(credit)+creditType);
			//shardedJedis.hset("credit", String.valueOf(userid+"credit"), String.valueOf(score));
		}else{
			List creditDetails=kmCreditDetailDao.findByUserId(userid);
			if(creditDetails!=null && creditDetails.size()>0){
				KmCreditDetail kmc=(KmCreditDetail) creditDetails.get(0);
				score=kmc.getCredit()+Long.parseLong(ConfigUtils.getConfig("CREDITSCORE"+creditType));
			}else{
				score=Long.parseLong(ConfigUtils.getConfig("CREDITSCORE"+creditType));
			}
		}
		if (score >= 0) {
			if(creditType==4){
				KmParent kmParent=kmParentDAO.findById(userid);
				if(kmParent!=null){
					Date vip = kmParent.getVip();
					if (vip == null||vip.getTime()<new Date().getTime()) {
	        			vip = new Date();
	        		}
	        		Calendar cal = Calendar.getInstance();
	        		cal.setTime(vip);
	        		cal.add(Calendar.MONTH, 1);
	        		vip = cal.getTime();
	        		kmParent.setVip(vip);
	        		kmParentDAO.attachDirty(kmParent);
				}
			}
		    KmCreditDetail kmCredit = new KmCreditDetail();
			kmCredit.setPid(userid);
			kmCredit.setStatus("1");
			kmCredit.setCreatetime(new Date());
			kmCredit.setTypeid(creditType);
			kmCredit.setCredit(score);
			kmCredit.setCreditchange(Long.parseLong(ConfigUtils
					.getConfig("CREDITSCORE" + creditType)));
			kmCreditDetailDao.save(kmCredit);
			shardedJedis.hset(Constants.CREDIT, String.valueOf(userid + Constants.CREDIT),
					String.valueOf(score));
			shardedJedisPool.returnResource(shardedJedis);
			tc.setCid(userid);
			tc.setCredittype(creditType);
			tc.setCreditopera(1);// -1表示已经操作过了。
			tc.setUsercredit(score);
			tKmcre.add(tc);
			return tKmcre;
		}
			shardedJedisPool.returnResource(shardedJedis);
			return tKmcre;
		
	}
	//null 表示获取所有
	@Override
	public List<TKmCredit> getKmcredit(long userid,List<Long> type) {
		// TODO Auto-generated method stub
		ShardedJedis shardedJedis = shardedJedisPool.getResource();
		List<TKmCredit>  tKmcre=new ArrayList<TKmCredit>();
		String credit=null;
		long score = 0;
		if(shardedJedis.hexists(Constants.CREDIT, String.valueOf(userid+Constants.CREDIT))){
			credit=shardedJedis.hget(Constants.CREDIT,String.valueOf(userid+Constants.CREDIT));
			score=Long.parseLong(credit);
		}else{
			List creditDetails=kmCreditDetailDao.findByUserId(userid);
			if(creditDetails!=null && creditDetails.size()>0){
				KmCreditDetail kmc=(KmCreditDetail) creditDetails.get(0);
				//credit=kmc.getCredit();
				score=kmc.getCredit();
			}
			shardedJedis.hset(Constants.CREDIT,String.valueOf(userid+Constants.CREDIT), String.valueOf(score));
		};
	
		shardedJedisPool.returnResource(shardedJedis);
		  
	   //判断不同类型的积分用户是否在规定的时间获取到
		  if(type==null || type.size()==0){
			  TKmCredit tc1=new TKmCredit();
			  tc1.setCid(userid);
			  tc1.setUsercredit(score);
			  tKmcre.add(tc1);
		  }else{
			Date time=TimeUtil.getToday();
			for(long creditType:type){
				 TKmCredit tc=new TKmCredit();
				    tc.setCid(userid);
				    tc.setUsercredit(score);
				if(creditType==1){   // 1表示签到类型的积分
					List creditDetail=kmCreditDetailDao.findByCretim(userid, creditType,time);
					if(creditDetail.size()>0){
						   tc.setCredittype(creditType);
						   tc.setCreditopera(-1); //这种类型的积分已经获取过了不能在获取
					}else{
						   tc.setCredittype(creditType);
						   tc.setCreditopera(1); //这种类型的积分还未获取
					}
				}else{
					tc.setCredittype(creditType);
					tc.setCreditopera(1); //这种类型的积分还未获取
				}
				
				tKmcre.add(tc);
			}
		  }
		
	   
		return tKmcre;
	}
	//生成用户分享码
	@Override
	public String getCreditInvite(long userid,long creditType) {
		// TODO Auto-generated method stub
		String inviteCode=null;
		KmParent kmparent=kmParentDAO.findById(userid);
		if(kmparent==null){
			try {
				ExceptionUtil.throwUnauthorizedKmException();
			} catch (TKmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else{
			if(kmparent.getInvitecode()!=null){
				inviteCode=kmparent.getInvitecode();
			}else{
				inviteCode=String.valueOf(userid);
//				inviteCode=SecurityUtils.md5ByHex(userid+"sc").substring(0,4)+userid;
//				inviteCode=inviteCode.toLowerCase();
				kmparent.setInvitecode(inviteCode);
				kmParentDAO.attachDirty(kmparent);
			}
			logger.info("-----------------inviteCode=="+inviteCode);
		}
		System.out.println("---------------inviteCode"+inviteCode);
		return inviteCode;
	}

	//Spring 的定时调度任务,保存积分
	@Override
	public void quartzCredit() {
		// TODO Auto-generated method stub
		ShardedJedis shardedJedis = shardedJedisPool.getResource();
		 Map<String, String> credit=shardedJedis.hgetAll(Constants.CREDIT);
		 shardedJedisPool.returnResource(shardedJedis);
	        Set keySet=credit.keySet();
	       Iterator it=keySet.iterator();
	         while(it.hasNext()){
	        	 String k=(String) it.next();
	        	 String score=credit.get(k);
	        	List<KmCredit> kmCredit=kmCreditDao.findByUserId(Long.parseLong(k.substring(0,k.length()-8)));
	        	KmCredit kc=null;
	        	 if(kmCredit!=null && kmCredit.size()==1){
	        		 kc=kmCredit.get(0);
	        		 kc.setCredit(Long.parseLong(score));
	        	 }else{
	        		 kc=new KmCredit();
	        		 kc.setCredit(Long.parseLong(score));
	        		 kc.setUpdatetime(new Date());
	        		 kc.setPid(Long.parseLong(k.substring(0,k.length()-8)));
	        		 kc.setStatus("1");
	        	 }
	        	 kmCreditDao.attachDirty(kc);
	        	 System.out.println("userid="+k+"---score="+score);
	         }
	}
	
	//生成kmRss的新闻
	@Override
	public List<KmRssChan> getRssList(long userId, long channelType) {
		// TODO Auto-generated method stub
		ShardedJedis shardedJedis = shardedJedisPool.getResource();
		List<KmRssChan> rssc=new ArrayList<KmRssChan>();
		if(shardedJedis.hexists("kmrss".getBytes(),("newsfeed").getBytes())){
			rssc= SerializeUtil.unserializeList(shardedJedis.hget("kmrss".getBytes(),("newsfeed").getBytes()));
		    System.out.println("------------------------------redis中Controlrule=="+rssc.size());
		}else{
			List<KmRss> rss=kmRssDao.findByChannelPage(10, 1);
			for(KmRss r:rss){
				KmRssChan rc=new KmRssChan();
				rc.setId(r.getId());
				rc.setChannelId(r.getChannelId());
				rc.setAuthor(r.getAuthor());
				rc.setCategory(r.getCategory());
				rc.setPubdate(r.getPubdate());
				rc.setLink(r.getLink());
				rc.setDescription(StringUtils.subDescrip(r.getDescription()));
				rc.setPictureUrl(StringUtils.subUrl(r.getDescription()));
				rc.setTitle(r.getTitle());
				rssc.add(rc);
			}
			
			shardedJedis.hset("kmrss".getBytes(),("newsfeed").getBytes(),SerializeUtil.serializeList(rssc));
		}
		shardedJedisPool.returnResource(shardedJedis);
		 return rssc;
	}
	public KmCreditDAO getKmCreditDao() {
		return kmCreditDao;
	}
	public void setKmCreditDao(KmCreditDAO kmCreditDao) {
		this.kmCreditDao = kmCreditDao;
	}
	public KmCreditDetailDAO getKmCreditDetailDao() {
		return kmCreditDetailDao;
	}
	public void setKmCreditDetailDao(KmCreditDetailDAO kmCreditDetailDao) {
		this.kmCreditDetailDao = kmCreditDetailDao;
	}
	public ShardedJedisPool getShardedJedisPool() {
		return shardedJedisPool;
	}
	public void setShardedJedisPool(ShardedJedisPool shardedJedisPool) {
		this.shardedJedisPool = shardedJedisPool;
	}
	public static Logger getLogger() {
		return logger;
	}
	public static void setLogger(Logger logger) {
		CreditServiceImpl.logger = logger;
	}

	public KmCreditTypeDAO getKmCreditTypeDao() {
		return kmCreditTypeDao;
	}

	public void setKmCreditTypeDao(KmCreditTypeDAO kmCreditTypeDao) {
		this.kmCreditTypeDao = kmCreditTypeDao;
	}

	public KmParentDAO getKmParentDAO() {
		return kmParentDAO;
	}

	public void setKmParentDAO(KmParentDAO kmParentDAO) {
		this.kmParentDAO = kmParentDAO;
	}

	public KmRssChannelDao getKmRssChannelDao() {
		return kmRssChannelDao;
	}

	public void setKmRssChannelDao(KmRssChannelDao kmRssChannelDao) {
		this.kmRssChannelDao = kmRssChannelDao;
	}

	public KmRssDao getKmRssDao() {
		return kmRssDao;
	}

	public void setKmRssDao(KmRssDao kmRssDao) {
		this.kmRssDao = kmRssDao;
	}

	

	

	
	
}
