package com.kidmate.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.thrift.TException;

import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

import com.kidmate.kmservice.InternalService;
import com.kidmate.kmservice.TKmControlRuleInfo;
import com.kidmate.kmservice.TKmEquipment;
import com.kidmate.kmservice.TKmException;
import com.kidmate.model.KmAppControlRule;
import com.kidmate.model.KmAppControlRuleDAO;
import com.kidmate.model.KmGuardian;
import com.kidmate.model.KmGuardianDao;
import com.kidmate.service.IChildUserService;
import com.kidmate.service.IControlService;
import com.kidmate.service.IEquipmentService;
import com.kidmate.tools.Constants;
import com.kidmate.tools.ExceptionUtil;
import com.kidmate.tools.InternalServiceUtil;
import com.kidmate.tools.SerializeUtil;

public class ControlServiceImpl implements IControlService{

	private KmAppControlRuleDAO kmAppControlRuleDAO;
	private IEquipmentService equipmentService;
	private ShardedJedisPool shardedJedisPool;
	private InternalServiceUtil internalServiceUtil;
	private KmGuardianDao kmGuardianDao;
	private IChildUserService childUserService;
	private static Logger logger = Logger.getLogger(ControlServiceImpl.class);
	@Override
	public TKmControlRuleInfo saveControlRule(long parentID,
			TKmControlRuleInfo tKmControlRuleInfo) throws TKmException{
		// TODO Auto-generated method stub
		KmAppControlRule kmAppControlRule = null; 
		long kmparentid=childUserService.getParentId(tKmControlRuleInfo.getChildId());
		if (tKmControlRuleInfo.getId()!=0) {
    		kmAppControlRule = kmAppControlRuleDAO.findById(tKmControlRuleInfo.getId());
			if (!kmAppControlRule.getParentid().equals(parentID)) {
				List<KmGuardianDao> guparent=kmGuardianDao.findByCpa(parentID);
				if(guparent==null || guparent.size()==0){
					ExceptionUtil.throwUnauthorizedKmException();
				}
				//ExceptionUtil.throwUnauthorizedKmException();
			}
		} else { 
			if (tKmControlRuleInfo.getAppId()>=5000 || tKmControlRuleInfo.getAppId()==1) {
				KmAppControlRule t = new KmAppControlRule();
				t.setAppid(tKmControlRuleInfo.getAppId());
				t.setParentid(kmparentid);
				t.setChildid(tKmControlRuleInfo.getChildId());
				List<KmAppControlRule> kmAppControlRuleList = kmAppControlRuleDAO.findByExample(t);
				for (KmAppControlRule k : kmAppControlRuleList) {
					if (k.getEquipmentid()==tKmControlRuleInfo.getEquipmentId()) {
						kmAppControlRule = k;
						break;
					}
				}
			}
			if (kmAppControlRule==null) {
				kmAppControlRule = new KmAppControlRule();
				kmAppControlRule.setParentid(kmparentid);
			}
		}
		ShardedJedis shardedJedis = shardedJedisPool.getResource();
		if(shardedJedis.hexists(Constants.CONTROLRULE,String.valueOf(tKmControlRuleInfo.getChildId()+"CON"+tKmControlRuleInfo.getEquipmentId()))){
			shardedJedis.hdel(Constants.CONTROLRULE.getBytes(), (tKmControlRuleInfo.getChildId()+"CON"+tKmControlRuleInfo.getEquipmentId()).getBytes());
		}
		shardedJedisPool.returnResource(shardedJedis);
		kmAppControlRule.setCreatetime(new Date());
		kmAppControlRule.setAppid(tKmControlRuleInfo.getAppId());
		kmAppControlRule.setChildid(tKmControlRuleInfo.getChildId());
		kmAppControlRule.setEquipmentid(tKmControlRuleInfo.getEquipmentId());
		kmAppControlRule.setDuration(Long.valueOf(tKmControlRuleInfo.getDur()).intValue());
		kmAppControlRule.setEndtime(Long.valueOf(tKmControlRuleInfo.getEndTime()).intValue());
		kmAppControlRule.setStarttime(Long.valueOf(tKmControlRuleInfo.getStartTime()).intValue());
		kmAppControlRule.setStatus(tKmControlRuleInfo.isOn()?"1":"0");
		kmAppControlRule.setExceptapp(tKmControlRuleInfo.getExceptapp());
		kmAppControlRule.setRepeattype(tKmControlRuleInfo.getRepeatType());
		kmAppControlRule.setControlname(tKmControlRuleInfo.getControlname());
		if (kmAppControlRule.getId()!=null) {
			kmAppControlRuleDAO.attachDirty(kmAppControlRule);
		} else {
			kmAppControlRuleDAO.save(kmAppControlRule);
		}
		tKmControlRuleInfo.setId(kmAppControlRule.getId());
		//TODO 推送消息至儿童设备
		String content = "{\"type\":\"1\"}";
		if(tKmControlRuleInfo.getAppId() == 1) {
			if(tKmControlRuleInfo.isOn()) {
				content = "{\"type\":\"3\"}";
			} else {
				content = "{\"type\":\"2\"}";
			}
		}
		InternalService.Iface iface = internalServiceUtil.borrowInternal();
		try {
			logger.info("----------------保存规则发送给孩子内容"+content);
			if (tKmControlRuleInfo.getEquipmentId()!=0)
				iface.sendMessge(2, "1000", String.valueOf(tKmControlRuleInfo.getEquipmentId()), content, "规则更新", null);
			else if (tKmControlRuleInfo.getChildId()!=0){
				List<TKmEquipment> tKmEquipmentList = childUserService.getChildEquipmentList(parentID, tKmControlRuleInfo.getChildId());
				for (TKmEquipment tKmEquipment:tKmEquipmentList) {
					iface.sendMessge(2, "1000", String.valueOf(tKmEquipment.getId()), content, "规则更新", null);
				}
			}
		} catch (TException e) {
			e.printStackTrace();
		}
		internalServiceUtil.returnInternal(iface);
		
		return tKmControlRuleInfo;
	}
	
	@Override
	public boolean setControlRuleOn(long parentID, long ruleId) throws TKmException{
		// TODO Auto-generated method stub
		KmAppControlRule kmAppControlRule = kmAppControlRuleDAO.findById(ruleId);
		if (parentID!=kmAppControlRule.getParentid()) {
			KmGuardian km=new KmGuardian();
			km.setCparentId(parentID);
			km.setParentId(kmAppControlRule.getParentid());
			km.setStatus("1");
			List<KmGuardian> kpt=kmGuardianDao.findByExample(km);
			if(kpt==null){
				ExceptionUtil.throwUnauthorizedKmException();
			}
		}
		ShardedJedis shardedJedis = shardedJedisPool.getResource();
		if(shardedJedis.hexists(Constants.CONTROLRULE,String.valueOf(kmAppControlRule.getChildid()+"CON"+kmAppControlRule.getEquipmentid()))){
			shardedJedis.hdel(Constants.CONTROLRULE.getBytes(), (kmAppControlRule.getChildid()+"CON"+kmAppControlRule.getEquipmentid()).getBytes());
		}
		shardedJedisPool.returnResource(shardedJedis);
		if (!kmAppControlRule.getStatus().equals("1")) {
			kmAppControlRule.setStatus("1");
			kmAppControlRuleDAO.attachDirty(kmAppControlRule);
		}
		//TODO 推送消息至儿童设备
		InternalService.Iface iface = internalServiceUtil.borrowInternal();
		try {
			if (kmAppControlRule.getEquipmentid()!=0)
				iface.sendMessge(2, "1000", String.valueOf(kmAppControlRule.getEquipmentid()), "{\"type\":\"1\"}", "规则更新", null);
			else if (kmAppControlRule.getChildid()!=0){
				List<TKmEquipment> tKmEquipmentList = childUserService.getChildEquipmentList(parentID, kmAppControlRule.getChildid());
				for (TKmEquipment tKmEquipment:tKmEquipmentList) {
					iface.sendMessge(2, "1000", String.valueOf(tKmEquipment.getId()), "{\"type\":\"1\"}", "规则更新", null);
				}
			}
		} catch (TException e) {
			e.printStackTrace();
		}
		internalServiceUtil.returnInternal(iface);
		return true;
	}

	@Override
	public boolean setControlRuleOff(long parentID, long ruleId) throws TKmException{
		// TODO Auto-generated method stub
		KmAppControlRule kmAppControlRule = kmAppControlRuleDAO.findById(ruleId);
		if (parentID!=kmAppControlRule.getParentid()) {
			KmGuardian km=new KmGuardian();
			km.setCparentId(parentID);
			km.setParentId(kmAppControlRule.getParentid());
			km.setStatus("1");
			List<KmGuardian> kpt=kmGuardianDao.findByExample(km);
			if(kpt==null){
				ExceptionUtil.throwUnauthorizedKmException();
			}
		}
		ShardedJedis shardedJedis = shardedJedisPool.getResource();
		if(shardedJedis.hexists(Constants.CONTROLRULE,String.valueOf(kmAppControlRule.getChildid()+"CON"+kmAppControlRule.getEquipmentid()))){
			shardedJedis.hdel(Constants.CONTROLRULE.getBytes(), (kmAppControlRule.getChildid()+"CON"+kmAppControlRule.getEquipmentid()).getBytes());
		}
		shardedJedisPool.returnResource(shardedJedis);
		if (!kmAppControlRule.getStatus().equals("0")) {
			kmAppControlRule.setStatus("0");
			kmAppControlRuleDAO.attachDirty(kmAppControlRule);
		}
		//TODO 推送消息至儿童设备
		InternalService.Iface iface = internalServiceUtil.borrowInternal();
		try {
			if (kmAppControlRule.getEquipmentid()!=0)
				iface.sendMessge(2, "1000", String.valueOf(kmAppControlRule.getEquipmentid()), "{\"type\":\"1\"}", "规则更新", null);
			else if (kmAppControlRule.getChildid()!=0){
				List<TKmEquipment> tKmEquipmentList = childUserService.getChildEquipmentList(parentID, kmAppControlRule.getChildid());
				for (TKmEquipment tKmEquipment:tKmEquipmentList) {
					iface.sendMessge(2, "1000", String.valueOf(tKmEquipment.getId()), "{\"type\":\"1\"}", "规则更新", null);
				}
			}
		} catch (TException e) {
			e.printStackTrace();
		}
		internalServiceUtil.returnInternal(iface);
		return true;
	}
	
	@Override
	public boolean setControlRuleInfoOffByAppid(long parentId, long appid,
			long childid, long equipmentID) {
		// TODO Auto-generated method stub
		long parent=childUserService.getParentId(childid);
		KmAppControlRule kmAppControlRule = new KmAppControlRule();
		kmAppControlRule.setAppid(appid);
		kmAppControlRule.setParentid(parent);
		kmAppControlRule.setChildid(childid);
		List<KmAppControlRule> kmAppControlRuleList = kmAppControlRuleDAO.findByExample(kmAppControlRule);
		for (KmAppControlRule k:kmAppControlRuleList) {
			if (equipmentID==0 || equipmentID==k.getEquipmentid()) {
				if (!k.getStatus().equals("0")) {
					k.setStatus("0");
					kmAppControlRuleDAO.attachDirty(k);
				}
			}
		}
		ShardedJedis shardedJedis = shardedJedisPool.getResource();
		if(shardedJedis.hexists(Constants.CONTROLRULE,String.valueOf(kmAppControlRule.getChildid()+"CON"+kmAppControlRule.getEquipmentid()))){
			shardedJedis.hdel(Constants.CONTROLRULE.getBytes(), (kmAppControlRule.getChildid()+"CON"+kmAppControlRule.getEquipmentid()).getBytes());
		}
		shardedJedisPool.returnResource(shardedJedis);
		InternalService.Iface iface = internalServiceUtil.borrowInternal();
		try {
			if (equipmentID!=0)
				iface.sendMessge(2, "1000", String.valueOf(equipmentID), "{\"type\":\"1\"}", "规则更新", null);
			else if (kmAppControlRule.getChildid()!=0){
				List<TKmEquipment> tKmEquipmentList = childUserService.getChildEquipmentList(parentId, childid);
				for (TKmEquipment tKmEquipment:tKmEquipmentList) {
					iface.sendMessge(2, "1000", String.valueOf(tKmEquipment.getId()), "{\"type\":\"1\"}", "规则更新", null);
				}
			}
		} catch (TException e) {
			e.printStackTrace();
		}
		internalServiceUtil.returnInternal(iface);
		
		return true;
	}
	
	@Override
	public boolean delControlRule(long parentID, long ruleId)
			throws TKmException {
		KmAppControlRule kmAppControlRule = kmAppControlRuleDAO.findById(ruleId);
		if (parentID!=kmAppControlRule.getParentid()) {
			KmGuardian km=new KmGuardian();
			km.setCparentId(parentID);
			km.setParentId(kmAppControlRule.getParentid());
			km.setStatus("1");
			List<KmGuardian> kpt=kmGuardianDao.findByExample(km);
			if(kpt==null){
				ExceptionUtil.throwUnauthorizedKmException();
			}
		}
		if (!kmAppControlRule.getStatus().equals("2")) {
			kmAppControlRule.setStatus("2");
			kmAppControlRuleDAO.attachDirty(kmAppControlRule);
		}
		ShardedJedis shardedJedis = shardedJedisPool.getResource();
		if(shardedJedis.hexists(Constants.CONTROLRULE,String.valueOf(kmAppControlRule.getChildid()+"CON"+kmAppControlRule.getEquipmentid()))){
			shardedJedis.hdel(Constants.CONTROLRULE.getBytes(), (kmAppControlRule.getChildid()+"CON"+kmAppControlRule.getEquipmentid()).getBytes());
		}
		shardedJedisPool.returnResource(shardedJedis);
		// 推送消息至儿童设备
		long equipmentID = kmAppControlRule.getEquipmentid();
		InternalService.Iface iface = internalServiceUtil.borrowInternal();
		try {
			if (equipmentID!=0)
				iface.sendMessge(2, "1000", String.valueOf(equipmentID), "{\"type\":\"1\"}", "规则更新", null);
			else if (kmAppControlRule.getChildid()!=0){
				List<TKmEquipment> tKmEquipmentList = childUserService.getChildEquipmentList(parentID, kmAppControlRule.getChildid());
				for (TKmEquipment tKmEquipment:tKmEquipmentList) {
					iface.sendMessge(2, "1000", String.valueOf(tKmEquipment.getId()), "{\"type\":\"1\"}", "规则更新", null);
				}
			}
		} catch (TException e) {
			e.printStackTrace();
		}
		internalServiceUtil.returnInternal(iface);
		
		return true;
	}

	@Override
	public List<TKmControlRuleInfo> getChildControlRuleList(long childID) {
		List<KmAppControlRule> kmAppControlRuleList = new ArrayList<KmAppControlRule>();
		List<TKmControlRuleInfo> tKmControlRuleInfoList = new ArrayList<TKmControlRuleInfo>();
		ShardedJedis shardedJedis = shardedJedisPool.getResource();
		if(shardedJedis.hexists(Constants.CONTROLRULE,String.valueOf(childID+"CON"+0))){
			tKmControlRuleInfoList= SerializeUtil.unserializeList(shardedJedis.hget(Constants.CONTROLRULE.getBytes(),String.valueOf(childID+"CON"+0).getBytes()));
		    System.out.println("------------------------------redis中Controlrule"+tKmControlRuleInfoList.size());
		    shardedJedisPool.returnResource(shardedJedis);
		    return tKmControlRuleInfoList;
		}
		kmAppControlRuleList = kmAppControlRuleDAO.findByChildid(childID);
		for (KmAppControlRule kmAppControlRule:kmAppControlRuleList) {
			if ("0".equals(kmAppControlRule.getStatus()) || "1".equals(kmAppControlRule.getStatus())) {
				TKmControlRuleInfo tKmControlRuleInfo = new TKmControlRuleInfo();
				tKmControlRuleInfo.setId(kmAppControlRule.getId());
				tKmControlRuleInfo.setParentId(kmAppControlRule.getParentid());
				tKmControlRuleInfo.setAppId(kmAppControlRule.getAppid());
				tKmControlRuleInfo.setChildId(kmAppControlRule.getChildid());
				tKmControlRuleInfo.setDur(kmAppControlRule.getDuration());
				tKmControlRuleInfo.setEndTime(kmAppControlRule.getEndtime());
				tKmControlRuleInfo.setStartTime(kmAppControlRule.getStarttime());
				tKmControlRuleInfo.setOn("1".equals(kmAppControlRule.getStatus()));
				tKmControlRuleInfo.setExceptapp(kmAppControlRule.getExceptapp());
				tKmControlRuleInfo.setRepeatType(kmAppControlRule.getRepeattype());
				tKmControlRuleInfo.setCreattime(kmAppControlRule.getCreatetime().getTime());
				tKmControlRuleInfo.setControlname(kmAppControlRule.getControlname());
				tKmControlRuleInfoList.add(tKmControlRuleInfo);
			}
		}
		shardedJedis.hset(Constants.CONTROLRULE.getBytes(),String.valueOf(childID+"CON"+0).getBytes(),SerializeUtil.serializeList(tKmControlRuleInfoList));
		shardedJedisPool.returnResource(shardedJedis);
		return tKmControlRuleInfoList;
	}

	@Override
	public List<TKmControlRuleInfo> getEquipmentControlRuleList(long equipmentID) {
		long childid = equipmentService.getChildID(equipmentID, null);
		List<KmAppControlRule> kmAppControlRuleList = new ArrayList<KmAppControlRule>();
		List<TKmControlRuleInfo> tKmControlRuleInfoList = new ArrayList<TKmControlRuleInfo>();
		ShardedJedis shardedJedis = shardedJedisPool.getResource();
		if(shardedJedis.hexists(Constants.CONTROLRULE,String.valueOf(childid+"CON"+equipmentID))){
			tKmControlRuleInfoList= SerializeUtil.unserializeList(shardedJedis.hget(Constants.CONTROLRULE.getBytes(),String.valueOf(childid+"CON"+equipmentID).getBytes()));
		    System.out.println("------------------------------redis中Controlrule"+tKmControlRuleInfoList.size());
		    shardedJedisPool.returnResource(shardedJedis);
		    return tKmControlRuleInfoList;
		}
			KmAppControlRule r = new KmAppControlRule();
			r.setChildid(childid);
			r.setEquipmentid(equipmentID);
			kmAppControlRuleList = kmAppControlRuleDAO.findByExample(r);
			
		for (KmAppControlRule kmAppControlRule:kmAppControlRuleList) {
			if ("0".equals(kmAppControlRule.getStatus()) || "1".equals(kmAppControlRule.getStatus())) {
				TKmControlRuleInfo tKmControlRuleInfo = new TKmControlRuleInfo();
				tKmControlRuleInfo.setId(kmAppControlRule.getId());
				tKmControlRuleInfo.setParentId(kmAppControlRule.getParentid());
				tKmControlRuleInfo.setAppId(kmAppControlRule.getAppid());
				tKmControlRuleInfo.setChildId(kmAppControlRule.getChildid());
				tKmControlRuleInfo.setEquipmentId(kmAppControlRule.getEquipmentid());
				if(kmAppControlRule.getDuration()==null){
					tKmControlRuleInfo.setDur(0);
				}else{
					tKmControlRuleInfo.setDur(kmAppControlRule.getDuration());
				}
				
				tKmControlRuleInfo.setEndTime(kmAppControlRule.getEndtime());
				tKmControlRuleInfo.setStartTime(kmAppControlRule.getStarttime());
				tKmControlRuleInfo.setOn("1".equals(kmAppControlRule.getStatus()));
				tKmControlRuleInfo.setExceptapp(kmAppControlRule.getExceptapp());
				tKmControlRuleInfo.setRepeatType(kmAppControlRule.getRepeattype());
				tKmControlRuleInfo.setCreattime(kmAppControlRule.getCreatetime().getTime());
				tKmControlRuleInfo.setControlname(kmAppControlRule.getControlname());
				tKmControlRuleInfoList.add(tKmControlRuleInfo);
			}
		}
		shardedJedis.hset(Constants.CONTROLRULE.getBytes(),String.valueOf(childid+"CON"+equipmentID).getBytes(),SerializeUtil.serializeList(tKmControlRuleInfoList));
		shardedJedisPool.returnResource(shardedJedis);
		System.out.println("--------------tKmControlRuleInfoList.size()===="+tKmControlRuleInfoList.size());
		return tKmControlRuleInfoList;
	}
	
	@Override
	public List<TKmControlRuleInfo> getEquipmentAllControlRuleList(long equipmentID) {
		long childId=equipmentService.getChildID(equipmentID, null);
		List<KmAppControlRule> kmAppControlRuleList = new ArrayList<KmAppControlRule>();
		List<TKmControlRuleInfo> tKmControlRuleInfoList = new ArrayList<TKmControlRuleInfo>();
		ShardedJedis shardedJedis = shardedJedisPool.getResource();
		if(shardedJedis.hexists(Constants.CONTROLRULE,String.valueOf(childId+"CON"+equipmentID))){
			tKmControlRuleInfoList= SerializeUtil.unserializeList(shardedJedis.hget(Constants.CONTROLRULE.getBytes(),String.valueOf(childId+"CON"+equipmentID).getBytes()));
		    System.out.println("------------------------------redis中Controlrule=="+tKmControlRuleInfoList.size());
		    return tKmControlRuleInfoList;
		}
		 kmAppControlRuleList = kmAppControlRuleDAO.findEquipmentAllRule(equipmentID,childId);
		 for (KmAppControlRule kmAppControlRule:kmAppControlRuleList) {
			if ("0".equals(kmAppControlRule.getStatus()) || "1".equals(kmAppControlRule.getStatus())) {
				TKmControlRuleInfo tKmControlRuleInfo = new TKmControlRuleInfo();
				tKmControlRuleInfo.setId(kmAppControlRule.getId());
				tKmControlRuleInfo.setParentId(kmAppControlRule.getParentid());
				tKmControlRuleInfo.setAppId(kmAppControlRule.getAppid());
				tKmControlRuleInfo.setEquipmentId(kmAppControlRule.getEquipmentid());
				tKmControlRuleInfo.setChildId(kmAppControlRule.getChildid());
				tKmControlRuleInfo.setDur(kmAppControlRule.getDuration());
				tKmControlRuleInfo.setEndTime(kmAppControlRule.getEndtime());
				tKmControlRuleInfo.setStartTime(kmAppControlRule.getStarttime());
				tKmControlRuleInfo.setOn("1".equals(kmAppControlRule.getStatus()));
				tKmControlRuleInfo.setExceptapp(kmAppControlRule.getExceptapp());
				tKmControlRuleInfo.setRepeatType(kmAppControlRule.getRepeattype());
				tKmControlRuleInfo.setCreattime(kmAppControlRule.getCreatetime().getTime());
				tKmControlRuleInfoList.add(tKmControlRuleInfo);
			}
		}
		 shardedJedis.hset(Constants.CONTROLRULE.getBytes(),String.valueOf(childId+"CON"+equipmentID).getBytes(),SerializeUtil.serializeList(kmAppControlRuleList));
		shardedJedisPool.returnResource(shardedJedis);
		return tKmControlRuleInfoList;
	}
    
    //  立即截屏发送消息给儿童端
	@Override
	public void getsnapshot(long parentId, long equipmentID) {
		 //long childid = equipmentService.getChildID(equipmentID, null);
		  //long partsid=childUserService.getParentId(childid);
		  // 推送消息给儿童设备
	
		InternalService.Iface iface = internalServiceUtil.borrowInternal();
		try {
//			if (parentId != partsid) {
//				ExceptionUtil.throwUnauthorizedKmException();
//			}
			if (equipmentID != 0)
				iface.sendMessge(2, "1000", String.valueOf(equipmentID),"{\"type\":\"5\"}", "规则更新", null);
			System.out.println("-----------snapshot"+equipmentID);
		} catch (TException e) {
			e.printStackTrace();
		}
		internalServiceUtil.returnInternal(iface);
		
		if(String.valueOf(parentId)!=null){
			ShardedJedis shardedJedis = shardedJedisPool.getResource();
			shardedJedis.hset(Constants.SNAPSHOTID,String.valueOf(equipmentID+"snapshot"), String.valueOf(parentId));
			shardedJedisPool.returnResource(shardedJedis);
		}
	}
	
	public KmAppControlRuleDAO getKmAppControlRuleDAO() {
		return kmAppControlRuleDAO;
	}

	public void setKmAppControlRuleDAO(KmAppControlRuleDAO kmAppControlRuleDAO) {
		this.kmAppControlRuleDAO = kmAppControlRuleDAO;
	}

	public ShardedJedisPool getShardedJedisPool() {
		return shardedJedisPool;
	}

	public void setShardedJedisPool(ShardedJedisPool shardedJedisPool) {
		this.shardedJedisPool = shardedJedisPool;
	}

	public IEquipmentService getEquipmentService() {
		return equipmentService;
	}

	public void setEquipmentService(IEquipmentService equipmentService) {
		this.equipmentService = equipmentService;
	}

	public InternalServiceUtil getInternalServiceUtil() {
		return internalServiceUtil;
	}

	public void setInternalServiceUtil(InternalServiceUtil internalServiceUtil) {
		this.internalServiceUtil = internalServiceUtil;
	}

	public IChildUserService getChildUserService() {
		return childUserService;
	}

	public void setChildUserService(IChildUserService childUserService) {
		this.childUserService = childUserService;
	}

	public KmGuardianDao getKmGuardianDao() {
		return kmGuardianDao;
	}

	public void setKmGuardianDao(KmGuardianDao kmGuardianDao) {
		this.kmGuardianDao = kmGuardianDao;
	}

	
   
}
