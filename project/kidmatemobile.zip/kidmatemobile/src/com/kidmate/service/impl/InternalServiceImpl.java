package com.kidmate.service.impl;

import org.apache.log4j.Logger;
import org.apache.thrift.TException;

import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

import com.kidmate.kmservice.InternalService;
import com.kidmate.kmservice.TKmAppUsage;
import com.kidmate.kmservice.TKmException;
import com.kidmate.thread.AppUsageRunnable;
import com.kidmate.thread.AppUsageRunnable.AppUsage;
import com.kidmate.thread.MessageSendRunnable;
import com.kidmate.tools.Config;
import com.kidmate.tools.Constants;
import com.kidmate.tools.SerializeUtil;

public class InternalServiceImpl implements InternalService.Iface{
	private static Logger logger = Logger.getLogger(InternalServiceImpl.class);
	private AppUsageRunnable appUsageRunnable;
	private MessageSendRunnable ParentMessageSendRunnable;
	private MessageSendRunnable ChildMessageSendRunnable;
	private ShardedJedisPool shardedJedisPool;
	private Config config;
	@Override
	public boolean ping() throws TException {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean addAppUsage(long equipmentid, long appid, long wifiid,
			long positionid, long time, String ip) throws TException {
		// TODO Auto-generated method stub
		AppUsage appUsage = new AppUsage(equipmentid, appid, wifiid, positionid, ip, time); 
		ShardedJedis shardedJedis = shardedJedisPool.getResource();
		shardedJedis.lpush(Constants.APP_USEAGE.getBytes(), SerializeUtil.serialize(appUsage));
		shardedJedisPool.returnResourceObject(shardedJedis);
		synchronized(appUsageRunnable) {
			appUsageRunnable.notify();
		   //appUsageRunnable.notifyAll();
		}
		return true;
	}

	@Override
	public boolean sendMessge(int selectClient, String fromid, String toid,
			String content, String summary, String extend) throws TKmException,
			TException {
		// TODO Auto-generated method stub
		MessageSendRunnable messageSendRunnable = null;
		if (selectClient==1) {
			messageSendRunnable = ParentMessageSendRunnable;
		} else if (selectClient==2) {
			messageSendRunnable = ChildMessageSendRunnable;
			if (config.isDevelop()) {
				toid = "test" + toid;
			}
		}
		if (messageSendRunnable!=null) {
			messageSendRunnable.addMessage(true, fromid, toid, content, summary, extend);
		}
		return true;
	}

	public AppUsageRunnable getAppUsageRunnable() {
		return appUsageRunnable;
	}

	public void setAppUsageRunnable(AppUsageRunnable appUsageRunnable) {
		this.appUsageRunnable = appUsageRunnable;
	}

	public MessageSendRunnable getParentMessageSendRunnable() {
		return ParentMessageSendRunnable;
	}

	public void setParentMessageSendRunnable(MessageSendRunnable parentMessageSendRunnable) {
		ParentMessageSendRunnable = parentMessageSendRunnable;
	}

	public MessageSendRunnable getChildMessageSendRunnable() {
		return ChildMessageSendRunnable;
	}

	public void setChildMessageSendRunnable(MessageSendRunnable childMessageSendRunnable) {
		ChildMessageSendRunnable = childMessageSendRunnable;
	}

	public ShardedJedisPool getShardedJedisPool() {
		return shardedJedisPool;
	}

	public void setShardedJedisPool(ShardedJedisPool shardedJedisPool) {
		this.shardedJedisPool = shardedJedisPool;
	}

	public Config getConfig() {
		return config;
	}

	public void setConfig(Config config) {
		this.config = config;
	}


}
