package com.kidmate.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.thrift.TException;

import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

import com.kidmate.kmservice.InternalService;
import com.kidmate.kmservice.TKmAppUsage;
import com.kidmate.kmservice.TKmEquipment;
import com.kidmate.kmservice.TKmException;
import com.kidmate.kmservice.TKmUser;
import com.kidmate.model.KmAppControlRule;
import com.kidmate.model.KmAppControlRuleDAO;
import com.kidmate.model.KmChild;
import com.kidmate.model.KmChildEquipment;
import com.kidmate.model.KmChildEquipmentDAO;
import com.kidmate.model.KmEquipment;
import com.kidmate.model.KmEquipmentApp;
import com.kidmate.model.KmEquipmentAppDAO;
import com.kidmate.model.KmEquipmentDAO;
import com.kidmate.model.KmParent;
import com.kidmate.model.KmGuardian;
import com.kidmate.model.KmGuardianDao;
import com.kidmate.service.IAppUsageService;
import com.kidmate.service.IChildUserService;
import com.kidmate.service.IEquipmentService;
import com.kidmate.service.IParentUserService;
import com.kidmate.servlet.BaseTServlet;
import com.kidmate.tools.Config;
import com.kidmate.tools.Constants;
import com.kidmate.tools.ExceptionUtil;
import com.kidmate.tools.InternalServiceUtil;
import com.kidmate.tools.SecurityUtils;
import com.taobao.api.ApiException;
import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.domain.Userinfos;
import com.taobao.api.request.OpenimUsersAddRequest;
import com.taobao.api.request.OpenimUsersUpdateRequest;
import com.taobao.api.response.OpenimUsersAddResponse;
import com.taobao.api.response.OpenimUsersUpdateResponse;

public class EquipmentServiceImpl implements IEquipmentService {

	private KmEquipmentDAO kmEquipmentDAO;
	private Config config;
	private ShardedJedisPool shardedJedisPool;
	private KmChildEquipmentDAO kmChildEquipmentDAO;
	private KmEquipmentAppDAO kmEquipmentAppDAO;
	private KmGuardianDao kmGuardianDao;
	private IAppUsageService appUsageService;
	private IParentUserService parentUserService;
	private InternalServiceUtil internalServiceUtil;
	private IChildUserService childUserService;
    private KmAppControlRuleDAO  kmAppControlRuleDAO;
	private static Logger logger = Logger.getLogger(EquipmentServiceImpl.class);
	@Override
	public TKmUser bindEquipment(String mac, String ip, String qrcode, int source, String name) throws TException {
		// TODO Auto-generated method stub
		String params[]=params = qrcode.split("\\$");
		String qsign = null;
		try{
			qsign = params[3].trim();
		}catch(Exception e){
			ExceptionUtil.throwDefaultKmException("请扫描正确的二维码！");
		}
		long time = Long.valueOf(params[2].trim());
		if (Math.abs(System.currentTimeMillis()-time)>120000) {
			ExceptionUtil.throwDefaultKmException("时间过期，请家长端刷新二维码后重新扫描！");
		}
		long parentId = Long.valueOf(params[0].trim());
		long childID = Long.valueOf(params[1].trim());
		System.out.println("parentUserService.getVerifyUserSign(parentId)==="+parentUserService.getVerifyUserSign(parentId).substring(0, 32));
		String md5toke = parentUserService.getVerifyUserSign(parentId).substring(0, 32);
		System.out.println("--------------md5toke"+md5toke);
		String t = SecurityUtils.md5ByHex("" + (parentId<<1) + (childID<<2) + (time<<3) + md5toke).substring(8, 16);
		logger.info("---------:" + t);
		if (!SecurityUtils.md5ByHex("" + (parentId<<1) + (childID<<2) + (time<<3) + md5toke).substring(8, 16).equals(qsign)) {
			ExceptionUtil.throwDefaultKmException("二维码校验有误！");
		}
		
		KmEquipment kmEquipment = new KmEquipment();
		kmEquipment.setParentid(parentId);  //根据mac找，找到这台设备是否被绑定过，一台设备只允许存在一条记录。
		kmEquipment.setMac(mac);
		//kmEquipment.setStatus("1");
		List<KmEquipment> kmEquipmentList = kmEquipmentDAO.findByExample(kmEquipment);
		String sign = SecurityUtils.md5ByHex("%q23r"+ Math.random() + Math.random());
		System.out.println("sign======================"+sign);
		boolean isNew = false;
		 if (kmEquipmentList==null || kmEquipmentList.size()==0) {
//			long chilparentid=childUserService.getParentId(childID);
//			if(chilparentid!=parentId){
//				parentId=chilparentid;
//			}
				kmEquipment.setRegip(ip);
				kmEquipment.setAlias(name);
				kmEquipment.setRegsource(source);
				kmEquipment.setParentid(parentId);
				kmEquipment.setCreatetime(new Date());
				kmEquipment.setLastupdate(new Date());
				kmEquipment.setLastip(ip);
				kmEquipment.setSign(sign);
				kmEquipment.setStatus("1");
				if(source==1000){
				  kmEquipment.setEquipmenttype("1");
				}else{
				  kmEquipment.setEquipmenttype("0");
				}
				kmEquipmentDAO.save(kmEquipment);
				isNew = true;
			
		} else {
			kmEquipment = kmEquipmentList.get(0);
            kmEquipment.setLastupdate(new Date());
			kmEquipment.setLastip(ip);
		    kmEquipment.setSign(sign);
			if (source ==1000) {
				kmEquipment.setEquipmenttype("1");
			} else {
				kmEquipment.setEquipmenttype("0");
			}
			kmEquipment.setStatus("1");
			kmEquipmentDAO.attachDirty(kmEquipment);

		}
		 KmEquipment kmet2 = new KmEquipment();  //这个设备只允许被一台家长端绑定。其他绑定的会删除。
		     kmet2.setMac(mac);
		     kmet2.setStatus("1");
			List<KmEquipment> oneEuipment = kmEquipmentDAO.findByExample(kmet2);
			for(KmEquipment oe:oneEuipment){
				if(oe.getParentid()!=null&&!oe.getParentid().equals(parentId)){
					oe.setStatus("0");
					kmEquipmentDAO.attachDirty(oe);
				}
			}
		TaobaoClient client = new DefaultTaobaoClient(config.getTaoBaoServerUrl(), config.getChildAppKey(), config.getChildAppSec());
		List<Userinfos> userinfoList = new ArrayList<Userinfos>();
		Userinfos userinfo = new Userinfos();
		userinfo.setUserid((config.isDevelop()?"test":"") + String.valueOf(kmEquipment.getId()));
		userinfo.setPassword(SecurityUtils.md5ByHex(sign));
		System.out.println("password==============="+userinfo.getPassword()+"userinfo=="+userinfo.getUserid());
		userinfoList.add(userinfo);
		try {
			if (isNew) {
				//TODO im添加账号
				OpenimUsersAddRequest req = new OpenimUsersAddRequest();
				req.setUserinfos(userinfoList);
				OpenimUsersAddResponse rsp = client.execute(req);
			}
			//TODO im修改密码
			OpenimUsersUpdateRequest req = new OpenimUsersUpdateRequest();
			req.setUserinfos(userinfoList);
			OpenimUsersUpdateResponse rsp = client.execute(req);
		} catch (Exception e) {
			ExceptionUtil.throwDefaultKmException("IM信息更新有误");
		}
	
			childUserService.bindEquipment(parentId, childID, kmEquipment.getId());

	   //TODO 向家长发送消息，绑定成功
		InternalService.Iface iface = internalServiceUtil.borrowInternal();
		try {
			if(params.length!=5){
				iface.sendMessge(1, "1000", parentUserService.getAccountId(parentId), "{\"type\":\"1\"}", "绑定成功", null);
				System.out.println("----------------parentId.getAccountId=="+parentUserService.getAccountId(parentId)+"====parentId"+parentId+"childID===="+childID+"kmEquipment.getId()===="+kmEquipment.getId());
			}
		} catch (TException e) {
			e.printStackTrace();
		}
		internalServiceUtil.returnInternal(iface);
		
		
		TKmUser tKmUser = new TKmUser();
		tKmUser.setUserid(kmEquipment.getId());
		tKmUser.setSign(sign);		
		ShardedJedis shardedJedis = shardedJedisPool.getResource();
		shardedJedis.hset(Constants.EQUIPMENTSIGN, String.valueOf(kmEquipment.getId()), sign);
		shardedJedisPool.returnResource(shardedJedis);
		System.out.println("sign="+tKmUser.getSign()+" id=="+tKmUser.getUserid());
		return tKmUser;
	}
	
	@Override
	public boolean delEquipment(long parentId,long childId,long euqipmentId) {
		// TODO Auto-generated method stub
		KmEquipment kmEquipment = kmEquipmentDAO.findById(euqipmentId);
        if(kmEquipment==null||!kmEquipment.getParentid().equals(parentId)){
			try {
				ExceptionUtil.throwUnauthorizedKmException();
				return false;
			} catch (TKmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}
		}
		KmAppControlRule kmAppCon=new KmAppControlRule();
		kmAppCon.setParentid(parentId);
		kmAppCon.setEquipmentid(euqipmentId);
		if(childId>0){
			kmAppCon.setChildid(childId);
			System.out.println("-----"+parentId+"ee="+euqipmentId+"childId"+childId);
			List<KmAppControlRule> kmAppConRus=kmAppControlRuleDAO.findByExample(kmAppCon);
		    for(KmAppControlRule s:kmAppConRus){
		    	if(s.getAppid()!=2L){
		    		s.setStatus("0");
					kmAppControlRuleDAO.attachDirty(s);
		    	}
			}
		}
		
		//TODO 向家长发送消息，解绑成功
				InternalService.Iface iface = internalServiceUtil.borrowInternal();
				try {
					iface.sendMessge(1, "1000", parentUserService.getAccountId(parentId), "{\"type\":\"1\"}", "删除设备", null);
				} catch (TException e) {
					e.printStackTrace();
				}
				internalServiceUtil.returnInternal(iface);
		if (kmEquipment!=null && kmEquipment.getParentid()==parentId) {  //分享的家长不能删除设备。
			kmEquipment.setStatus("0");
			String sign = SecurityUtils.md5ByHex("%q23r"+ Math.random() + Math.random());
			kmEquipment.setSign(sign);
			kmEquipmentDAO.attachDirty(kmEquipment);
			ShardedJedis shardedJedis = shardedJedisPool.getResource();
			shardedJedis.hset(Constants.EQUIPMENTSIGN, String.valueOf(kmEquipment.getId()), sign);
			shardedJedisPool.returnResource(shardedJedis);
		}
		return true;
	}
	
	@Override
	public TKmEquipment editEquipmentName(long parentId, long equipmentId,
			String name) throws TException {
		// TODO Auto-generated method stub
		KmEquipment kmEquipment = kmEquipmentDAO.findById(equipmentId);
		if (kmEquipment!=null && kmEquipment.getParentid()==parentId) {
			kmEquipment.setAlias(name);
			kmEquipmentDAO.attachDirty(kmEquipment);
			TKmEquipment tKmEquipment = new TKmEquipment();
			tKmEquipment.setAliasName(kmEquipment.getAlias());
			tKmEquipment.setMac(kmEquipment.getMac());
			tKmEquipment.setId(kmEquipment.getId());
			tKmEquipment.setChildId(this.getChildID(equipmentId, null));
//			tKmEquipment.setSign(kmEquipment.getSign());
			
			return tKmEquipment;
		}
		return null;
	}
	
	@Override
	public long getChildID(long equipmentId, ShardedJedis shardedJedis) {
		// TODO Auto-generated method stub
		boolean re = false;
		long childid = 0;
		if (shardedJedis==null) {
			re = true;
			shardedJedis = shardedJedisPool.getResource();
		}
		if (shardedJedis.hexists(Constants.EQ2CID, String.valueOf(equipmentId))) {
			childid = Long.valueOf(shardedJedis.hget(Constants.EQ2CID, String.valueOf(equipmentId)));
		} else {
			List<KmChildEquipment> kmChildEquipmentList = kmChildEquipmentDAO.findByEquipmentid(equipmentId);
			if (kmChildEquipmentList!=null && kmChildEquipmentList.size()>0) {
				childid = kmChildEquipmentList.get(0).getChildid();
			} 
			shardedJedis.hset(Constants.EQ2CID, String.valueOf(equipmentId), String.valueOf(childid));
		}
		if (re) {
			shardedJedisPool.returnResource(shardedJedis);
		}
		return childid;
	}
	
	@Override
	public List<Long> getAppIds(long equipmentId) {
		// TODO Auto-generated method stub
		KmEquipmentApp kmEquipmentApp = new KmEquipmentApp();
		kmEquipmentApp.setEquipmentid(equipmentId);
		kmEquipmentApp.setStatus("1");
		List<KmEquipmentApp> kmEquipmentAppList = kmEquipmentAppDAO.findByExample(kmEquipmentApp);
		//System.out.println(kmEquipmentAppList.size());
		List<Long> ids = new ArrayList<Long>();
		for (KmEquipmentApp e:kmEquipmentAppList) {
			if(!ids.contains(e.getAppid()))
				ids.add(e.getAppid());
		}
          if(ids.size()==0){
        	// 推送消息至儿童设备
      		//System.out.println("推送消息="+equipmentId);
      		InternalService.Iface iface = internalServiceUtil.borrowInternal();
      		try {
      			if (equipmentId!=0)
      				iface.sendMessge(2, "1000", String.valueOf(equipmentId), "{\"type\":\"4\"}", "数据更新", null);
      			
      		} catch (TException e) {
      			e.printStackTrace();
      		}
      		internalServiceUtil.returnInternal(iface);
          }
		return ids;
	}
	
	@Override
	public List<Long> getAppUderControlIds(long equipmentId) {
		// TODO Auto-generated method stub
//		KmEquipmentApp kmEquipmentApp = new KmEquipmentApp();
//		kmEquipmentApp.setEquipmentid(equipmentId);
//		kmEquipmentApp.setStatus("1");
		List<KmEquipmentApp> kmEquipmentAppList = kmEquipmentAppDAO.getAppUderControlIds(equipmentId);
		List<Long> ids = new ArrayList<Long>();
		for (KmEquipmentApp e:kmEquipmentAppList) {
			if (!ids.contains(e.getAppid()))
				ids.add(e.getAppid());
		}
		return ids;
	}
	
	@Override
	public List<Long> getAppOutofControlIds(long equipmentId) {
		// TODO Auto-generated method stub
//		KmEquipmentApp kmEquipmentApp = new KmEquipmentApp();
//		kmEquipmentApp.setEquipmentid(equipmentId);
//		kmEquipmentApp.setStatus("1");
		List<KmEquipmentApp> kmEquipmentAppList = kmEquipmentAppDAO.getAppOutofControlIds(equipmentId);
		List<Long> ids = new ArrayList<Long>();
		for (KmEquipmentApp e:kmEquipmentAppList) {
			if (!ids.contains(e.getAppid()))
				ids.add(e.getAppid());
		}
		return ids;
	}
	
	@Override
	public boolean verifyUserSign(TKmUser user, boolean mustLogin)
			throws TKmException {
		// TODO Auto-generated method stub
		
		if (Math.abs(System.currentTimeMillis()-user.getTimestamp())>120000) {
			ExceptionUtil.throwDefaultKmException("时间过期，请刷新");
		}
		String sign = null;
		ShardedJedis shardedJedis = shardedJedisPool.getResource();//清除缓存
		if (shardedJedis.hexists(Constants.EQUIPMENTSIGN, String.valueOf(user.getUserid()))){
			sign = shardedJedis.hget(Constants.EQUIPMENTSIGN, String.valueOf(user.getUserid()));
		} else {
			KmEquipment kmEquipment = kmEquipmentDAO.findById(user.getUserid());
			if (kmEquipment!=null) {
				sign = kmEquipment.getSign();
				shardedJedis.hset(Constants.EQUIPMENTSIGN, String.valueOf(user.getUserid()), sign);
			}
		}
		shardedJedisPool.returnResource(shardedJedis);
		String s = sign + (user.getTimestamp()<<5);
		String ss = SecurityUtils.md5ByHex(sign + (user.getTimestamp()<<5));
		System.out.println("------"+sign+"----------------s" + s+"--------ss"+ss+"user.getsin"+user.getSign()+"user.getTimestamp()"+user.getTimestamp());
		if (sign==null || !SecurityUtils.md5ByHex(sign + (user.getTimestamp()<<5)).equals(user.getSign())) {
			if (mustLogin) {
				ExceptionUtil.throwUnloginKmException();
			} else {
				user.setUserid(0);
			}
		}
		return true;
	}
	
	@Override
	public List<TKmEquipment> getParentEquipmentList(long parentID)
			throws TException {
		List<KmEquipment> kmEquipmentList = kmEquipmentDAO.findByParentid(parentID);
		
		List<KmGuardian> kmpaequ=kmGuardianDao.findByCpa(parentID);
		for(KmGuardian kpe:kmpaequ){
			List<KmEquipment>  kmEquip=kmEquipmentDAO.findByParentid(kpe.getParentId());
			kmEquipmentList.addAll(kmEquip);
		}
		List<TKmEquipment> tKmEquipmentList = new ArrayList<TKmEquipment>();
		for (KmEquipment kmEquipment: kmEquipmentList) {
			if ("1".equals(kmEquipment.getStatus())) {
				TKmEquipment tKmEquipment = new TKmEquipment();
				tKmEquipment.setAliasName(kmEquipment.getAlias());
				tKmEquipment.setMac(kmEquipment.getMac());
				tKmEquipment.setId(kmEquipment.getId());
				tKmEquipment.setChildId(this.getChildID(kmEquipment.getId(), null));
				System.out.println("-------getAllEquipmentList  "+tKmEquipment.getId()+"-----parentID"+parentID);
//				try {
//					Thread.sleep(2000);
//					System.out.println("睡眠500");
//				} catch (InterruptedException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
				TKmAppUsage tkmAppUsage = appUsageService.getTheLatestAppUsage(kmEquipment.getId(), null);
				if(kmEquipment.getEquipmenttype() != null && kmEquipment.getEquipmenttype().equals("1")){
					tKmEquipment.setLasttime(System.currentTimeMillis());
					tKmEquipmentList.add(tKmEquipment);
				}else if (tkmAppUsage!=null){
					tKmEquipment.setLasttime(tkmAppUsage.getTime()+tkmAppUsage.getDuration());
					//tKmEquipment.setLasttime(System.currentTimeMillis());
					tKmEquipmentList.add(tKmEquipment);
				}else if(tkmAppUsage==null){  
					tKmEquipment.setLasttime(kmEquipment.getLastupdate().getTime());
					tKmEquipmentList.add(tKmEquipment);
				}
			}
		}
	  logger.info("-----------getallequipment"+tKmEquipmentList.size());
		return tKmEquipmentList;
	}
    
	@Override
	public boolean isEquipmentLocked(TKmUser user, long childid,
			long equipmentid) throws TKmException {
		KmChildEquipment e = new KmChildEquipment();
		e.setChildid(childid);
		e.setEquipmentid(equipmentid);
	    List equipments = kmChildEquipmentDAO.findByExample(e);
		if(equipments != null && equipments.size() > 0) {
			KmChildEquipment ce = (KmChildEquipment)equipments.get(0);
			if(ce.getStatus() != null && ce.getStatus().equals("2")) {
				System.out.println("----------true");
			return true;
			}else{
				return false;
			}
		}
		return false;
	}
	
	@Override
	public void updateLockStatus(TKmUser user, String status)
			throws TKmException {
		List equipments = kmChildEquipmentDAO.findByEquipmentid(user.userid);
		if(equipments != null && equipments.size() > 0) {
			KmChildEquipment ce = (KmChildEquipment)equipments.get(0);
			ce.setStatus(status);
			kmChildEquipmentDAO.attachDirty(ce);
		} else {
			ExceptionUtil.throwDefaultKmException("无效的设备编号");
		}
		
	}
	@Override
	public boolean isIosExist(long equipmentId) throws TKmException {
		boolean flag=false;
		if(equipmentId>0){
			KmEquipment kmquip=kmEquipmentDAO.findById(equipmentId);
			if(kmquip!=null&& kmquip.getStatus().equals("1")){
				flag=true;
			}
		}
		return flag;
		
	}
	public KmEquipmentDAO getKmEquipmentDAO() {
		return kmEquipmentDAO;
	}

	public void setKmEquipmentDAO(KmEquipmentDAO kmEquipmentDAO) {
		this.kmEquipmentDAO = kmEquipmentDAO;
	}

	public Config getConfig() {
		return config;
	}

	public void setConfig(Config config) {
		this.config = config;
	}

	public ShardedJedisPool getShardedJedisPool() {
		return shardedJedisPool;
	}

	public void setShardedJedisPool(ShardedJedisPool shardedJedisPool) {
		this.shardedJedisPool = shardedJedisPool;
	}

	public KmChildEquipmentDAO getKmChildEquipmentDAO() {
		return kmChildEquipmentDAO;
	}

	public void setKmChildEquipmentDAO(KmChildEquipmentDAO kmChildEquipmentDAO) {
		this.kmChildEquipmentDAO = kmChildEquipmentDAO;
	}

	public KmEquipmentAppDAO getKmEquipmentAppDAO() {
		return kmEquipmentAppDAO;
	}

	public void setKmEquipmentAppDAO(KmEquipmentAppDAO kmEquipmentAppDAO) {
		this.kmEquipmentAppDAO = kmEquipmentAppDAO;
	}

	public IAppUsageService getAppUsageService() {
		return appUsageService;
	}

	public void setAppUsageService(IAppUsageService appUsageService) {
		this.appUsageService = appUsageService;
	}

	public IParentUserService getParentUserService() {
		return parentUserService;
	}

	public void setParentUserService(IParentUserService parentUserService) {
		this.parentUserService = parentUserService;
	}

	public InternalServiceUtil getInternalServiceUtil() {
		return internalServiceUtil;
	}

	public void setInternalServiceUtil(InternalServiceUtil internalServiceUtil) {
		this.internalServiceUtil = internalServiceUtil;
	}

	public IChildUserService getChildUserService() {
		return childUserService;
	}

	public void setChildUserService(IChildUserService childUserService) {
		this.childUserService = childUserService;
	}
	public KmAppControlRuleDAO getKmAppControlRuleDAO() {
		return kmAppControlRuleDAO;
	}

	public void setKmAppControlRuleDAO(KmAppControlRuleDAO kmAppControlRuleDAO) {
		this.kmAppControlRuleDAO = kmAppControlRuleDAO;
	}

	public KmGuardianDao getKmGuardianDao() {
		return kmGuardianDao;
	}

	public void setKmGuardianDao(KmGuardianDao kmGuardianDao) {
		this.kmGuardianDao = kmGuardianDao;
	}

	
}
