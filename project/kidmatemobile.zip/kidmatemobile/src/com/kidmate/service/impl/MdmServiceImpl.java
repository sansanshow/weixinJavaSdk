package com.kidmate.service.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Serializable;
import java.sql.Time;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

import com.kidmate.kmservice.TKmAppInfo;
import com.kidmate.kmservice.TKmAppInfoUpload;
import com.kidmate.kmservice.TKmControlRuleInfo;
import com.kidmate.kmservice.TKmException;
import com.kidmate.model.KmAppControlRule;
import com.kidmate.model.KmAppControlRuleDAO;

import com.kidmate.model.KmAppInfoDAO;
import com.kidmate.model.KmChildEquipment;
import com.kidmate.model.KmChildEquipmentDAO;
import com.kidmate.model.KmEquipment;
import com.kidmate.model.KmEquipmentAppDAO;
import com.kidmate.model.KmEquipmentDAO;

import com.kidmate.service.IAppInfoService;
import com.kidmate.service.IMdmService;
import com.kidmate.tools.ConfigUtils;
import com.kidmate.tools.Constants;
import com.kidmate.tools.ExceptionUtil;
import com.kidmate.tools.FileUtil;
import com.kidmate.tools.MdmUtils;
import com.kidmate.tools.PushUtils;
import com.kidmate.tools.SerializeUtil;


@RequestMapping("/mdm")
public class MdmServiceImpl implements  IMdmService{
	/**
	 * 
	 */
	private ShardedJedisPool shardedJedisPool;
    private KmAppInfoDAO kmAppInfoDAO;
	private IAppInfoService appInfoService;
    private KmChildEquipmentDAO kmChildEquipmentDAO;
    private KmEquipmentDAO kmEquipmentDAO;
    private KmAppControlRuleDAO kmAppControlRuleDAO;
    private KmEquipmentAppDAO kmEquipmentAppDAO;
	private static Logger logger = Logger.getLogger(MdmServiceImpl.class);

	/**
	 * 
	 * 下载设备控制描述文件功能
	 * 
	 * @throws Exception
	 */

	@RequestMapping("/down/{deviceId}")
	public void downConfig(@PathVariable("deviceId") String deviceId,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		logger.info("-------------------Download MobileConfig File Start---------------");
		 KmEquipment mdm =kmEquipmentDAO.findById(Long.parseLong(deviceId));
		if (null == mdm) {
			// 孩子的设备没有
			ExceptionUtil.throwDefaultKmException("添加设备失败！");
		} else {
			/** 生成签名的MobileConfig配置文件的三个证书文件 **/
			logger.info("----------------------生成证书文件等的路径 start---------------------");
			String configPath = request.getSession().getServletContext().getRealPath("/mdmtool");
			String tempPath = request.getSession().getServletContext().getRealPath("/mdmtool")+ "/down";
			String crtPath = configPath + ConfigUtils.getConfig("APNS_CRT");
			String keyPath = configPath + ConfigUtils.getConfig("APNS_KEY");
			String pemPath = configPath + ConfigUtils.getConfig("APNS_PEM");
			logger.info("----------------------生成证书文件等的路径 end---------------------");
			/** 创建未签名的文件和已签名的MobileConfig文件 **/
			System.out.println("----------------------生成未签名的mobileconfig文件 start---------------------");
			String oldPath = tempPath + "/" + deviceId + ".mobileconfig";
			String newPath = tempPath + "/" + deviceId + "Signed.mobileconfig";
			String content = MdmUtils.readConfig(configPath).replace(
					"#deviceId#", deviceId);
			boolean createSuccess = MdmUtils.createMobileConfigFile(oldPath,content);
			System.out.println("----------------------生成未签名的mobileconfig文件 end---------------------");
			/** 签名和认证过程 **/
			if (createSuccess) {
				System.out.println("----------------------签名mobileconfig文件 start---------------------");
				// -sign：用提供的证书和私钥值来签名邮件信息值 输入 输出 签名或放弃一个签名数据 私钥存放地址
				// 添加filename中所有的证书信息值 输出格式 加密
				String os = System.getProperty("os.name");
				if (os != null && os.startsWith("Windows")) {
					String oldCmd = "cmd /c openssl smime -sign -in \"{0}\" -out \"{1}\" -signer \"{2}\" -inkey \"{3}\" -certfile \"{4}\" -outform der -nodetach ";
					String newCmd = MessageFormat.format(oldCmd, oldPath, newPath,
							crtPath, keyPath, pemPath);
					logger.info("---OpenSSL：\n" + newCmd);
					try {
						Runtime.getRuntime().exec("cmd /c " + newCmd);
						Process p = Runtime.getRuntime().exec(newCmd);
		                BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
		                String line = null;
		                while((line=input.readLine()) != null) {
		                    System.out.println(line);
		                }
		                int exitVal = p.waitFor();
		                logger.info("Exited with error code " + exitVal);
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					try {
						String[] cmds = { "/opt/shell/openssl.sh",
								oldPath,
								newPath,
								crtPath,
								keyPath,
								pemPath};
						Process p = Runtime.getRuntime().exec(cmds);
		                BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
		                String line = null;
		                while((line=input.readLine()) != null) {
		                    System.out.println(line);
		                }
		                int exitVal = p.waitFor();
		                logger.info("Exited with error code " + exitVal);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
             logger.info("----------------------签名mobileconfig文件 end---------------------");
			}
			System.out.println("----------------------下载签名后的mobileconfig文件 start---------------------");
			response.setHeader("content-type", "application/xml;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			String configTitle = "MDMApp_" + deviceId;
			response.setHeader("Content-Disposition", "attachment; filename="
					+ configTitle + ".mobileconfig");
			/** 获取配置文件动态组装参数 **/
			System.out.println("----------------------下载签名后的mobileconfig文件 end---------------------");
			try {
				Thread.sleep(5000);// 括号里面的5000代表5000毫秒，也就是5秒，可以该成你需要的时间
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			/** 写入文件 **/
			java.io.File f = new java.io.File(newPath);
			while (true) {
				if (f.exists() && f.length() > 0) {
					java.io.FileInputStream fis = new java.io.FileInputStream(
							newPath);
					java.io.OutputStream os = response.getOutputStream();
					byte[] b = new byte[1024];
					int i = 0;
					while ((i = fis.read(b)) > 0) {
						os.write(b, 0, i);
					}
					fis.close();
					os.flush();
					os.close();
					break;
				} else {
					continue;
				}
			}
		}
	}


	/**
	 * 设备认证和注册功能
	 * 
	 * @throws Exception
	 */
	@RequestMapping(value = "/checkin/{deviceId}", method = RequestMethod.PUT)
	public void checkIn(@PathVariable("deviceId") String deviceId,HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		/** 获取当期设备的编号和设备信息 **/
		KmEquipment mdm = kmEquipmentDAO.findById(Long.parseLong(deviceId));
		String info = MdmUtils.inputStream2String(request.getInputStream());
		System.out.println("----------------------checkin="+info);
		/** Device认证方法调用、Device回传Token方法调用 **/
		if (info.toString().contains(MdmUtils.Authenticate)) {
			logger.info("Device->Server Authenticate start:\n"+ info.toString());
			/** 保存返回的Token、PushMagic数据 **/
			Map<String, String> plistMap = MdmUtils.parseAuthenticate(info.toString());
            /** 返回一个空的pList格式的文件 **/
			String blankPList = MdmUtils.getBlankPList();
			//System.out.println("Server->Device:\n" + blankPList);
			response.setHeader("content-type", "application/xml;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			String configTitle = "MDMApp_EraseDevice";
			response.setHeader("Content-Disposition", "attachment; filename="+ configTitle + ".plist");
			PrintWriter sos = response.getWriter();
			System.out.println("-------------------Authenticate end---------------");
			sos.write(blankPList);
			sos.flush();
			sos.close();
		} else if (info.toString().contains(MdmUtils.TokenUpdate)) {
			System.out.println("-------------------TokenUpdate start---------------");
			System.out.println("Device->Server TokenUpdate:\n"+ info.toString());
			/** 保存返回的数据 **/
			Map<String, String> plistMap = MdmUtils.parseTokenUpdate(info
					.toString());
			String UnlockToken = MdmUtils.parseUnlockToken(info.toString());
			String UDID = plistMap.get(MdmUtils.UDID);
			String Topic = plistMap.get(MdmUtils.Topic);
			String OriToken = plistMap.get(MdmUtils.Token);
			String PushMagic = plistMap.get(MdmUtils.PushMagic);
			if (mdm == null) {
				mdm = new KmEquipment();
			}
			mdm.setId(Long.parseLong(deviceId));
			mdm.setUdid(UDID);
			mdm.setTopic(Topic);
			mdm.setEquipmenttype("1");
			mdm.setStatus("1");
			//kmEquipmentDAO.attachDirty(mdm);
			mdm.setUnlockToken(UnlockToken);
			/** 组装新的Token数据 **/
			String Token = MdmUtils.parseToken(OriToken);
			mdm.setToken(Token);
			mdm.setPushMagic(PushMagic);
			kmEquipmentDAO.attachDirty(mdm);
            /** 空返回 **/
		    System.out.println("-------------------TokenUpdate end---------------");
			response.setContentType("text/plain;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			response.setHeader("Cache-Control", "no-cache");
			PrintWriter out;
			try {
				out = response.getWriter();
				out.print("");
				logger.info("-----ios儿童端证书安装完了");
				//绑定app，如果设备的app的已经在数据库存在了则不绑定
				List<TKmAppInfo>  tkms=appInfoService.getAllAppInfo(Long.parseLong(deviceId));
				if(tkms==null || tkms.size()<1){
					logger.info("----------------------添加app和绑定新的app");
					this.deviceInstalledApplicationList(deviceId, request, response);
					logger.info("-----------------------app绑定成功");
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else if (info.toString().contains(MdmUtils.CheckOut)) {
			//System.out.println("Device->Server CheckOut:\n" + info.toString());
			
			System.out.println("-------------------CheckOut start---------------");
			if (mdm != null) {
                List<KmChildEquipment> checkOutkm=kmChildEquipmentDAO.findByEquipmentid((long)Long.parseLong(deviceId));
               for(KmChildEquipment checkOut:checkOutkm)
				if(mdm!=null&&checkOut.getEquipmentid()==mdm.getId()&&mdm.getEquipmenttype().equals("1")){
					logger.info("--------------ios删除了配置文件");
					checkOut.setStatus("0");
					kmChildEquipmentDAO.attachDirty(checkOut);
					
				}
				mdm.setStatus("0");
				mdm.setLastupdate(new Date());
				mdm.setTopic(null);
				kmEquipmentDAO.attachDirty(mdm);
			}

			System.out.println("Server->Device:\n Don't need to return");
			System.out.println("-------------------CheckOut end---------------");
		}

	      
	}

	/**
	 * 操作状态回执
	 * 
	 * @throws Exception
	 * 
	 */
	@RequestMapping(value = "/server/{deviceId}", method = RequestMethod.PUT)
	public void serverUrl(@PathVariable("deviceId") String deviceId,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		/** 获取当期设备的编号 **/
         KmEquipment mdm = kmEquipmentDAO.findById(Long.parseLong(deviceId));
         String info = MdmUtils.inputStream2String(request.getInputStream());
		//System.out.println("Device->Server:\n"+info.toString());
		KmAppControlRule kmappcon = null;
		/** 设备空闲状态,可以发送相关命令 **/
		if (info.contains(MdmUtils.Idle)) {
			/** 执行命令 **/
			KmAppControlRule command = null;
			kmappcon = new KmAppControlRule();
            kmappcon.setEquipmentid(Long.parseLong(deviceId));
            kmappcon.setAppid(2L);
			kmappcon.setStatus("0");
			kmappcon.setParentid(mdm.getParentid());
			List<KmAppControlRule> commands = kmAppControlRuleDAO.findByExample(kmappcon);
			if (commands.size() > 0) {
				command = commands.get(0);
			}
           if (command!= null) {
               if(command.getControlname().equals(MdmUtils.InstallProfile)){
					String lockfile=ConfigUtils.getConfig("APNS_LOCK");
					String lockPath = request.getSession().getServletContext()
							.getRealPath("/mdmtool")
							+ "/" + lockfile;
					String file=FileUtil.readString3(lockPath);
					String commandString = MdmUtils.getInstalProfile(MdmUtils.InstallProfile ,file,command.getId().toString());
					command.setStatus("1");
					kmAppControlRuleDAO.attachDirty(command);
				   List<KmChildEquipment>  equipments = kmChildEquipmentDAO.findByEquipmentid(Long.parseLong(deviceId));
					for(KmChildEquipment es:equipments){
						System.out.print("Unlock------end");
						if(mdm.getEquipmenttype().equals("1")&&!es.getStatus().equals("0")){
							es.setStatus("2");
							kmChildEquipmentDAO.attachDirty(es);
						}	
					}
					System.out.println("Server->Device Security:\n" + commandString);
					response.setHeader("content-type","application/xml;charset=UTF-8");
					response.setCharacterEncoding("UTF-8");
					String configTitle = "info";
					response.setHeader("Content-Disposition","attachment; filename=" + configTitle + ".plist");
					PrintWriter sos = response.getWriter();
					System.out.println("-------------------lock End---------------");
					sos.write(commandString);
					sos.flush();
					sos.close();
				}else if(command.getControlname().equals(MdmUtils.UnInstallProfile)){
					String unLockfile=ConfigUtils.getConfig("APNS_UNLOCK");
					String unLockPath = request.getSession().getServletContext()
							.getRealPath("/mdmtool")
							+ "/" +unLockfile;
					String file=FileUtil.readString3(unLockPath);
					String commandString = MdmUtils.getInstalProfile(MdmUtils.InstallProfile ,file,command.getId().toString());
					command.setStatus("1");
					kmAppControlRuleDAO.attachDirty(command);
					List<KmChildEquipment>  equipments = kmChildEquipmentDAO.findByEquipmentid(Long.parseLong(deviceId));
					for(KmChildEquipment es:equipments){
						System.out.print("Unlock------end");
						if(mdm.getEquipmenttype().equals("1")&&es.getStatus().equals("2")){
							es.setStatus("1");
							kmChildEquipmentDAO.attachDirty(es);
						}	
					}
					System.out.println("Server->Device Security:\n" + commandString);
					response.setHeader("content-type","application/xml;charset=UTF-8");
					response.setCharacterEncoding("UTF-8");
					String configTitle = "info";
					response.setHeader("Content-Disposition","attachment; filename=" + configTitle + ".plist");
					PrintWriter sos = response.getWriter();
					System.out.println("-------------------unlock End---------------");
					sos.write(commandString);
					sos.flush();
					sos.close();

	        }else if (command.getControlname().equals(MdmUtils.Apps)) {
					System.out.println("-------------------InstalledApplicationList Start---------------");
					/** 发送获取设备app信息命令 **/
					command.setStatus("1");
					kmAppControlRuleDAO.attachDirty(command);
					String commandString = MdmUtils.getCommandPList(
							MdmUtils.Apps, command.getId().toString());
					System.out.println("Server->Device InstalledApplicationList:\n"
									+ commandString);
					command.setStatus("1");
					kmAppControlRuleDAO.attachDirty(command);
					response.setHeader("content-type",
							"application/xml;charset=UTF-8");
					response.setCharacterEncoding("UTF-8");
					String configTitle = "MDMApp_InstalledApplicationList";
					response.setHeader("Content-Disposition",
							"attachment; filename=" + configTitle + ".plist");
					PrintWriter sos = response.getWriter();
					sos.write(commandString);
					sos.flush();
					sos.close();
//			} else if (command.getControlname().equals(MdmUtils.Info)) {
//					System.out.println("-------------------DeviceInformation Start---------------");
//					/** 发送获取设备信息命令 **/
//					String commandString = MdmUtils.getCommandInfoPList(
//							MdmUtils.Info, command.getId().toString());
//					System.out.println("Server->Device DeviceInformation:\n"
//							+ commandString);
//					command.setStatus("1");
//					kmAppControlRuleDAO.attachDirty(command);
//					response.setHeader("content-type",
//							"application/xml;charset=UTF-8");
//					response.setCharacterEncoding("UTF-8");
//					String configTitle = "MDMApp_DeviceInformation";
//					response.setHeader("Content-Disposition",
//							"attachment; filename=" + configTitle + ".plist");
//					PrintWriter sos = response.getWriter();
//					System.out
//							.println("-------------------DeviceInformation End---------------");
//					sos.write(commandString);
//					sos.flush();
//					sos.close();
//			} else if (command.getControlname().equals(MdmUtils.Lock)) {
//					 System.out.println("-------------------DeviceLock Start---------------");
//					 /** 发送锁屏命令 **/
//					 String commandString = MdmUtils.getCommandPList(
//					 MdmUtils.Lock, command.getId().toString());
//					 command.setStatus("1");
//					 kmAppControlRuleDAO.attachDirty(command);
//					 System.out.println("Server->Device Lock:\n" +
//					 commandString);
//					 response.setHeader("content-type","application/xml;charset=UTF-8");
//					 response.setCharacterEncoding("UTF-8");
//					 String configTitle = "MDMApp_DeviceLock";
//					 response.setHeader("Content-Disposition","attachment; filename="
//					 + configTitle + ".plist");
//					 PrintWriter sos = response.getWriter();
//					 System.out.println("-------------------DeviceLock End---------------");
//					 sos.write(commandString);
//					 sos.flush();
//					 sos.close();
//				} else if (command.getControlname().equals(MdmUtils.Clear)) {
//					System.out.println("-------------------ClearPasscode Start---------------");
//					 /**发送清除设备密码命令**/
//					 String commandString =
//					 MdmUtils.getClearPassCodePList(MdmUtils.Clear, command.getId().toString(),mdm);
//					 System.out.println("Server->Device ClearPasscode:\n"+commandString);
//					 command.setStatus("1");
//					 kmAppControlRuleDAO.attachDirty(command);
//					 response.setHeader("content-type",
//					 "application/xml;charset=UTF-8");
//					 response.setCharacterEncoding("UTF-8");
//					 String configTitle = "MDMApp_ClearPasscode";
//					 response.setHeader("Content-Disposition",
//					 "attachment; filename=" + configTitle + ".plist");
//					 PrintWriter sos = response.getWriter();
//					 System.out.println("-------------------ClearPasscode End---------------");
//					 sos.write(commandString);
//					 sos.flush();
//					 sos.close();
				} else if (command.getControlname().equals(MdmUtils.Online)) {
					/** 查询设备状态，如果又返回，则修改状态就行了：1 表示设备在线 **/
					command.setStatus("1");
					kmAppControlRuleDAO.attachDirty(command);
				} else if (command.getControlname().equals(MdmUtils.Repay)) {
				    /** 更新设备是否可控状态 **/
					command.setStatus("2");
					kmAppControlRuleDAO.attachDirty(command);
				}
			}
		} else if (info.contains(MdmUtils.Acknowledged)) {
			if (info.contains(MdmUtils.QueryResponses)) {
				System.out.println("-------------------DeviceInformation Start---------------");
				System.out.println("Device->Server DeviceInformation:\n"
						+ info.toString());
				Map<String, String> plistMap = MdmUtils.parseInformation(info);
				System.out.println(plistMap.get("IMEI"));
				String CommandUUID = plistMap.get("CommandUUID");
				// comandUUID从哪里来的，代表的什么？
				System.out.println(CommandUUID);
                KmAppControlRule command = kmAppControlRuleDAO.findById(Long.parseLong(CommandUUID));
                if (command != null) {
                    command.setStatus("2");
					kmAppControlRuleDAO.attachDirty(command);
				}
				System.out.println("-------------------DeviceInformation End InstalledApplicationList ---------------");
			} else if (info.contains(MdmUtils.InstalledApplicationList)) {
				System.out.println("-------------------InstalledApplicationList Start---------------");
				// System.out.println("Device->Server InstalledApplicationList:\n"+info.toString());
				Map<String, String> plistMap = MdmUtils.parseInformation(info);
				String CommandUUID = plistMap.get("CommandUUID");
				/** 保存处理后的APP列表数据 end **/
                KmAppControlRule command = kmAppControlRuleDAO.findById(Long.parseLong(CommandUUID));
                if (command != null && command.getStatus().equals("1")) {
					command.setStatus("2");
					kmAppControlRuleDAO.attachDirty(command);
					//通过线程去启动添加app和绑定设备 
					List<TKmAppInfoUpload> iosApp = MdmUtils.getIosApp(info);// 解析info生成iosapp
					List<String> packageList = new ArrayList<String>();
					for (TKmAppInfoUpload tKmAppInfoUpload : iosApp) {
						packageList.add(tKmAppInfoUpload.getPackagename());
					}
					List<Long> appIDList = new ArrayList<Long>();

					List<TKmAppInfo> tKmAppInfo = appInfoService.addNewAppInfo((long) Long.parseLong(deviceId),iosApp);

					for (TKmAppInfo tk : tKmAppInfo) {
						appIDList.add(tk.getId());
					}
                   this.appInfoService.bindToEquipment((long) Long.parseLong(deviceId), appIDList);

				}

				System.out.println("-----------------has --InstalledApplicationList End---------------");
			} else {
				System.out.println("-------------------OtherResult Start---------------");
				Map<String, String> plistMap = MdmUtils.parseCommand(info);
				String CommandUUID = plistMap.get("CommandUUID");

				KmAppControlRule command = kmAppControlRuleDAO.findById((long) Long.parseLong(CommandUUID));

				if (command != null ) {
					command.setStatus("2");
					kmAppControlRuleDAO.attachDirty(command);
					if(command.getControlname().equals(MdmUtils.InstallProfile)){
						System.out.println("修改");
//						List<KmChildEquipment>  equipments = kmChildEquipmentDAO.findByEquipmentid(Long.parseLong(deviceId));
//						for(KmChildEquipment es:equipments){
//							System.out.print("lock------end");
//							if(mdm.getEquipmenttype().equals("1")&&!es.getStatus().equals("0")){
//								es.setStatus("2");
//								kmChildEquipmentDAO.attachDirty(es);
//							}	
//						}
					}else if(command.getControlname().equals(MdmUtils.UnInstallProfile)){
						//ios解锁的时候，修改状态，暂不做操作
//						List<KmChildEquipment>  equipments = kmChildEquipmentDAO.findByEquipmentid(Long.parseLong(deviceId));
//						for(KmChildEquipment es:equipments){
//							System.out.print("Unlock------end");
//							if(mdm.getEquipmenttype().equals("1")&&!es.getStatus().equals("0")){
//								es.setStatus("1");
//								kmChildEquipmentDAO.attachDirty(es);
//							}	
//						}
					}
				}
				
				System.out.println("-------------------OtherResult End---------------");
			}
		} else if (info.contains(MdmUtils.CommandFormatError)) {
			System.out.println("-------------------CommandFormatError Start---------------");
			Map<String, String> plistMap = MdmUtils.parseCommand(info);
			String CommandUUID = plistMap.get("CommandUUID");
            KmAppControlRule command = kmAppControlRuleDAO.findById((long) Long.parseLong(CommandUUID));

			if (command != null) {
                command.setStatus("3");
				kmAppControlRuleDAO.attachDirty(command);
			}
			System.out.println("-------------------CommandFormatError End---------------");
		} else if (info.contains(MdmUtils.Error)) {
			System.out.println("-------------------Error Start---------------");
			Map<String, String> plistMap = MdmUtils.parseCommand(info);
			String CommandUUID = plistMap.get("CommandUUID");
			KmAppControlRule command = kmAppControlRuleDAO.findById((long) Long.parseLong(CommandUUID));

			if (command != null) {
               command.setStatus("3");
				kmAppControlRuleDAO.attachDirty(command);
			}
			System.out.println("-------------------Error End---------------");
		} else if (info.contains(MdmUtils.NotNow)) {
			System.out.println("-------------------NotNow Start---------------");
			Map<String, String> plistMap = MdmUtils.parseCommand(info);
			String CommandUUID = plistMap.get("CommandUUID");
             KmAppControlRule command = kmAppControlRuleDAO.findById((long) Long.parseLong(CommandUUID));
            
			if (command != null) {
				command.setStatus("2");  
				kmAppControlRuleDAO.attachDirty(command);
			}

			System.out.println("-------------------NotNow End---------------");
		}
	}



	/**
	 * 获取设备信息
	 * 
	 * @throws Exception
	 */

	public  void deviceInformation( String deviceId,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		System.out.println("-------------------Information Start---------------");
		//System.out.println("------------------"+contronName);
		Map<String, String> map = new HashMap<String, String>();
		KmEquipment mdm = kmEquipmentDAO.findById((long) Long.parseLong(deviceId));
		KmChildEquipment kmChiEuipmen = null;
		List<KmChildEquipment> kmChiEus = kmChildEquipmentDAO.findByEquipmentid((long) Long.parseLong(deviceId));
		for(KmChildEquipment ce:kmChiEus){
			if(!ce.getStatus().equals("0")&&ce.getEquipmentid()==(long) Long.parseLong(deviceId)){
				
			}
		}
		if (null == mdm || kmChiEuipmen == null) {
			map.put("state", "0");
			map.put("msg", "Incorrect code!");
		} else {
            String pemFile = ConfigUtils.getConfig("APNS_P12MDM");
			String pemPath = request.getSession().getServletContext()
					.getRealPath("/mdmtool")
					+ "/" + pemFile;
			int pushState = PushUtils.singleMDMPush(pemPath, mdm);
			if (pushState == 1) {
				KmAppControlRule command = new KmAppControlRule();
				command.setControlname(MdmUtils.UnInstallProfile);
				command.setEquipmentid(Long.parseLong(deviceId));
                command.setParentid(mdm.getParentid());
				command.setAppid(2L);//iPhone 控制app的id
				command.setChildid(kmChiEuipmen.getChildid());
				command.setRepeattype(0);
				command.setStarttime(0);
				command.setEndtime(0);
				command.setDuration(0);
				List<KmAppControlRule> commands = kmAppControlRuleDAO.findByExample(command);
				if (commands.size() > 0) {
					command.setCreatetime(new Date());
					commands.get(0).setStatus("0");
					kmAppControlRuleDAO.attachDirty(commands.get(0));
				} else {
					command.setCreatetime(new Date());
					command.setStatus("0");
					kmAppControlRuleDAO.attachDirty(command);
				}
				// command.setCreatetime(new Time(System.currentTimeMillis()));
                map.put("state", "1");
				map.put("msg", "query device information command success!");
			} else {
				map.put("state", "0");
				map.put("msg", "query device information command failure!");
			}
			System.out.println("-------------------Information End---------------");
		}
		
	}


	@Override
	public void updateIosLock(long equipmentId, String MdmCommand)
			throws TKmException {
		// TODO Auto-generated method stub
		
		//System.out.println("------------------"+contronName);
		KmEquipment mdm = kmEquipmentDAO.findById(equipmentId);
		KmChildEquipment kmChiEuipmen = null;
		List<KmChildEquipment> kmChiEus = kmChildEquipmentDAO.findByEquipmentid(equipmentId);
		for(KmChildEquipment ce:kmChiEus){
			if(!ce.getStatus().equals("0")&&ce.getEquipmentid()==equipmentId){
				kmChiEuipmen=ce;
			}
		}
		if (null == mdm || kmChiEuipmen == null ) {
			ExceptionUtil.throwDefaultKmException("儿童端已被卸载，请重新安装");
		} else  if(mdm.getTopic()==null){
			ExceptionUtil.throwDefaultKmException("请儿童端安装证书");
		} else{
			
			String pemFile = ConfigUtils.getConfig("APNS_P12MDM");
			HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest(); 
			String pemPath = request.getSession().getServletContext()
					.getRealPath("/mdmtool")
					+ "/" + pemFile;
			int pushState = PushUtils.singleMDMPush(pemPath, mdm);
			if (pushState == 1) {
				KmAppControlRule command = new KmAppControlRule();
				System.out.println("--------MdmCommand"+MdmCommand);
				command.setControlname(MdmCommand);
				command.setEquipmentid(equipmentId);
				command.setParentid(mdm.getParentid());
				command.setAppid(2L);// iPhone 锁屏是传app的id
				command.setChildid(kmChiEuipmen.getChildid());
				command.setDuration(0);
				command.setRepeattype(0);
				command.setStarttime(0);
				command.setEndtime(0);
				List<KmAppControlRule> commands = kmAppControlRuleDAO.findByExample(command);
				if (commands.size() > 0) {
					logger.info("---------+"+commands.size());
					command.setCreatetime(new Date());
					commands.get(0).setStatus("0");
					kmAppControlRuleDAO.attachDirty(commands.get(0));
				} else {
					command.setCreatetime(new Date());
					command.setStatus("0");
					kmAppControlRuleDAO.attachDirty(command);
				}

			} else if(MdmCommand.equals(MdmUtils.UnInstallProfile)) {
				ExceptionUtil.throwDefaultKmException("发送解锁消息失败");
			}else{
				ExceptionUtil.throwDefaultKmException("发送消息失败");
			}

		}
            
	}
     

	/**
	 * 获取设备已经安装的app信息,
	 * 
	 * @throws Exception
	 */
	
	public boolean deviceInstalledApplicationList(String deviceId,HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		System.out.println("-------------------InstalledApplicationList Start---------------");
		boolean flag=true;
       KmEquipment mdm = kmEquipmentDAO.findById(Long.parseLong(deviceId));
		KmChildEquipment kmChiEuipmen = null;
		List<KmChildEquipment> kmChiEus = kmChildEquipmentDAO.findByEquipmentid(Long.parseLong(deviceId));
        for(KmChildEquipment ce:kmChiEus){
               if(!ce.getStatus().equals("0")){
				kmChiEuipmen=ce;
			   }
		}

		if (null ==mdm ||kmChiEuipmen == null) {
             ExceptionUtil.throwDefaultKmException("ios儿童端绑定失败");
		} else {
			/** 获取设备的app**/
			String pemFile = ConfigUtils.getConfig("APNS_P12MDM");
			String pemPath = request.getSession().getServletContext().getRealPath("/mdmtool")+ "/" + pemFile;
			int pushState = PushUtils.singleMDMPush(pemPath, mdm);
			if (pushState == 1) {
				KmAppControlRule command = new KmAppControlRule();
				command.setControlname(MdmUtils.Apps);
				command.setEquipmentid(Long.parseLong(deviceId));
                command.setParentid(mdm.getParentid());
				command.setAppid(2L);
				command.setChildid(kmChiEuipmen.getChildid());
				command.setCreatetime(new Date());
				command.setRepeattype(0);
				command.setStarttime(0);
				command.setEndtime(0);
				command.setDuration(0);
				List<KmAppControlRule> commands = kmAppControlRuleDAO.findByExample(command);
				if (commands.size() > 0) {
					commands.get(0).setStatus("0");
					kmAppControlRuleDAO.attachDirty(commands.get(0));
				} else {
					command.setStatus("0");
					kmAppControlRuleDAO.attachDirty(command);
				}
				flag=true;
			} else {
				flag=false;
			}
			logger.info("-------------------InstalledApplicationList End---------------");
		}
	     return flag;
	}
    
	
	public ShardedJedisPool getShardedJedisPool() {
		return shardedJedisPool;
	}

	public void setShardedJedisPool(ShardedJedisPool shardedJedisPool) {
		this.shardedJedisPool = shardedJedisPool;
	}

	public KmChildEquipmentDAO getKmChildEquipmentDAO() {
		return kmChildEquipmentDAO;
	}

	public void setKmChildEquipmentDAO(KmChildEquipmentDAO kmChildEquipmentDAO) {
		this.kmChildEquipmentDAO = kmChildEquipmentDAO;
	}

	
	
	public KmAppControlRuleDAO getKmAppControlRuleDAO() {
		return kmAppControlRuleDAO;
	}

	public void setKmAppControlRuleDAO(KmAppControlRuleDAO kmAppControlRuleDAO) {
		this.kmAppControlRuleDAO = kmAppControlRuleDAO;
	}

	public KmEquipmentDAO getKmEquipmentDAO() {
		return kmEquipmentDAO;
	}

	public void setKmEquipmentDAO(KmEquipmentDAO kmEquipmentDAO) {
		this.kmEquipmentDAO = kmEquipmentDAO;
	}

	public IAppInfoService getAppInfoService() {
		return appInfoService;
	}

	public void setAppInfoService(IAppInfoService appInfoService) {
		this.appInfoService = appInfoService;
	}

	public KmAppInfoDAO getKmAppInfoDAO() {
		return kmAppInfoDAO;
	}

	public void setKmAppInfoDAO(KmAppInfoDAO kmAppInfoDAO) {
		this.kmAppInfoDAO = kmAppInfoDAO;
	}

  

}
