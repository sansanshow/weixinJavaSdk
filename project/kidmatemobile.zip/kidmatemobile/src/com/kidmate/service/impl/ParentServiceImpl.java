package com.kidmate.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.thrift.TException;

import redis.clients.jedis.ShardedJedisPool;

import com.kidmate.comman.DemoData;
import com.kidmate.kmservice.InternalService;
import com.kidmate.kmservice.TKmAppInfo;
import com.kidmate.kmservice.TKmAppUsage;
import com.kidmate.kmservice.TKmAppUsageStatistics;
import com.kidmate.kmservice.TKmChild;
import com.kidmate.kmservice.TKmControlRuleInfo;
import com.kidmate.kmservice.TKmCredit;
import com.kidmate.kmservice.TKmEquipment;
import com.kidmate.kmservice.TKmException;
import com.kidmate.kmservice.TKmPosition;
import com.kidmate.kmservice.TKmProduct;
import com.kidmate.kmservice.TKmProductClass;
import com.kidmate.kmservice.TKmSnapshot;
import com.kidmate.kmservice.TKmTimeStatistics;
import com.kidmate.kmservice.TKmUser;
import com.kidmate.kmservice.ParentService;
import com.kidmate.model.KmChildEquipment;
import com.kidmate.model.KmChildEquipmentDAO;
import com.kidmate.model.KmEquipment;
import com.kidmate.model.KmEquipmentDAO;
import com.kidmate.model.KmRss;
import com.kidmate.model.KmRssChan;
import com.kidmate.model.KmRssChannel;
import com.kidmate.service.IAppInfoService;
import com.kidmate.service.IAppUsageService;
import com.kidmate.service.IChildUserService;
import com.kidmate.service.IControlService;
import com.kidmate.service.ICreditService;
import com.kidmate.service.IEquipmentService;
import com.kidmate.service.IKmRssService;
import com.kidmate.service.IMdmService;
import com.kidmate.service.IParentUserService;
import com.kidmate.service.IPositionService;
import com.kidmate.servlet.BaseTServlet;
import com.kidmate.tools.Config;
import com.kidmate.tools.ExceptionUtil;
import com.kidmate.tools.MdmUtils;
import com.kidmate.tools.SecurityUtils;

public class ParentServiceImpl implements ParentService.Iface,IKmRssService{
	
	private IParentUserService parentUserService;
	private IChildUserService childUserService;
	private KmChildEquipmentDAO kmChildEquipmentDAO;
	private IMdmService MdmService;
	private ShardedJedisPool shardedJedisPool;
	private IAppInfoService appInfoService;
	private IEquipmentService equipmentService;
	private IControlService controlService;
	private IAppUsageService appUsageService;
	private IPositionService positionService;
	private KmEquipmentDAO kmEquipmentDAO;
	private Config config;
	private AppStoreRechargeService appStoreRechargeService;
	private ICreditService   creditServiceImpl;
    private static Logger logger = Logger.getLogger(ParentServiceImpl.class);
	@Override
	public TKmUser login(String authToken, String checksum, long timestamp,
			int source, String version) throws TKmException, TException {
		// TODO Auto-generated method stub
		if (Math.abs(System.currentTimeMillis()-timestamp)>120000) {
			ExceptionUtil.throwDefaultKmException("时间过期，请刷新");
		}
		if (!checksum.equals(SecurityUtils.md5ByHex(authToken + version + (timestamp<<3)))) {
			ExceptionUtil.throwDefaultKmException("校验有误");
		}
		return parentUserService.login(authToken, source, BaseTServlet.clientip.get(),null);
	}

	@Override
	public String loginWithPw(String mobile, String password, long timestamp,
			String checksum) throws TKmException, TException {
		// TODO Auto-generated method stub
		System.out.println("timestamp==="+timestamp);
		System.out.println("timesamp"+SecurityUtils.md5ByHex(mobile + password + (timestamp<<3)));
		if (!checksum.equals(SecurityUtils.md5ByHex(mobile + password + (timestamp<<3)))) {
			ExceptionUtil.throwDefaultKmException("校验有误");
		}
		return parentUserService.loginPw(mobile, password);
	}
	
	@Override
	public TKmUser loginWx(String accessToken, String opendId, String unionid,
			String checksum, long timestamp, int source, String version)
			throws TKmException, TException {
		if (Math.abs(System.currentTimeMillis()-timestamp)>120000) {
			ExceptionUtil.throwDefaultKmException("时间过期，请刷新");
		}
		if (!checksum.equals(SecurityUtils.md5ByHex(accessToken + version + (timestamp<<3)))) {
			ExceptionUtil.throwDefaultKmException("校验有误");
		}
		return parentUserService.loginWx(accessToken, opendId, unionid,source, BaseTServlet.clientip.get());
	}
	@Override
	public TKmUser loginV2(String authToken, String checksum, long timestamp,
			int source, String version, String invitecode) throws TKmException,
			TException {
		if (Math.abs(System.currentTimeMillis()-timestamp)>120000) {
			ExceptionUtil.throwDefaultKmException("时间过期，请刷新");
		}
		if (!checksum.equals(SecurityUtils.md5ByHex(authToken + version + (timestamp<<3)))) {
			ExceptionUtil.throwDefaultKmException("校验有误");
		}
		return parentUserService.login(authToken, source, BaseTServlet.clientip.get(),invitecode);
	}
	
	@Override
	public int appStoreRecharge(TKmUser user, String receipt)
			throws TKmException, TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		return appStoreRechargeService.appStoreRecharge(user.getUserid(), receipt, false);
	}

	@Override
	public long getVipTime(TKmUser user) throws TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		return parentUserService.getVipTime(user.getUserid());
	}
	
	@Override
	public Map<String, String> getSysConfig() throws TException {
		// TODO Auto-generated method stub
		Map<String, String> sysConfig = new HashMap<String, String>();
		sysConfig.put("audit", config.getParentAudit());
		sysConfig.put("version", config.getParentVersion());
		return sysConfig;
	}
	
	@Override
	public List<TKmAppInfo> getAppInfoByIDs(TKmUser user, List<Long> appids)
			throws TKmException, TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		return appInfoService.getAppInfoByIds(appids);
	}
	
	@Override
	public List<Long> getChildAllAPP(TKmUser user, long childid)
			throws TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		return childUserService.getAppIds(childid);
	}

	@Override
	public List<Long> getEquipmentAllAPP(TKmUser user, long equipmentId)
			throws TException {
		// TODO Auto-generated method stub
		if (user.getUserid()==2000) {
			return  DemoData.getEquipmentApp(0);
		}
		parentUserService.verifyUserSign(user, true);
		return equipmentService.getAppIds(equipmentId);
	}
	
	@Override
	public List<Long> getEquipmentUnderControlAPP(TKmUser user, long equipmentId)
			throws TKmException, TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			return  DemoData.getEquipmentApp(1);
		}
		KmEquipment km=kmEquipmentDAO.findById(equipmentId);
		if(km!=null){
			if(km.getEquipmenttype()!=null&&"1".equals(km.getEquipmenttype())){
				ExceptionUtil.throwDefaultKmException("ios暂不支持此功能");
			}
		}
		
		return equipmentService.getAppUderControlIds(equipmentId);
	}

	@Override
	public List<Long> getEquipmentOutOfControlAPP(TKmUser user, long equipmentId)
			throws TKmException, TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			return  DemoData.getEquipmentApp(2);
		}
		KmEquipment km=kmEquipmentDAO.findById(equipmentId);
		return equipmentService.getAppOutofControlIds(equipmentId);
	}
	
	@Override
	public TKmChild saveChild(TKmUser user, TKmChild tKmChild) throws TKmException,
			TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			ExceptionUtil.throwDefaultKmException("演示用户，不能进行此功能操作");
		}
		return childUserService.saveChild(user.getUserid(), tKmChild);
	}

	@Override
	public List<TKmChild> getChildList(TKmUser user) throws TKmException,
			TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			return  DemoData.getChildList();
		}
		return childUserService.getCHild(user.getUserid());
	}

	@Override
	public boolean delChild(TKmUser user, long childid) throws TKmException,
			TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			ExceptionUtil.throwDefaultKmException("演示用户，不能进行此功能操作");
		}
		List<KmChildEquipment> kmChildEquipmentList = kmChildEquipmentDAO.findByChildid(childid);
		for (KmChildEquipment e:kmChildEquipmentList) {
			if (e.getStatus().equals("2")) {
				KmEquipment kmEquip=kmEquipmentDAO.findById(e.getId());
				if(kmEquip!=null&&kmEquip.getEquipmenttype().equals("1")&&!kmEquip.getStatus().equals("0"))
				MdmService.updateIosLock(kmEquip.getId(),MdmUtils.UnInstallProfile);
			}
		}
		return childUserService.delChild(user.getUserid(), childid);
	}

	@Override
	public boolean bindEquipment(TKmUser user, long childid, long equipmentID)
			throws TKmException, TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			ExceptionUtil.throwDefaultKmException("演示用户，不能进行此功能操作");
		}
		return childUserService.bindEquipment(user.getUserid(), childid, equipmentID);
	}

	@Override
	public boolean unBindEquipment(TKmUser user, long childid, long equipmentID)
			throws TKmException, TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			ExceptionUtil.throwDefaultKmException("演示用户，不能进行此功能操作");
		}
		return childUserService.unBindEquipment(user.getUserid(), childid, equipmentID);
	}

	@Override
	public boolean delEquipment(TKmUser user, long equipmentID) throws TKmException,
			TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			ExceptionUtil.throwDefaultKmException("演示用户，不能进行此功能操作");
		}
		long childid = equipmentService.getChildID(equipmentID, null);
		KmEquipment kmEuqip = kmEquipmentDAO.findById(equipmentID);
		List<KmChildEquipment> kmch=kmChildEquipmentDAO.findByEquipmentid(equipmentID);
		for (KmChildEquipment e : kmch) {
			if (e.getStatus().equals("2")) {
				if (kmEuqip != null) {
					if (kmEuqip.getEquipmenttype().equals("1")&& !kmEuqip.getStatus().equals("0"))
						MdmService.updateIosLock(equipmentID,MdmUtils.UnInstallProfile);
				}
			}
		}
		if(kmEuqip.getParentid()==user.getUserid()){
			if (childid!=0)
				childUserService.unBindEquipment(user.getUserid(), childid, equipmentID);
		}
		return equipmentService.delEquipment(user.getUserid(),childid,equipmentID);
	}

	@Override
	public List<TKmEquipment> getAllEquipment(TKmUser user)
			throws TKmException, TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			return  DemoData.getAllEquipment();
		}
		return equipmentService.getParentEquipmentList(user.getUserid());
	}
	@Override
	public List<TKmControlRuleInfo> getAllControlRuleInfo(TKmUser user,
			long childid, long equipmentID) throws TKmException, TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			return  DemoData.getAllControlRuleInfo();
		}
		if (childid!=0 && equipmentID==0) {
			return controlService.getChildControlRuleList(childid);
		} 
		if (equipmentID!=0) {
			return controlService.getEquipmentControlRuleList(equipmentID);
		}  
		return null;
	}

	@Override
	public TKmControlRuleInfo saveControlRuleInfo(TKmUser user,
			TKmControlRuleInfo controlrule) throws TKmException, TException {
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			TKmControlRuleInfo t=new TKmControlRuleInfo();
			t.setId(100);
			return t;
			//ExceptionUtil.throwDefaultKmException("演示用户，不能进行此功能操作");
		}
		KmEquipment kmEquip=kmEquipmentDAO.findById(controlrule.getEquipmentId());
		if(kmEquip.getEquipmenttype() == null || kmEquip.getEquipmenttype().equals("0")){
			return controlService.saveControlRule(user.getUserid(), controlrule);
		}else if(kmEquip.getEquipmenttype() != null && kmEquip.getEquipmenttype().equals("1") && controlrule.getAppId()==1L){
			if(controlrule.on){
				MdmService.updateIosLock(controlrule.getEquipmentId(),MdmUtils.InstallProfile);
			}else{
				MdmService.updateIosLock(controlrule.getEquipmentId(),MdmUtils.UnInstallProfile);
			}
		}else{
			ExceptionUtil.throwDefaultKmException("ios暂不支持此功能");
		}
		
		return controlService.saveControlRule(user.getUserid(), controlrule);
	}

	@Override
	public boolean setControlRuleInfoOn(TKmUser user, long ruleid)
			throws TException {
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			ExceptionUtil.throwDefaultKmException("演示用户，不能进行此功能操作");
		}
		
		return controlService.setControlRuleOn(user.getUserid(), ruleid);
	}

	@Override
	public boolean setControlRuleInfoOff(TKmUser user, long ruleid)
			throws TException {
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			ExceptionUtil.throwDefaultKmException("演示用户，不能进行此功能操作");
		}
		
		return controlService.setControlRuleOff(user.getUserid(), ruleid);
	}
	
	@Override
	public boolean setControlRuleInfoOffByAppid(TKmUser user, long appid,
			long childid, long equipmentID) throws TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		return controlService.setControlRuleInfoOffByAppid(user.getUserid(), appid, childid, equipmentID);
	}
	
	@Override
	public boolean delControlRuleInfo(TKmUser user, long ruleid)
			throws TException {
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			ExceptionUtil.throwDefaultKmException("演示用户，不能进行此功能操作");
		}
		return controlService.delControlRule(user.getUserid(), ruleid);
	}

	@Override
	public List<TKmTimeStatistics> getChildTimeStatistics(TKmUser user,
			long childid, int dayCount) throws TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			return  DemoData.getChildTimeStatistics();
		}                       
		return appUsageService.getChildTimeStatistics(user.getUserid(), childid, dayCount);
	}

	@Override
	public List<TKmAppUsageStatistics> getChildAppUsageStatistics(TKmUser user,
			long childid, int days, int topx) throws TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			return  DemoData.getChildAppUsageStatistics(days);
		}     
		return appUsageService.getChildAppUsageStatistics(user.getUserid(), childid, days, topx);
	}
	
	@Override
	public TKmAppUsage getTheLatestAppUsage(TKmUser user, long equipmentId)
			throws TKmException, TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			return  DemoData.getTheLatestAppUsage();
		}     
		TKmAppUsage tKmAppUsage = appUsageService.getTheLatestNotSysAppUsage(equipmentId, null);
		if (tKmAppUsage==null) {
			tKmAppUsage = new TKmAppUsage();
		}
		return tKmAppUsage;
	}

	@Override
	public List<TKmAppUsage> getEquipmentAppUsageStatistics(TKmUser user,
			long equipmentid, int page, int size, int ordertype)
			throws TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			return  DemoData.getchildtoday();
		}    
		return appUsageService.getEquipmentAppUsageStatistics(equipmentid, page, size, ordertype);
	}

	@Override
	public List<TKmPosition> getPositionList(TKmUser user, long equipmentid,
			int page, int size) throws TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		return positionService.getPositionList(equipmentid, page, size);
	}
	
	@Override
	public boolean isEquipmentLocked(TKmUser user, long childid,
			long equipmentid) throws TKmException, TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		
		return equipmentService.isEquipmentLocked(user, childid, equipmentid);
	}
	
	@Override
	public List<TKmSnapshot> getSnapshots(TKmUser user, long equipmentid,
			int page, int size) throws TException {
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			//return  DemoData.getchildtoday();
		}
//		KmEquipment kmEquip=kmEquipmentDAO.findById(equipmentid);
//		if(null!=kmEquip&&null!=kmEquip.getEquipmenttype() && kmEquip.getEquipmenttype().equals("1")){
//			ExceptionUtil.throwDefaultKmException("ios暂不支持此功能");
//			
//		}
		return childUserService.getSnapshots(user, equipmentid, page, size);
	}

	@Override
	public List<TKmEquipment> getEquipmentsByChildId(TKmUser user, long childid)
			throws TKmException, TException {
		parentUserService.verifyUserSign(user, true);
		long parentID=childUserService.getParentId(childid);
		return childUserService.getChildEquipmentList(parentID, childid);  //user.getid();
		
	}
     //立即截屏
	@Override
	public void snapshot(TKmUser user, long equipmentid) throws TException {
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			ExceptionUtil.throwDefaultKmException("演示用户，不能进行此功能操作");
		}
		KmEquipment kmEquip=kmEquipmentDAO.findById(equipmentid);
		if(kmEquip!=null&&kmEquip.getEquipmenttype() != null && kmEquip.getEquipmenttype().equals("1")){
			ExceptionUtil.throwDefaultKmException("ios暂不支持此功能");
		}
		controlService.getsnapshot(user.getUserid(), equipmentid);
	}
    
	
  // 08-11 zz
	@Override
	public boolean shareChild(TKmUser user, long timestamp, String code)
			throws TKmException, TException {
		parentUserService.verifyUserSign(user, true);
		
		return childUserService.shareChild(user.getUserid(), code);
	}

	@Override
	public List<TKmProductClass> getProduct_class(TKmUser user)
			throws TKmException, TException {
		parentUserService.verifyUserSign(user, true);
		return parentUserService.getProductClass(1, 3);
	}
	@Override
	public List<TKmProduct> getProduct(TKmUser user, long productclassid,
			int page, int size) throws TKmException, TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		return parentUserService.getProduct(productclassid, page, size);
	}
    
	@Override
	public List<TKmProduct> getListProduct(TKmUser user,
			List<Long> productclassid, int page, int size) throws TKmException,
			TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		return parentUserService.getListProducts(productclassid, page, size);
	}
	public KmEquipmentDAO getKmEquipmentDAO() {
		return kmEquipmentDAO;
	}

	@Override
	public TKmUser getTkmUserByopenId(TKmUser user, String accessToken,
			String opendId, String unionid, int source, String ip)
			throws TKmException, TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		return parentUserService.getTkmUserByUnionid(user.getUserid(),accessToken,opendId,unionid,source,ip);
	}
	
	@Override
	public List<TKmCredit> GetCreditScore(TKmUser user, List<Long> creditType)
			throws TKmException, TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		return creditServiceImpl.getKmcredit(user.getUserid(), creditType);
		
	}


	@Override
	public List<TKmCredit> saveCreditScore(TKmUser user, long creditType,
			long userCredit) throws TKmException, TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		return creditServiceImpl.saveKmCredit(user.getUserid(),creditType,userCredit);
		
	}
	
	@Override
	public String getCreditInvite(TKmUser user, long creditType)
			throws TKmException, TException {
		// TODO Auto-generated method stub
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			ExceptionUtil.throwDefaultKmException("演示用户，不能进行此功能操作");
		}
	
		return creditServiceImpl.getCreditInvite(user.getUserid(),creditType);
	}
	//100 表示新闻类型
	@Override
	public List<KmRssChan> getKmRss(TKmUser user,long channelType){
		return creditServiceImpl.getRssList(user.getUserid(), channelType);
	}
	
	@Override
	public boolean delSnashotPhoto(TKmUser user, List<Long> snaPhotoId,long equipmentid)
			throws TKmException, TException {
		// TODO Auto-generated method stub  删除截屏图片的接口。
		parentUserService.verifyUserSign(user, true);
		if (user.getUserid()==2000) {
			ExceptionUtil.throwDefaultKmException("演示用户，不能进行此功能操作");
		}
	
		return childUserService.delSnashotPhoto(user.getUserid(), snaPhotoId,equipmentid);
	}
	public void setKmEquipmentDAO(KmEquipmentDAO kmEquipmentDAO) {
		this.kmEquipmentDAO = kmEquipmentDAO;
	}
	
	

	public IMdmService getMdmService() {
		return MdmService;
	}

	public void setMdmService(IMdmService mdmService) {
		MdmService = mdmService;
	}

	public KmChildEquipmentDAO getKmChildEquipmentDAO() {
		return kmChildEquipmentDAO;
	}

	public void setKmChildEquipmentDAO(KmChildEquipmentDAO kmChildEquipmentDAO) {
		this.kmChildEquipmentDAO = kmChildEquipmentDAO;
	}
	
	public IParentUserService getParentUserService() {
		return parentUserService;
	}

	public void setParentUserService(IParentUserService parentUserService) {
		this.parentUserService = parentUserService;
	}

	public ShardedJedisPool getShardedJedisPool() {
		return shardedJedisPool;
	}

	public void setShardedJedisPool(ShardedJedisPool shardedJedisPool) {
		this.shardedJedisPool = shardedJedisPool;
	}

	public IChildUserService getChildUserService() {
		return childUserService;
	}

	public void setChildUserService(IChildUserService childUserService) {
		this.childUserService = childUserService;
	}

	public IAppInfoService getAppInfoService() {
		return appInfoService;
	}

	public void setAppInfoService(IAppInfoService appInfoService) {
		this.appInfoService = appInfoService;
	}

	public IEquipmentService getEquipmentService() {
		return equipmentService;
	}

	public void setEquipmentService(IEquipmentService equipmentService) {
		this.equipmentService = equipmentService;
	}

	public IControlService getControlService() {
		return controlService;
	}

	public void setControlService(IControlService controlService) {
		this.controlService = controlService;
	}

	public IAppUsageService getAppUsageService() {
		return appUsageService;
	}

	public void setAppUsageService(IAppUsageService appUsageService) {
		this.appUsageService = appUsageService;
	}

	public IPositionService getPositionService() {
		return positionService;
	}

	public void setPositionService(IPositionService positionService) {
		this.positionService = positionService;
	}

	public Config getConfig() {
		return config;
	}

	public void setConfig(Config config) {
		this.config = config;
	}

	public AppStoreRechargeService getAppStoreRechargeService() {
		return appStoreRechargeService;
	}

	public void setAppStoreRechargeService(AppStoreRechargeService appStoreRechargeService) {
		this.appStoreRechargeService = appStoreRechargeService;
	}

	public ICreditService getCreditServiceImpl() {
		return creditServiceImpl;
	}

	public void setCreditServiceImpl(ICreditService creditServiceImpl) {
		this.creditServiceImpl = creditServiceImpl;
	}

	

		
}
