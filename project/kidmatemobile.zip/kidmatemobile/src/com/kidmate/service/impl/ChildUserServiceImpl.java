package com.kidmate.service.impl;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.thrift.TException;

import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

import com.kidmate.kmservice.InternalService;
import com.kidmate.kmservice.TKmChild;
import com.kidmate.kmservice.TKmEquipment;
import com.kidmate.kmservice.TKmException;
import com.kidmate.kmservice.TKmSnapshot;
import com.kidmate.kmservice.TKmUser;
import com.kidmate.model.KmAppControlRule;
import com.kidmate.model.KmAppControlRuleDAO;
import com.kidmate.model.KmChild;
import com.kidmate.model.KmChildDAO;
import com.kidmate.model.KmChildEquipment;
import com.kidmate.model.KmChildEquipmentDAO;
import com.kidmate.model.KmEquipment;
import com.kidmate.model.KmEquipmentApp;
import com.kidmate.model.KmEquipmentAppDAO;
import com.kidmate.model.KmEquipmentDAO;
import com.kidmate.model.KmGuardian;
import com.kidmate.model.KmGuardianDao;
import com.kidmate.model.KmSnapshot;
import com.kidmate.model.KmSnapshotDAO;
import com.kidmate.service.IChildUserService;
import com.kidmate.service.IMdmService;
import com.kidmate.service.IParentUserService;
import com.kidmate.tools.Config;
import com.kidmate.tools.Constants;
import com.kidmate.tools.ExceptionUtil;
import com.kidmate.tools.FileUtil;
import com.kidmate.tools.InternalServiceUtil;
import com.kidmate.tools.SecurityUtils;

public class ChildUserServiceImpl implements IChildUserService {
	private KmChildDAO kmChildDAO;
	private KmEquipmentDAO kmEquipmentDAO;
	private KmChildEquipmentDAO kmChildEquipmentDAO;
	private KmEquipmentAppDAO kmEquipmentAppDAO;
	private KmAppControlRuleDAO kmAppControlRuleDAO;
	private KmGuardianDao kmGuardianDao;
	private KmSnapshotDAO  kmSnapshotDAO;
	private ShardedJedisPool shardedJedisPool;
	private IParentUserService parentUserService;
	private Config config;
	private InternalServiceUtil internalServiceUtil;
	private static Logger logger = Logger.getLogger(ChildUserServiceImpl.class);
	@Override
	public List<TKmChild> getCHild(long parentId) throws TException {
		// TODO Auto-generated method stub
		List<KmChild> kmChildList = kmChildDAO.findByParentid(parentId);
		List<KmGuardian> kmParEqu=kmGuardianDao.findByCpa(parentId);
		List<TKmChild> tKmChildList = new ArrayList<TKmChild>();
		for(KmGuardian  kmpe:kmParEqu){
			if(kmpe.getStatus().equals("1")){
				List<KmChild> kmChildList2 = kmChildDAO.findByParentid(kmpe.getParentId());
				for(KmChild kc:kmChildList2){
					System.out.println("kc.getId()"+kc.getId()+"kmpe.getChildId()"+kmpe.getChildId()+(kc.getId()==kmpe.getChildId()));
					if(kc.getId().equals(kmpe.getChildId())&&kc.getStatus().equals("1")){
//						System.out.println("------另外绑定的孩子"+kc.getId());
//						kmChildList.add(kc);
						TKmChild tKmChild = new TKmChild();
						tKmChild.setId(kc.getId());
						tKmChild.setName(kc.getName());
						if (kc.getBirth()!=null)
							tKmChild.setBirth(kc.getBirth().getTime());
						tKmChild.setGender("1".equals(kc.getGender()));
						tKmChild.setShareType("1");
						tKmChildList.add(tKmChild);
					}
				}
			}
			
		}
		for (KmChild kmChild: kmChildList) {
			if(kmChild.getStatus().equals("1")){
				TKmChild tKmChild = new TKmChild();
				tKmChild.setId(kmChild.getId());
				tKmChild.setName(kmChild.getName());
				if (kmChild.getBirth()!=null)
					tKmChild.setBirth(kmChild.getBirth().getTime());
				tKmChild.setGender("1".equals(kmChild.getGender()));
				tKmChild.setShareType("0");
				tKmChildList.add(tKmChild);
				System.out.println("------------getCHild"+kmChild.getId());
			}
		}
		return tKmChildList;
	}

	@Override
	public TKmChild saveChild(long parentID, TKmChild tKmChild)
			throws TException {
		// TODO Auto-generated method stub
		KmChild kmChild = null;
		if(tKmChild.getId()==0) {
			kmChild = new KmChild();
		} else {
			kmChild = kmChildDAO.findById(tKmChild.getId());
			if (kmChild.getParentid()!=parentID) {
				throw new TException();
			}
		}
		if (tKmChild.getBirth()!=0) {
			kmChild.setBirth(new Date(tKmChild.getBirth()));
		}
		kmChild.setParentid(parentID);
		kmChild.setGender(tKmChild.isGender()?"1":"0");
		List<KmChild>  kmcs=kmChildDAO.findByParentid(parentID);
		String tKmChildDate=new Date(tKmChild.getBirth()).toString();
		  for(KmChild km:kmcs){
			if(!km.getId().equals(tKmChild.getId())){
				  if(km.getName().equals(tKmChild.getName()) && km.getParentid().equals(parentID)){
					  ExceptionUtil.throwDefaultKmException("孩子姓名已存在！");
				  }
			 }
			  
		  }
		kmChild.setName(tKmChild.getName());
		kmChild.setStatus("1");
		if (kmChild.getId()!=null) {
			kmChildDAO.attachDirty(kmChild);
		} else {
			kmChild.setCreatetime(new Date());
			kmChildDAO.save(kmChild);
			tKmChild.setId(kmChild.getId());
		}
		return tKmChild;
	}

	

	@Override
	public boolean delChild(long parentID, long childID) throws TException {
		// TODO Auto-generated method stub
		KmChild kmChild = kmChildDAO.findById(childID);
		if (kmChild.getParentid()!=parentID) {
			KmGuardian kpt=new KmGuardian();
			kpt.setCparentId(parentID);
			kpt.setChildId(childID);
			kpt.setParentId(kmChild.getParentid());
			List<KmGuardian> kmparequ=kmGuardianDao.findByExample(kpt);
			for(KmGuardian kpe:kmparequ){
				if(kpe.getChildId().equals(childID)){
					kpe.setStatus("0");
					kmGuardianDao.attachDirty(kpe);
					//TODO 向分享的家长发送消息，删除成功
					InternalService.Iface iface = internalServiceUtil.borrowInternal();
					try {
						iface.sendMessge(1, "1000", parentUserService.getAccountId(parentID), "{\"type\":\"1\"}", "删除设备", null);
					} catch (TException e) {
						e.printStackTrace();
					}
					internalServiceUtil.returnInternal(iface);
					logger.info("---------分享的家长端删除了孩子");
				}
			}
			return true;
		}
		
		//将规则清空，除了ios的控制规则
		KmAppControlRule kmAppCon=new KmAppControlRule();
		kmAppCon.setParentid(parentID);
		kmAppCon.setChildid(childID);
		List<KmAppControlRule> kmAppConRus=kmAppControlRuleDAO.findByExample(kmAppCon);
		for(KmAppControlRule s:kmAppConRus){
			if(s.getAppid()!=2l){
				s.setStatus("0");
				kmAppControlRuleDAO.attachDirty(s);
			}
		}
		//TODO 向家长发送消息，绑定成功
				InternalService.Iface iface = internalServiceUtil.borrowInternal();
				try {
					iface.sendMessge(1, "1000", parentUserService.getAccountId(parentID), "{\"type\":\"1\"}", "删除设备", null);
				} catch (TException e) {
					e.printStackTrace();
				}
				internalServiceUtil.returnInternal(iface);
		List<KmChildEquipment> kmChildEquipmentList = kmChildEquipmentDAO.findByChildid(childID);
		List<KmEquipment> kmEquipment = kmEquipmentDAO.findByChildID(childID);
		boolean add=true;
		for (KmChildEquipment e:kmChildEquipmentList) {
			if (e.getStatus().equals("1")||e.getStatus().equals("2")) {
				e.setStatus("0");
				kmChildEquipmentDAO.attachDirty(e);
			}
		}
		
		if (kmEquipment!=null || kmEquipment.size()>0) {
			for(KmEquipment  ks:kmEquipment){
				ks.setStatus("0");
				String sign = SecurityUtils.md5ByHex("%q23r"+ Math.random() + Math.random());
				ks.setSign(sign);
				kmEquipmentDAO.attachDirty(ks);
				ShardedJedis shardedJedis = shardedJedisPool.getResource();
				shardedJedis.hset(Constants.EQUIPMENTSIGN, String.valueOf(ks.getId()), sign);
				shardedJedisPool.returnResource(shardedJedis);
			}
			
		}
		kmChild.setStatus("0");
		kmChildDAO.attachDirty(kmChild);
		return true;
	}

	@Override
	public long getParentId(long childid) {
		KmChild kmChild = kmChildDAO.findById(childid);
		if (kmChild!=null) {
			return kmChild.getParentid();
		}
		return 0;
	}
	
	@Override
	public boolean bindEquipment(long parentID, long childID, long equipmentID)
			throws TException {
		// TODO Auto-generated method stub
		KmChild kmChild = kmChildDAO.findById(childID);
		KmEquipment kmEquipment = kmEquipmentDAO.findById(equipmentID);
		if (kmChild==null || kmEquipment==null) {
			ExceptionUtil.throwUnauthorizedKmException();
		}
		if (kmChild.getParentid()!=parentID || kmEquipment.getParentid()!=parentID) {
				ExceptionUtil.throwUnauthorizedKmException();	
			
		}
		
		List<KmChildEquipment> kmChildEquipmentList = kmChildEquipmentDAO.findByEquipmentid(equipmentID);
		boolean add = true;
		for (KmChildEquipment ce:kmChildEquipmentList) {
			if (ce.getChildid() != childID || ce.getStatus().equals("0")) {
				ce.setChildid(childID);
				ce.setStatus("1");
				kmChildEquipmentDAO.attachDirty(ce);
			}
         add = false;
		}
		if (add) {
			KmChildEquipment kmChildEquipment = new KmChildEquipment();
			kmChildEquipment.setChildid(childID);
			kmChildEquipment.setEquipmentid(equipmentID);
			kmChildEquipment.setStatus("1");
			kmChildEquipmentDAO.save(kmChildEquipment);
			{
				KmAppControlRule r = new KmAppControlRule();
				r.setControlname("学习时间");
				r.setAppid(0L);
				r.setParentid(parentID);
				r.setChildid(childID);
				r.setEquipmentid(equipmentID);
				r.setStarttime(16*60*60*1000);
				r.setEndtime((18*60+30)*60*1000);
				r.setCreatetime(new Date());
				r.setDuration(0);
				// 工作日重复
				r.setRepeattype(0x1F);
				r.setStatus("0");
				kmAppControlRuleDAO.save(r);
			}
			
			{
				// 睡觉时间
				KmAppControlRule r = new KmAppControlRule();
				r.setControlname("睡觉时间");
				r.setAppid(0L);
				r.setParentid(parentID);
				r.setChildid(childID);
				r.setEquipmentid(equipmentID);
				r.setStarttime(22*60*60*1000);
				r.setEndtime(7*60*60*1000);
				r.setCreatetime(new Date());
				r.setDuration(0);
				// 每天重复
				r.setRepeattype(0x7F);
				r.setStatus("0");
				kmAppControlRuleDAO.save(r);
			}
		}
		ShardedJedis shardedJedis = shardedJedisPool.getResource();
		shardedJedis.hset(Constants.EQ2CID, String.valueOf(equipmentID), String.valueOf(childID));
		shardedJedisPool.returnResource(shardedJedis);

		return true;
	}
	
	@Override
	public boolean unBindEquipment(long parentID, long childID, long equipmentID)
			throws TException {
		// TODO Auto-generated method stub
		KmChild kmChild = kmChildDAO.findById(childID);
		KmEquipment kmEquipment = kmEquipmentDAO.findById(equipmentID);
		if (kmChild==null || kmEquipment==null) {
			ExceptionUtil.throwUnauthorizedKmException();
		}
		if (kmChild.getParentid()!=parentID || kmEquipment.getParentid()!=parentID) {
			ExceptionUtil.throwUnauthorizedKmException();
		}
		KmChildEquipment kmChildEquipment = new KmChildEquipment();
		kmChildEquipment.setChildid(childID);
		kmChildEquipment.setEquipmentid(equipmentID);
		List<KmChildEquipment> kmChildEquipmentList = kmChildEquipmentDAO.findByExample(kmChildEquipment);
		for (KmChildEquipment e:kmChildEquipmentList) {
			if (!e.getStatus().equals("0")) {
				e.setStatus("0");
				kmChildEquipmentDAO.attachDirty(e);
			}
		}
		ShardedJedis shardedJedis = shardedJedisPool.getResource();
		shardedJedis.hset(Constants.EQ2CID, String.valueOf(equipmentID), "0");
		shardedJedisPool.returnResource(shardedJedis);
		return true;
	}


	@Override
	public List<TKmEquipment> getChildEquipmentList(long parentID, long childID) throws TException{
		// TODO Auto-generated method stub
		KmChild kmChild = kmChildDAO.findById(childID);
		
		if (kmChild==null ) {  //|| kmChild.getParentid()!=parentID
			ExceptionUtil.throwUnauthorizedKmException();
		}
     	List<TKmEquipment> tKmEquipmentList = new ArrayList<TKmEquipment>();
//		if (kmChild.getParentid() .equals(parentID)) {
//			KmParentEquipment kmparequ = new KmParentEquipment();
//			kmparequ.setChildId(childID);
//			kmparequ.setStatus("1");
//			kmparequ.setCparentId(parentID); //根据获得分享家长id找，其实只能找到一条数据
//			List<KmParentEquipment> kmpars = kmParentEquipmentDao.findByExample(kmparequ);
//			for (KmParentEquipment kmp : kmpars) {
//				if (kmp.getChildId() == childID) {
//					List<KmEquipment> keLi = kmEquipmentDAO.findByChildID(childID);
//					for (KmEquipment km : keLi) {
//						TKmEquipment tKmEquipment = new TKmEquipment();
//						tKmEquipment.setAliasName(km.getAlias());
//						tKmEquipment.setMac(km.getMac());
//						tKmEquipment.setId(km.getId());
//						tKmEquipmentList.add(tKmEquipment);
//					}
//				}
//			}
//
//			return tKmEquipmentList;
//		}
		List<KmEquipment> kmEquipmentList = kmEquipmentDAO.findByChildID(childID);
		for (KmEquipment kmEquipment: kmEquipmentList) {
			 //如果是他自己的设备
			    TKmEquipment tKmEquipment = new TKmEquipment();
				tKmEquipment.setAliasName(kmEquipment.getAlias());
				tKmEquipment.setMac(kmEquipment.getMac());
				tKmEquipment.setId(kmEquipment.getId());
				tKmEquipmentList.add(tKmEquipment);
			
		}
		return tKmEquipmentList;
	}
	
	@Override
	public List<Long> getAppIds(long childID) {
		// TODO Auto-generated method stub
		List<KmEquipmentApp> kmEquipmentAppList = kmEquipmentAppDAO.findByChildId(childID);
		List<Long> ids = new ArrayList<Long>();
		for (KmEquipmentApp e:kmEquipmentAppList) {
			if (!ids.contains(e.getAppid()))
				ids.add(e.getAppid());
		}
		
		return ids;
	}
	
	//上传孩子截屏的图片
	@Override
	public void uploadSnapshot(TKmUser user, TKmSnapshot  snapshot){
		// TODO Auto-generated method stub
		// user.getUserid()就是设备的id
		//KmEquipment kmes = kmEquipmentDAO.findById(user.getUserid());
		boolean flag = true;
		
			ShardedJedis shardedJedis = shardedJedisPool.getResource();
			String parentid=shardedJedis.hget(Constants.SNAPSHOTID,String.valueOf(user.getUserid()+"snapshot"));
			shardedJedisPool.returnResource(shardedJedis);
		
		// TODO 向家长发送消息，上传截屏是否成功
		InternalService.Iface iface = internalServiceUtil.borrowInternal();
		if (snapshot.getType() == -1) {
			try {
				if (parentid != null) {
					iface.sendMessge(1, "1000",parentUserService.getAccountId(Long.parseLong(parentid)),"{\"type\":\"-6\"}", "系统版本过低", null);
				}
			} catch (TKmException e) {
				logger.error(e, e);
			} catch (TException e) {
				logger.error(e, e);
			}
		} else if (snapshot.getType() == 1) {
            // byte bb=imagedata.get();
			KmSnapshot kmSnapshot = new KmSnapshot();
			// String savePath=config.getImagePath();//
			// 修改，目录结构的调整 /tomcat/webapps/images
			String savedir = "/" + user.getUserid() / 30000 + "/"+ user.getUserid();
			System.out.println("config = " + config);
			String savePath = config.getImagePath() + savedir;
            logger.info("------------config.getImagePath() = " + config.getImagePath());
            File saveFile = new File(savePath);
			if (!saveFile.exists()) {
				saveFile.mkdirs();
			}
			// ByteBuffer imagedata=snapshot.bufferForImagedata();
			//System.out.println("bufferForImagedata=="+ snapshot.bufferForImagedata());
			String name = FileUtil.saveFile(snapshot.bufferForImagedata(),savePath);
			// http://192.168.0.222:888/images/
			kmSnapshot.setUrl(config.getImageUrl() + savedir + "/" + name);
			kmSnapshot.setEquipmentid(user.getUserid());
			kmSnapshot.setCreatetime(new Date());
			kmSnapshot.setLongitude(snapshot.getLongitude());
			kmSnapshot.setLatitude(snapshot.getLatitude());
			kmSnapshot.setAddr(snapshot.addr);
			kmSnapshot.setStatus("1");
			try {
				if (kmSnapshot != null) {
					kmSnapshotDAO.attachDirty(kmSnapshot);
				}
			} catch (Exception e) {
				flag = false;
				logger.error(e, e);
			}
            try {
               if (parentid != null) {
					if (flag) {
						iface.sendMessge(1, "1000", parentUserService
								.getAccountId(Long.parseLong(parentid)),
								"{\"type\":\"5\"}", "上传成功", null);
					} else {
						iface.sendMessge(1, "1000", parentUserService
								.getAccountId(Long.parseLong(parentid)),
								"{\"type\":\"-5\"}", "上传失败", null);
					}

				}

			} catch (TException e) {
				logger.error(e, e);
			}
		}
        internalServiceUtil.returnInternal(iface);

	}
	
	 //分页获取孩子截屏的图片
	@Override
	public List<TKmSnapshot> getSnapshots(TKmUser user, long equipmentid,
			int page, int size) throws TException {
		
		KmEquipment kmEquipment = kmEquipmentDAO.findById(equipmentid);
		if(kmEquipment==null ){
			ExceptionUtil.throwUnauthorizedKmException();
		}
		List<TKmSnapshot> tkmsnaps=new  ArrayList<TKmSnapshot>();
		List<KmSnapshot> kmSnapshot=kmSnapshotDAO.findKmSnapshot(equipmentid, page, size);
		for(KmSnapshot  km:kmSnapshot){
			TKmSnapshot tKmSnapshot=new TKmSnapshot();
			tKmSnapshot.setId(km.getId());
			if(km.getAddr()==null){
				km.setAddr("");
			}
			tKmSnapshot.setAddr(km.getAddr());
			tKmSnapshot.setLatitude(km.getLatitude());
			tKmSnapshot.setLongitude(km.getLongitude());
			tKmSnapshot.setUrl(km.getUrl());
			tKmSnapshot.setTime(km.getCreatetime().getTime());
			tkmsnaps.add(tKmSnapshot);
		}
		return tkmsnaps;
	}

	@Override
	public boolean shareChild(long cparentID, String qrcode) throws TException {
		// TODO Auto-generated method stub
		String params[]=params = qrcode.split("\\$");
		String qsign = null;
		try{
			qsign = params[3].trim();
		}catch(Exception e){
			ExceptionUtil.throwDefaultKmException("请扫描正确的二维码！");
		}
		long time = Long.valueOf(params[2].trim());
		if (Math.abs(System.currentTimeMillis()-time)>120000) {
			ExceptionUtil.throwDefaultKmException("时间过期，请家长端刷新二维码后重新扫描！");
		}
		long parentId = Long.valueOf(params[0].trim());
		long childID = Long.valueOf(params[1].trim());
		String t = SecurityUtils.md5ByHex("" + (parentId<<1) + (childID<<2) + (time<<3) + "%qz23r").substring(5, 13);
        System.out.println("----qsign=="+qsign+"-------parentId=="+parentId+"-----childID"+childID+"-----time==="+time);
		logger.info("---------shareChild ------------      md5ByHex:" + t);
		if (!SecurityUtils.md5ByHex("" + (parentId<<1) + (childID<<2) + (time<<3) + "%qz23r").substring(5, 13).equals(qsign)) {
			ExceptionUtil.throwDefaultKmException("二维码校验有误！");
		}
		SecurityUtils.md5ByHex("" + (parentId<<1) + (childID<<2) + (time<<3) + "%qz23r").substring(5, 13);
        if(parentId==cparentID){
			ExceptionUtil.throwDefaultKmException("不可以分享孩子给原家长");
		}
        long childParentid=this.getParentId(childID);  //第二个家长不可以在分享。
        if(childParentid!=parentId){
        	ExceptionUtil.throwUnauthorizedKmException();
        }
		KmGuardian kmGuardian=new KmGuardian();
		kmGuardian.setChildId(childID);
		kmGuardian.setParentId(parentId);
		kmGuardian.setCparentId(cparentID);
		List<KmGuardian> guard=kmGuardianDao.findByExample(kmGuardian);
		if(guard==null ||guard.size()==0){
			kmGuardian.setCreatetime(new Date());
			kmGuardian.setStatus("1");
			kmGuardianDao.save(kmGuardian);
			return true;
		}else  if(guard.size()==1&&guard.get(0).getParentId().equals(parentId)){
			kmGuardian=guard.get(0);
			kmGuardian.setStatus("1");
			kmGuardianDao.attachDirty(kmGuardian);
			return true;
		}
		return false;
	}

	
	 
	@Override
	public boolean delSnashotPhoto(long parentId, List<Long> snaPhotoId,long equipmentid)
			throws TException {
		// TODO Auto-generated method stub
//		KmEquipment km=kmEquipmentDAO.findById(equipmentid);
//		if(!km.getParentid().equals(parentId)){
//			KmGuardian  KmGu=new KmGuardian();
//			KmGu.setParentId(km.getParentid());
//			KmGu.setCparentId(parentId);
//			List<KmGuardian> kmGus=kmGuardianDao.findByExample(KmGu);
//			if(kmGus.size()==0){
//				return false;
//			}
//		}
		int size=kmSnapshotDAO.delSnapshot(equipmentid, snaPhotoId);
		if(size>0){
			return true;
		}
		return false;
	}

	
	public KmChildDAO getKmChildDAO() {
		return kmChildDAO;
	}

	public void setKmChildDAO(KmChildDAO kmChildDAO) {
		this.kmChildDAO = kmChildDAO;
	}

	public KmEquipmentDAO getKmEquipmentDAO() {
		return kmEquipmentDAO;
	}

	public void setKmEquipmentDAO(KmEquipmentDAO kmEquipmentDAO) {
		this.kmEquipmentDAO = kmEquipmentDAO;
	}

	public KmChildEquipmentDAO getKmChildEquipmentDAO() {
		return kmChildEquipmentDAO;
	}

	public void setKmChildEquipmentDAO(KmChildEquipmentDAO kmChildEquipmentDAO) {
		this.kmChildEquipmentDAO = kmChildEquipmentDAO;
	}

	public ShardedJedisPool getShardedJedisPool() {
		return shardedJedisPool;
	}

	public void setShardedJedisPool(ShardedJedisPool shardedJedisPool) {
		this.shardedJedisPool = shardedJedisPool;
	}

	public KmEquipmentAppDAO getKmEquipmentAppDAO() {
		return kmEquipmentAppDAO;
	}

	public void setKmEquipmentAppDAO(KmEquipmentAppDAO kmEquipmentAppDAO) {
		this.kmEquipmentAppDAO = kmEquipmentAppDAO;
	}

	public KmAppControlRuleDAO getKmAppControlRuleDAO() {
		return kmAppControlRuleDAO;
	}

	public void setKmAppControlRuleDAO(KmAppControlRuleDAO kmAppControlRuleDAO) {
		this.kmAppControlRuleDAO = kmAppControlRuleDAO;
	}

	public KmSnapshotDAO getKmSnapshotDAO() {
		return kmSnapshotDAO;
	}

	public void setKmSnapshotDAO(KmSnapshotDAO kmSnapshotDAO) {
		this.kmSnapshotDAO = kmSnapshotDAO;
	}

	public Config getConfig() {
		return config;
	}

	public void setConfig(Config config) {
		this.config = config;
	}

	public InternalServiceUtil getInternalServiceUtil() {
		return internalServiceUtil;
	}

	public void setInternalServiceUtil(InternalServiceUtil internalServiceUtil) {
		this.internalServiceUtil = internalServiceUtil;
	}

	public IParentUserService getParentUserService() {
		return parentUserService;
	}

	public void setParentUserService(IParentUserService parentUserService) {
		this.parentUserService = parentUserService;
	}

	public KmGuardianDao getKmGuardianDao() {
		return kmGuardianDao;
	}

	public void setKmGuardianDao(KmGuardianDao kmGuardianDao) {
		this.kmGuardianDao = kmGuardianDao;
	}

	
	
	
}
