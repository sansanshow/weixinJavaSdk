package com.kidmate.service.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.thrift.TException;

import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

import com.kidmate.kmservice.TKmAppUsage;
import com.kidmate.kmservice.TKmAppUsageStatistics;
import com.kidmate.kmservice.TKmTimeStatistics;
import com.kidmate.model.KmAppUsage;
import com.kidmate.model.KmAppUsageDAO;
import com.kidmate.model.KmChild;
import com.kidmate.model.KmChildDAO;
import com.kidmate.service.IAppUsageService;
import com.kidmate.service.IEquipmentService;
import com.kidmate.tools.Config;
import com.kidmate.tools.Constants;
import com.kidmate.tools.RedisUtil;

public class AppUsageServiceImpl implements IAppUsageService {
	private static Logger logger = Logger.getLogger(AppUsageServiceImpl.class);
	private KmAppUsageDAO kmAppUsageDAO;
	private ShardedJedisPool shardedJedisPool;
	private RedisUtil redisUtil;
	private Config config;
	private IEquipmentService equipmentService;
	private KmChildDAO kmChildDAO; 
	private SimpleDateFormat dateformat = new SimpleDateFormat("yyyyMMdd");
	@Override
	public boolean addAppUsage(long equipmentId, TKmAppUsage tKmAppUsage, String ip, ShardedJedis shardedJedis) {
		// TODO Auto-generated method stub
		TKmAppUsage latestAppUsage = this.getTheLatestAppUsage(equipmentId, shardedJedis);
		boolean add = true;
		if (latestAppUsage != null) {
			if (tKmAppUsage.getAppid() == latestAppUsage.getAppid()) {
				if (latestAppUsage.getTime() + latestAppUsage.getDuration()
						+ config.getTimedur() > tKmAppUsage.getTime()) {
					add = false;
					if(tKmAppUsage.getTime()- latestAppUsage.getTime()>0){
						latestAppUsage.setDuration(tKmAppUsage.getTime()
								- latestAppUsage.getTime());
						kmAppUsageDAO.updateAppUsage(latestAppUsage.getId(),
								latestAppUsage.getDuration());
						redisUtil.hsetObject(shardedJedis,
								Constants.LATEST_APP_USAGE,
								String.valueOf(equipmentId), latestAppUsage);
						if (tKmAppUsage.getAppid() >= 5000) {
							redisUtil.hsetObject(shardedJedis,
									Constants.LATEST_NOTSYSAPP_USAGE,
									String.valueOf(equipmentId), latestAppUsage);
						}
					}
					
				} else {
					long t1 = latestAppUsage.getDuration() + 5 * 60 * 1000;
					long t2 = tKmAppUsage.getTime() - latestAppUsage.getTime();
					if((t1 < t2 ? t1 : t2)>0){
						 kmAppUsageDAO.updateAppUsage(latestAppUsage.getId(),
									t1 < t2 ? t1 : t2);
					}
				
				}
			} else {
				long t1 = latestAppUsage.getDuration() + 5 * 60 * 1000;
				long t2 = tKmAppUsage.getTime() - latestAppUsage.getTime();
				if((t1 < t2 ? t1 : t2)>0){
					kmAppUsageDAO.updateAppUsage(latestAppUsage.getId(),
							t1 < t2 ? t1 : t2);
				}
				
			}
		}
		if (add) {
			KmAppUsage kmAppUsage = new KmAppUsage();
			kmAppUsage.setChildid(equipmentService.getChildID(equipmentId, shardedJedis));
			kmAppUsage.setAppid(tKmAppUsage.getAppid());
			kmAppUsage.setCreatetime(new Date(tKmAppUsage.getTime()));
			kmAppUsage.setEquipmentid(equipmentId);
			kmAppUsage.setIp(ip);
			kmAppUsage.setLocationid(tKmAppUsage.getPositionid());
			kmAppUsage.setStatus("1");
			kmAppUsage.setWifiid(tKmAppUsage.getWifiid());
			kmAppUsageDAO.save(kmAppUsage);
			tKmAppUsage = new TKmAppUsage();
			tKmAppUsage.setId(kmAppUsage.getId());
			tKmAppUsage.setAppid(kmAppUsage.getAppid());
			if(kmAppUsage.getLocationid()!=null)
				tKmAppUsage.setPositionid(kmAppUsage.getLocationid());
			if(kmAppUsage.getWifiid()!=null)
				tKmAppUsage.setWifiid(kmAppUsage.getWifiid());
			tKmAppUsage.setTime(kmAppUsage.getCreatetime().getTime());
			if(kmAppUsage.getDuration()!=null)
				tKmAppUsage.setDuration(kmAppUsage.getDuration());
			redisUtil.hsetObject(shardedJedis, Constants.LATEST_APP_USAGE, String.valueOf(equipmentId), tKmAppUsage);
			if (tKmAppUsage.getAppid()>=5000) {
				redisUtil.hsetObject(shardedJedis, Constants.LATEST_NOTSYSAPP_USAGE, String.valueOf(equipmentId), tKmAppUsage);
			}
		}
		return true;
	}

	@Override
	public TKmAppUsage getTheLatestAppUsage(long equipmentId, ShardedJedis shardedJedis) {
		// TODO Auto-generated method stub
		TKmAppUsage tKmAppUsage = redisUtil.hgetObject(shardedJedis, Constants.LATEST_APP_USAGE, String.valueOf(equipmentId));
		if (tKmAppUsage==null) {
			KmAppUsage kmAppUsage = kmAppUsageDAO.findLatestAppUsage(equipmentId);
			if (kmAppUsage!=null) {
				tKmAppUsage = new TKmAppUsage();
				tKmAppUsage.setId(kmAppUsage.getId());
				tKmAppUsage.setAppid(kmAppUsage.getAppid());
				if(kmAppUsage.getLocationid()!=null)
					tKmAppUsage.setPositionid(kmAppUsage.getLocationid());
				if(kmAppUsage.getWifiid()!=null)
					tKmAppUsage.setWifiid(kmAppUsage.getWifiid());
				tKmAppUsage.setTime(kmAppUsage.getCreatetime().getTime());
				if(kmAppUsage.getDuration()!=null)
					tKmAppUsage.setDuration(kmAppUsage.getDuration());
				redisUtil.hsetObject(shardedJedis, Constants.LATEST_APP_USAGE, String.valueOf(equipmentId), tKmAppUsage);
			}
		}
		return tKmAppUsage;
	}
	
	@Override
	public TKmAppUsage getTheLatestNotSysAppUsage(long equipmentId, ShardedJedis shardedJedis) {
		// TODO Auto-generated method stub
		TKmAppUsage tKmAppUsage = redisUtil.hgetObject(shardedJedis, Constants.LATEST_NOTSYSAPP_USAGE, String.valueOf(equipmentId));
		if (tKmAppUsage==null) {
			KmAppUsage kmAppUsage = kmAppUsageDAO.findLatestNotSysAppUsage(equipmentId);
			if (kmAppUsage!=null) {
				tKmAppUsage = new TKmAppUsage();
				tKmAppUsage.setId(kmAppUsage.getId());
				tKmAppUsage.setAppid(kmAppUsage.getAppid());
				if(kmAppUsage.getLocationid()!=null)
					tKmAppUsage.setPositionid(kmAppUsage.getLocationid());
				if(kmAppUsage.getWifiid()!=null)
					tKmAppUsage.setWifiid(kmAppUsage.getWifiid());
				tKmAppUsage.setTime(kmAppUsage.getCreatetime().getTime());
				if(kmAppUsage.getDuration()!=null)
					tKmAppUsage.setDuration(kmAppUsage.getDuration());
				redisUtil.hsetObject(shardedJedis, Constants.LATEST_NOTSYSAPP_USAGE, String.valueOf(equipmentId), tKmAppUsage);
			}
		}
		return tKmAppUsage; 
	}
	
	
	@Override
	public long getChildAvgUsageTime(long birth , long date) {
		// TODO Auto-generated method stub
		if (birth==0) {
			return 0;
		}
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(birth);
		cal.set(Calendar.MONTH, 0);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        int birthyear = cal.get(Calendar.YEAR);
        Date ageStart = cal.getTime();
		cal.add(Calendar.YEAR, 1);
		Date ageEnd =  cal.getTime();
		
		cal.setTimeInMillis(date);
		cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        Date dayStart = cal.getTime();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        Date dayEnd = cal.getTime();
        
        long systime = System.currentTimeMillis();
        
        if (systime<dayStart.getTime()) {
        	return 0;
        }
        
        long avgtime = 0;
        if (systime>dayEnd.getTime() && systime-dayEnd.getTime()> 3*3600000) {
        	String key = "b" + birthyear + "d"  + dateformat.format(dayStart);
        	ShardedJedis shardedJedis = shardedJedisPool.getResource();
        	if (shardedJedis.hexists(Constants.AVGDAYTIME, key)) {
        		avgtime = Long.valueOf(shardedJedis.hget(Constants.AVGDAYTIME, key));
        	} else {
        		avgtime = kmAppUsageDAO.findChildAvgTime(dayStart, dayEnd, ageStart, ageEnd);
        		shardedJedis.hset(Constants.AVGDAYTIME, key, String.valueOf(avgtime));
        	}
        	shardedJedisPool.returnResource(shardedJedis);
        } else {
        	avgtime = kmAppUsageDAO.findChildAvgTime(dayStart, dayEnd, ageStart, ageEnd);
        }
		return avgtime;
	}
	
	@Override
	public long getChildUsageTime(long childid, long date) {
		// TODO Auto-generated method stub
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(date);
		cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        Date dayStart = cal.getTime();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        Date dayEnd = cal.getTime();
        long systime = System.currentTimeMillis();

        if (systime<dayStart.getTime()) {
        	return 0;
        }
        
        long childtime = 0;
        if (systime>dayEnd.getTime() && systime-dayEnd.getTime()> 3*3600000) {
        	String key = "c" + childid + "d"  + dateformat.format(dayStart);
        	ShardedJedis shardedJedis = shardedJedisPool.getResource();
        	if (shardedJedis.hexists(Constants.AVGDAYTIME, key)) {
        		childtime = Long.valueOf(shardedJedis.hget(Constants.CHILDDAYTIME, key));
        	} else {
        		childtime = kmAppUsageDAO.findChildTime(dayStart, dayEnd, childid);
        		shardedJedis.hset(Constants.CHILDDAYTIME, key, String.valueOf(childtime));
        	}
        	shardedJedisPool.returnResource(shardedJedis);
        } else {
        	childtime = kmAppUsageDAO.findChildTime(dayStart, dayEnd, childid);
        }
		return childtime;
	}

	@Override
	public List<TKmTimeStatistics> getChildTimeStatistics(long parentid,
			long childid, int dayCount) throws TException {
		// TODO Auto-generated method stub
		if (dayCount>10) {
			return null;
		}
		KmChild kmChild = kmChildDAO.findById(childid);
		if (kmChild==null ) {
			return null;
		}
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(System.currentTimeMillis());
		cal.add(Calendar.DAY_OF_MONTH, 0-dayCount);
		List<TKmTimeStatistics> tKmTimeStatisticsList = new ArrayList<TKmTimeStatistics>();
		for (int i=0; i<dayCount; i++ ) {
			Date d = cal.getTime();
			TKmTimeStatistics tKmTimeStatistics = new TKmTimeStatistics();
			tKmTimeStatistics.setTime(d.getTime());
			if (kmChild.getBirth()!=null)
				tKmTimeStatistics.setAvgDuration(getChildAvgUsageTime(kmChild.getBirth().getTime() , d.getTime()));
			tKmTimeStatistics.setSelfDuration(getChildUsageTime(childid, d.getTime()));
			tKmTimeStatisticsList.add(tKmTimeStatistics);
			cal.add(Calendar.DAY_OF_MONTH, 1);
		}
		
		return tKmTimeStatisticsList;
	}

	@Override
	public List<TKmAppUsageStatistics> getChildAppUsageStatistics(
			long parentid, long childid, int dayCount, int topX) throws TException {
		// TODO Auto-generated method stub
		if (dayCount>10 || topX>50) {
			return null;
		}
		KmChild kmChild = kmChildDAO.findById(childid);
		if (kmChild==null ) {
			return null;
		}
		List<TKmAppUsageStatistics> tKmAppUsageStatisticsList = new ArrayList<TKmAppUsageStatistics>();
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(System.currentTimeMillis());
		cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.add(Calendar.DAY_OF_MONTH, 1-topX);
		
		List<Object[]> oList = kmAppUsageDAO.findTopApp(childid, cal.getTime(), topX);
		for (Object[] o : oList) {
			TKmAppUsageStatistics tKmAppUsageStatistics = new TKmAppUsageStatistics();
			tKmAppUsageStatistics.setAppid(((BigDecimal) o[0]).longValue());
			tKmAppUsageStatistics.setDuration(((BigDecimal) o[1]).longValue());
			tKmAppUsageStatisticsList.add(tKmAppUsageStatistics);
		}
		return tKmAppUsageStatisticsList;  
	} 
	
	@Override
	public List<TKmAppUsage> getEquipmentAppUsageStatistics(long equipmentid, int page, int size, int ordertype) throws TException{
		List<KmAppUsage> kmAppUsageList = kmAppUsageDAO.getEquipmentAppUsageStatistics(equipmentid, page, size, ordertype);
		List<TKmAppUsage> tKmAppUsageList = new ArrayList<TKmAppUsage>();
		for (KmAppUsage kmAppUsage:kmAppUsageList) {
			TKmAppUsage tKmAppUsage = new TKmAppUsage();
			tKmAppUsage.setAppid(kmAppUsage.getAppid());
			if (kmAppUsage.getDuration()!=null)
				tKmAppUsage.setDuration(kmAppUsage.getDuration());
			tKmAppUsage.setTime(kmAppUsage.getCreatetime().getTime());
			tKmAppUsageList.add(tKmAppUsage);
		}
		return tKmAppUsageList;
	}
	
	
	@Override
	public List<TKmAppUsageStatistics> getAppUsageStatistics(long childid,
			long equipmentId) {
		// TODO Auto-generated method stub
		return null;
	}

	public KmAppUsageDAO getKmAppUsageDAO() {
		return kmAppUsageDAO;
	}

	public void setKmAppUsageDAO(KmAppUsageDAO kmAppUsageDAO) {
		this.kmAppUsageDAO = kmAppUsageDAO;
	}

	public ShardedJedisPool getShardedJedisPool() {
		return shardedJedisPool;
	}

	public void setShardedJedisPool(ShardedJedisPool shardedJedisPool) {
		this.shardedJedisPool = shardedJedisPool;
	}

	public RedisUtil getRedisUtil() {
		return redisUtil;
	}

	public void setRedisUtil(RedisUtil redisUtil) {
		this.redisUtil = redisUtil;
	}

	public Config getConfig() {
		return config;
	}

	public void setConfig(Config config) {
		this.config = config;
	}

	public IEquipmentService getEquipmentService() {
		return equipmentService;
	}

	public void setEquipmentService(IEquipmentService equipmentService) {
		this.equipmentService = equipmentService;
	}

	public KmChildDAO getKmChildDAO() {
		return kmChildDAO;
	}

	public void setKmChildDAO(KmChildDAO kmChildDAO) {
		this.kmChildDAO = kmChildDAO;
	}

}
