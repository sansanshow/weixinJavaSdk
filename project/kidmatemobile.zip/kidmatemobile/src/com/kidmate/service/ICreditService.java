package com.kidmate.service;

import java.util.List;

import com.kidmate.kmservice.TKmCredit;
import com.kidmate.model.KmRss;
import com.kidmate.model.KmRssChan;
import com.kidmate.model.KmRssChannel;

public interface ICreditService {
	public List<TKmCredit> saveKmCredit(long userid,long creditType,long userCredit);
	
	public List<TKmCredit>  getKmcredit(long user,List<Long> creditType);
	
	public void quartzCredit();
	
	public String getCreditInvite(long userid,long creditType);
	
	public List<KmRssChan> getRssList(long userId,long channelType );
	
	
}
