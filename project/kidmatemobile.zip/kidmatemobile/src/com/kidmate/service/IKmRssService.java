package com.kidmate.service;

import java.util.List;

import com.kidmate.kmservice.TKmUser;
import com.kidmate.model.KmRss;
import com.kidmate.model.KmRssChan;

public interface IKmRssService {
	public List<KmRssChan> getKmRss(TKmUser user,long channelType);
}
