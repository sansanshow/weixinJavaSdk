package com.kidmate.service;

import java.util.List;

import org.apache.thrift.TException;

import com.kidmate.kmservice.TKmAppInfo;
import com.kidmate.kmservice.TKmAppInfoUpload;
import com.kidmate.kmservice.TKmException;
import com.kidmate.kmservice.TKmUser;

public interface IAppInfoService {

	public List<TKmAppInfo> getAppInfoByIds(List<Long> appIDList) throws  TException ;
	public List<TKmAppInfo> checkExistApp(List<String> packageList) throws  TException ;
	public List<TKmAppInfo> getAllAppInfo(long equipmentID) throws TException ;
	public List<TKmAppInfo> getAllChildAppInfo(long childID) throws TException ;
	public List<TKmAppInfo> addNewAppInfo(long equipmentID, List<TKmAppInfoUpload> appInfoUploadList) throws TException;
	public List<TKmAppInfo> bindToEquipment(long equipmentID, List<Long> appIDList)  throws TException;
	public boolean unInstallApp(TKmUser user, long appid) throws TKmException;
	public boolean InstallApp(TKmUser user, long appid) throws TKmException;
}
