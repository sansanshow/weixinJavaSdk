package com.kidmate.service;
import java.nio.ByteBuffer;
import java.util.List;

import org.apache.thrift.TException;

import com.kidmate.kmservice.TKmChild;
import com.kidmate.kmservice.TKmEquipment;
import com.kidmate.kmservice.TKmSnapshot;
import com.kidmate.kmservice.TKmUser;
public interface IChildUserService {
	public List<TKmChild> getCHild(long parentId)  throws TException;;
	public TKmChild saveChild(long parentID, TKmChild tKmChild)  throws TException;
	public boolean delChild(long parentID, long childID)  throws TException;;
	public boolean bindEquipment(long parentID, long childID, long equipmentID)  throws TException;
	public boolean unBindEquipment(long parentID, long childID, long equipmentID)  throws TException;
	public List<TKmEquipment> getChildEquipmentList(long parentID, long childID) throws TException;
	public List<Long> getAppIds(long childID);
	public long getParentId(long childid);
	public void  uploadSnapshot(TKmUser user,TKmSnapshot  snapshot);
	public List<TKmSnapshot> getSnapshots(TKmUser user, long equipmentid,int page, int size) throws TException ;
    public boolean shareChild(long cparentID,String code) throws TException;
    public  boolean delSnashotPhoto(long parentId,List<Long> snaPhotoId,long equipmentid) throws TException;
}
