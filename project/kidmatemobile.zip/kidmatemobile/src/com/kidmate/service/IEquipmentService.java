package com.kidmate.service;


import java.util.List;

import org.apache.thrift.TException;

import redis.clients.jedis.ShardedJedis;

import com.kidmate.kmservice.TKmEquipment;
import com.kidmate.kmservice.TKmException;
import com.kidmate.kmservice.TKmUser;


public interface IEquipmentService {
	public TKmUser bindEquipment(String mac, String ip, String qrcode, int source, String name)  throws TException;
	public TKmEquipment editEquipmentName(long parentId, long equipmentId, String name) throws TException;
	public boolean delEquipment(long id,long childId,long equipmentId);
	public long getChildID(long equipmentId, ShardedJedis shardedJedis);
	public boolean verifyUserSign(TKmUser user, boolean mustLogin) throws TKmException;
	public List<Long> getAppIds(long equipmentId);
	public List<Long> getAppUderControlIds(long equipmentId);
	public List<Long> getAppOutofControlIds(long equipmentId);
	
	public List<TKmEquipment> getParentEquipmentList(long parentID) throws TException;
	public boolean isEquipmentLocked(TKmUser user, long childid, long equipmentid) throws TKmException;
	public void updateLockStatus(TKmUser user, String status) throws TKmException;
	public boolean isIosExist(long equipmentId) throws TKmException;
}
