package com.kidmate.service;


import javax.servlet.http.HttpServletRequest;

import com.kidmate.kmservice.TKmException;

public interface IMdmService {
	public void updateIosLock(long equipmentId,String MdmCommand) throws TKmException;
	  
}

