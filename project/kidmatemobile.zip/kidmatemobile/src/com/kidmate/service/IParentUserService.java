package com.kidmate.service;

import java.util.List;

import org.apache.thrift.TException;

import com.kidmate.kmservice.ParentService.Iface;
import com.kidmate.kmservice.TKmCredit;
import com.kidmate.kmservice.TKmException;
import com.kidmate.kmservice.TKmProduct;
import com.kidmate.kmservice.TKmProductClass;
import com.kidmate.kmservice.TKmSnapshot;
import com.kidmate.kmservice.TKmUser;
import com.kidmate.model.KmParent;

public interface IParentUserService{
	public TKmUser login(String authToken, int source, String ip,String invitecode) throws TException;
	public String loginPw(String mobile, String password) throws TException;
	
	
	public boolean verifyUserSign(TKmUser user, boolean mustLogin) throws TKmException; 
	public String getVerifyUserSign(long userid) ;
	public String getAccountId(long parentid);
	
	public long getVipTime(long userid);
	
	public TKmUser getTkmUserByUnionid(long parentId,String accessToken, String opendId, String unionid, int source,
			String ip) throws TException;
	
	public TKmUser loginWx(String accessToken,String opendId,String unionid, int source, String ip) throws TException;
	
	public List<TKmProductClass> getProductClass(int page, int size);
	
	public List<TKmProduct> getProduct(long cid,int page, int size);
	public List<TKmProduct> getListProducts(List cid,int page, int size);
	
	
	
}
