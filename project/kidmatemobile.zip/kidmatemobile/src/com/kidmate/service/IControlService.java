package com.kidmate.service;

import java.util.List;

import com.kidmate.kmservice.TKmControlRuleInfo;
import com.kidmate.kmservice.TKmException;

public interface IControlService {
	public TKmControlRuleInfo saveControlRule(long parentID, TKmControlRuleInfo tKmControlRuleInfo)throws TKmException;
	public boolean setControlRuleOn(long parentID, long ruleId) throws TKmException;
	public boolean setControlRuleOff(long parentID, long ruleId) throws TKmException;
	public boolean setControlRuleInfoOffByAppid(long parentId, long appid, long childid, long equipmentID);
	public boolean delControlRule(long parentID, long ruleId) throws TKmException;
	public List<TKmControlRuleInfo> getChildControlRuleList(long childID);
	public List<TKmControlRuleInfo> getEquipmentControlRuleList(long equipmentID);
	public List<TKmControlRuleInfo> getEquipmentAllControlRuleList(long equipmentID);
	
	public void getsnapshot(long parentId,long equipmentID); //立即截屏后给客户端发送信息
}
