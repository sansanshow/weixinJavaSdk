package com.kidmate.servlet;

 
import org.apache.thrift.TProcessor;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.protocol.TCompactProtocol;

//import com.paofan.pfservice.PfService;
//import com.paofan.service.impl.PfServiceImpl;
/**
 * 
 * @author cjdai
 */
public class TsnapBinaryServlet extends BaseTServlet {
        
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TsnapBinaryServlet(TProcessor processor) {
        super( processor, new TBinaryProtocol.Factory());
        System.out.println("-----------------TsnapBinaryServlet------------------");
    }
}
