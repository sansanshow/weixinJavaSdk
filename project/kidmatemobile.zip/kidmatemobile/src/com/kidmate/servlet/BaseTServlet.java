package com.kidmate.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.thrift.TProcessor;
import org.apache.thrift.protocol.TProtocolFactory;
import org.apache.thrift.server.TServlet;

/**
 * 访问类的父类 用于获取ip以及port
 * @author cjdai
 */
public class BaseTServlet extends TServlet {

	public static Log logger = LogFactory.getLog(BaseTServlet.class);
	public static ThreadLocal<String> clientip = new ThreadLocal<String>();
//	public static ThreadLocal<Integer> clientport = new ThreadLocal<Integer>();
//	public static ThreadLocal<Byte> clientype = new ThreadLocal<Byte>();
//	public static ThreadLocal<String> clienversion = new ThreadLocal<String>();
	public BaseTServlet(TProcessor processor, TProtocolFactory protocolFactory) {
		super(processor, protocolFactory);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		long startTime = System.currentTimeMillis();
		if (request.getHeader("X-Real-IP") != null
				&& request.getHeader("X-Real-IP").length() != 0) {
			clientip.set(request.getHeader("X-Real-IP"));
		} else {
			clientip.set(request.getRemoteHost());
		}

//		if (request.getHeader("X-Real-Port") != null
//				&& request.getHeader("X-Real-Port").length() != 0) {
//			clientport.set(Integer.parseInt(request.getHeader("X-Real-Port")));
//		} else {
//			clientport.set(request.getRemotePort());
//		}
		super.doPost(request, response);
//		logger.debug("servlet deal time:" + (System.currentTimeMillis() - startTime));
	}

	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		LogFactory.getLog(TServlet.class).info("----------BaseTServlet init-------------");
		super.init();
	}
}
