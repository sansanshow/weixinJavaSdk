drop table km_parent;
CREATE table km_parent
(
	id NUMBER(18,0) primary key,			-- 用户id 
	mobile varchar2(15),					-- 电话
	username VARCHAR2(64), 					-- 登录用户名
	password VARCHAR2(64), 					-- 用户密码
	sign VARCHAR2(64), 						-- 用户签名，用于API的数据通讯
	name VARCHAR2(128), 					-- 用户名字
	head VARCHAR2(1024),					-- 用户头像
	LASTLOGINTIME DATE, 					-- 最近一次登录时间
	LASTLOGINIP VARCHAR2(16), 				-- 最近一次登录IP
	openaccountid VARCHAR2(32),
	md5token VARCHAR2(32),
	SOURCEID NUMBER(18,0), 					-- 用户来源编号，联合登录使用，表示来自1:qq 2:sina 3:淘宝
	TOKEN VARCHAR2(64),						-- 联合登录返回的token
	regsource  NUMBER(4,0),					-- 注册来源
	regtime	date,							-- 注册时间
	regip varchar2(64),						-- 注册ip
	phonetype char(1),
	phonemac VARCHAR2(64),
	vip date,								-- vip结束时间
	grouptype NUMBER(8,0),					-- 用户类型
	status char(1),							-- 状态 
	invitecode varchar2(15)					-- 邀请码
);

drop SEQUENCE seq_km_parent;
create SEQUENCE seq_km_parent
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;

drop table km_equipment;
CREATE table km_equipment
(
	id NUMBER(18,0) primary key,			-- 设备id
	parentid NUMBER(18,0),					-- 家长id
	equipmenttype char(1),					-- 设备类型
	alias VARCHAR2(16),						-- 设备别名		
	mac VARCHAR2(64),						-- 手机mac
	sign VARCHAR2(32),						-- 自动生成的校验
	regsource NUMBER(9,0),
	regip VARCHAR2(16),
	lastip VARCHAR2(16),
	createtime date,						-- 创建时间
	lastupdate date,						-- 最后更新时间
	status char(1)
);
drop SEQUENCE seq_km_equipment;
create SEQUENCE seq_km_equipment
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;

drop table km_child;
CREATE table km_child
(
	id NUMBER(18,0) primary key,			-- 设备id
	parentid NUMBER(18,0),					-- 家长id
	name VARCHAR2(64),						-- 姓名
	gender char(1),							-- 性别
	birth date,								-- 生日
	createtime date,						-- 创建时间
	status char(1)
);
drop SEQUENCE seq_km_child;
create SEQUENCE seq_km_child
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;

drop table km_child_equipment;
CREATE table km_child_equipment(
	id NUMBER(18,0) primary key,			-- 设备id
	childid NUMBER(18,0),					-- 用户id
	equipmentid NUMBER(18,0),				-- 设备id
	relationtype NUMBER(9,0),				-- 用户和设备的关系
	status char(1)							-- 状态
);

drop SEQUENCE seq_km_child_equipment;
create SEQUENCE seq_km_child_equipment
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;

drop table km_app_info;
CREATE table km_app_info(
	id NUMBER(18,0) primary key,			-- 应用id
	name VARCHAR2(128),						-- 应用名字
	packagename VARCHAR2(128),				-- 包名
	icon VARCHAR2(128),						-- 图片
	fromtype VARCHAR2(4),					-- 由谁创建  0：用户创建  1：腾讯应用市场
	categoryId VARCHAR2(8),					-- 分类id	
    categoryName VARCHAR2(16),				-- 分类名称
	createtime date,						-- 创建时间
	status char(1)							-- 状态
);

drop SEQUENCE seq_km_app_info;
create SEQUENCE seq_km_app_info
INCREMENT BY 1
START WITH 5000
NOMAXvalue
NOCYCLE
CACHE 10;

drop table km_equipment_app;
CREATE table km_equipment_app (
	id NUMBER(18,0) primary key,			-- 应用id
	equipmentid NUMBER(18,0),				-- 设备id
	appid NUMBER(18,0),						-- 应用id
	version VARCHAR2(32),					-- 版本
	createtime date,						-- 创建时间
	status char(1)							-- 状态
);

drop SEQUENCE seq_km_equipment_app;
create SEQUENCE seq_km_equipment_app
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;


drop table km_app_usage;
CREATE table km_app_usage (
	id NUMBER(18,0) primary key,			-- 应用id
	equipmentid VARCHAR2(128),				-- 设备id
	appid VARCHAR2(128),					-- 应用id
	wifiname VARCHAR2(128),					-- wifi名称
	wifissid VARCHAR2(128),				
	ip VARCHAR2(16),						-- 网络ip
	longitude number(8,4),					-- 经纬度
	latitude number(8,4),
	createtime date,						-- 创建时间
	duration NUMBER(18,0),					-- 持续时长
	status char(1)							-- 状态
);

drop SEQUENCE seq_km_app_usage;
create SEQUENCE seq_km_app_usage
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;


drop table km_app_usage;
CREATE table km_app_usage (
	id NUMBER(18,0) primary key,			-- 应用id
	equipmentid NUMBER(18,0),				-- 设备id
	childid  NUMBER(18,0),							-- 所属儿童id
	appid NUMBER(18,0),						-- 应用id
	wifiid NUMBER(18,0),					-- wifi名称	
	ip VARCHAR2(16),						-- 网络ip
	locationid NUMBER(18,0),				-- 经纬度
	createtime date,						-- 创建时间
	duration NUMBER(18,0),					-- 持续时长
	status char(1)							-- 状态
);

drop SEQUENCE seq_km_app_usage;
create SEQUENCE seq_km_app_usage
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;

drop table km_location;
CREATE table km_location (
	id NUMBER(18,0) primary key,			-- 应用id
	equipmentid NUMBER(18,0),				-- 设备id
	longitude number(8,4),					-- 经纬度
	latitude number(8,4),
	createtime date						-- 创建时间
);

drop SEQUENCE seq_km_location;
create SEQUENCE seq_km_location
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;


drop table km_wifi;
CREATE table km_wifi (
	id NUMBER(18,0) primary key,			-- 应用id
	equipmentid NUMBER(18,0),				-- 设备id
	wifiname VARCHAR2(128),					-- wifi名称
	wifissid VARCHAR2(128),				
	ip VARCHAR2(16),						-- 网络ip
	createtime date	
);

drop SEQUENCE seq_km_wifi;
create SEQUENCE seq_km_wifi
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;


drop table  km_app_control_rule;
CREATE table km_app_control_rule (
	id NUMBER(18,0) primary key,		-- 应用id
	parentid NUMBER(18,0),				-- 家长id
	childid NUMBER(18,0),				-- 儿童id
	equipmentid NUMBER(18,0),
	controlname varchar2(128),			-- 名称
	appid NUMBER(18,0),					-- 应用id 指定应用受此规则控制		
	starttime NUMBER(9,0),				-- 开始时间
	endtime NUMBER(9,0),				-- 结束时间
	duration NUMBER(9,0),				-- 时长
	exceptapp varchar2(512),			-- 例外不收控制app
	repeattype Number(9,0),				-- 重复类型 （0：不重复 ）
	createtime date,					-- 创建时间
	status char(1)						-- 状态
);

drop SEQUENCE seq_km_app_control_rule;
create SEQUENCE seq_km_app_control_rule
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;


drop table km_money_history;
CREATE table km_money_history (
	id NUMBER(18,0) primary key,			-- 应用id
	userid NUMBER(18,0),					-- 用户id
	money Number(9,2),						-- wifi名称
	remark VARCHAR2(128),				
	ip VARCHAR2(16),						-- 
	createtime date	
);

drop SEQUENCE seq_km_money_history;
create SEQUENCE seq_km_money_history
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;

drop SEQUENCE seq_km_snapshot;
create SEQUENCE seq_km_snapshot
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;

drop table km_snapshot;
CREATE table km_snapshot (
	id NUMBER(18,0) primary key,			-- 截图id
	equipmentid NUMBER(18,0),
	url VARCHAR2(512),						-- 截图保存路径
	longitude number(8,4),					-- 经纬度
	latitude number(8,4),
	addr VARCHAR2(512),						-- 截图保存路径
	createtime date,						-- 创建时间
	status char(1)							-- 状态
);


alter table km_equipment add token varchar2(64);
alter table km_equipment add PushMagic varchar2(64);
alter table km_equipment add udid varchar2(64);
alter table km_equipment add unlocktoken varchar2(4000);
alter table km_equipment add topic varchar2(4000);
alter table km_parent add WXOPENID varchar2(64);

drop table km_rss_channel;
create table km_rss_channel (
	id NUMBER(18,0) primary key,			-- 频道id
	name VARCHAR2(128),						-- 频道名
	title VARCHAR2(128),					-- 标题
	description VARCHAR2(1024),				-- 摘要
	author VARCHAR2(64),					-- 作者
	link VARCHAR2(1024),					-- 本地连接则不填，有内容则表示是外部内容，比如百度RSS的频道连接
	linkmode char(1),						-- 0,本地内容；1，外部内容
	createtime date,						-- 创建时间
	status char(1)							-- 状态：0，有效；1，停用
);

drop SEQUENCE seq_km_rss_channel;
create SEQUENCE seq_km_rss_channel
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;

drop table km_rss;
CREATE table km_rss (
	id NUMBER(18,0) primary key,			-- rssid
	channelid NUMBER(18,0),					-- 频道id
	title VARCHAR2(128),					-- 标题
	description VARCHAR2(4000),				-- 摘要
	pubDate date,							-- rss的发布时间
	link VARCHAR2(1024),					-- 原文链接
	category VARCHAR2(1024),				-- 分类或标签
	author VARCHAR2(64),					-- 作者
	createtime date,						-- 创建时间
	status char(1)							-- 状态
);

create table KM_PARENT_SMS
(
  MSG          VARCHAR2(200),
  MSGTYPE      NUMBER(6),
  MOBILES      VARCHAR2(100),
  CREATETIME   DATE,
  SENDTIME     DATE,
  STATUS       CHAR(1),
  FUNCTIONNAME VARCHAR2(100),
  OPENID       VARCHAR2(100),
  VERIFY_CODE  VARCHAR2(20),
  ID           NUMBER(18) not null
);
drop SEQUENCE seq_KM_PARENT_SMS;
create SEQUENCE seq_KM_PARENT_SMS
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;



create table KM_WX_INFO
(
  ID         NUMBER(18) not null,
  APPID      VARCHAR2(200) not null,
  TYPE       NUMBER(6) not null,
  CONTENT    VARCHAR2(400) not null,
  UPDATETIME DATE not null,
  CREATETIME DATE not null
);

drop SEQUENCE seq_KM_WX_INFO;
create SEQUENCE seq_KM_WX_INFO
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;


create table KM_WX_KEY_REPLY
(
  ID         NUMBER(18) not null,
  KEYWORD    VARCHAR2(50) not null,
  CONTENT    VARCHAR2(1000) not null,
  CREATETIME DATE not null,
  UPDATETIME DATE not null,
  SATUS      CHAR(1) default 1
);
drop SEQUENCE seq_KM_WX_KEY_REPLY;
create SEQUENCE seq_KM_WX_KEY_REPLY
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;

drop SEQUENCE seq_km_rss;
create SEQUENCE seq_km_rss
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;

create SEQUENCE seq_km_parent_equipment
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;

create table km_parent_equipment(
     id NUMBER(18,0) primary key,     --字段id
     parentid NUMBER(18,0),           --主家长id   
     cparentid NUMBER(18,0),          --次家长id
     equipmentId  NUMBER(18,0),        -- 设备id  
     childId  NUMBER(18,0),        -- 设备id  
     createtime date,
     type char(1),                     
     status char(1)
)
  

update km_snapshot set status='1'
-- 08-11 zz
alter table km_parent_equipment rename to km_guardian;
alter table km_guardian drop column equipmentid;

drop sequence seq_km_parent_equipment; 

create SEQUENCE seq_km_guardian
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;


create SEQUENCE seq_km_product
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;

CREATE table km_product (
	id NUMBER(18,0) primary key,			-- 产品Id
	name VARCHAR2(128),						-- 产品名称
	cid NUMBER(18,0),						-- 分类id
	description VARCHAR2(4000),				-- 产品描述
	price NUMBER(18,2),						-- 产品价格
	remark VARCHAR2(4000),					-- 小编点评
	link VARCHAR2(1024),					-- 产品链接
	image VARCHAR2(1024),					-- 产品主图
	source VARCHAR2(1024),					-- 产品来源
	tags VARCHAR2(1024),					-- 分类或标签
	createtime date,						-- 创建时间
	status char(1)							-- 状态
);

create SEQUENCE seq_km_product_class
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;

CREATE table km_product_class (
    id NUMBER(18,0) primary key,            -- 产品分类Id
	name VARCHAR2(128),						-- 产品分类名称
	description VARCHAR2(4000),				-- 产品描述
    image VARCHAR2(1024),					-- 产品主图
	remark VARCHAR2(4000),					-- 小编点评
	link VARCHAR2(1024),					-- 产品链接
	tags VARCHAR2(1024),					-- 标签
	createtime date,						-- 创建时间
	status char(1)							-- 状态
);


alter table km_product_class
add (kmbysort NUMBER(18,0));

alter table km_product
add (prosize VARCHAR2(128));

alter table km_product
add (taocommand VARCHAR2(1024));


--09-05 zz  用户积分表
CREATE table km_credit  (
    id NUMBER(18,0) primary key,            -- 产品分类Id
	pid NUMBER(18,0),						-- 家长id
	credit NUMBER(18,0),				    -- 总积分
    updateTime date,					    -- 更新时间
	status char(1)							-- 状态
);

create SEQUENCE seq_km_credit
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;


---积分明细表  km_credit_detail
CREATE table km_credit_detail  (
    id NUMBER(18,0) primary key,            -- 产品分类Id
	pid NUMBER(18,0),						-- 家长id
	credit NUMBER(18,0),				    -- 总积分
	creditchange  NUMBER(18,0),             -- 积分变化值
	typeid   NUMBER(18,0),                  -- 类型id
    createTime date,					    -- 创建时间
	status char(1)							-- 状态
);
create SEQUENCE seq_km_credit_detail
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;


--积分类型表  km_credit_type
CREATE table km_credit_type (
    id NUMBER(18,0) primary key,            -- 产品分类Id
	description VARCHAR2(1024),				-- 类型描述
	credit NUMBER(18,0),				    -- 类型积分
	name VARCHAR2(1024),                    -- 类型名称
	createTime date,					    -- 创建时间
	status char(1)							-- 状态
);
create SEQUENCE seq_km_credit_type
INCREMENT BY 1
START WITH 2000
NOMAXvalue
NOCYCLE
CACHE 10;


--积分明细表索引：根据pid和createTime来建立

create index index_credit_detail on km_credit_detail(pid,createTime) 

--09-05 zz end

