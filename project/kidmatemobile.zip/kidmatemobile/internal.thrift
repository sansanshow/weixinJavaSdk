namespace java com.kidmate.kmservice
include "kidmate.thrift"
service InternalService {
	bool ping();
	bool addAppUsage(1:i64 equipmentid, 2:i64 appid ,3:i64 wifiid, 4:i64 positionid, 5:i64 time, 6:string ip);
	# 发送信息
	bool sendMessge(1:i32 selectClient, 2:string fromid, 3:string toid, 4: string content, 5:string summary, 6:string extend) throws (1:kidmate.TKmException e),
}
