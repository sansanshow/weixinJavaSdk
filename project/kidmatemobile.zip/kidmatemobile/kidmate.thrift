namespace java com.kidmate.kmservice

enum TKmExceptionType {
  DEFAULT = 0,					# 默认异常
  UNLOGIN = 1,					# 未登录
  UNAUTHORIZED = 2,				# 未授权
}

exception TKmException {
  1: TKmExceptionType whatOp,
  2: string why,
}

struct TKmUser {
	1:i64 userid,
	2:string sign,
	3:i64 timestamp,
	4:string ver,		# 版本号	
}

struct TKmEquipment {
	1:i64 id,			
	2:string aliasName,
	3:i64 childId,
	4:string mac,
	5:string lastip,
	6:i64 lasttime,
	7:string sign,
}

struct TKmChild {
	1:i64 id,
	2:string name,
	3:bool gender,
	4:i64 birth,
	5:string shareType,
}

struct TKmAppInfo {
	1:i64 id,
	2:string name,
	3:string packagename,
	4:string url,
	5:string ver,		# 版本号
}

struct TKmAppInfoUpload {
	1:i64 id,
	2:string name,
	3:string packagename,
	4:binary icon,
	5:string ver,		# 版本号
}

struct TKmControlRuleInfo {
	1:i64 id,			#id
	2:i64 parentId,
	3:i64 childId,
	4:i64 equipmentId,
	5:i64 appId,		# 对哪个应用起作用，0表示所有应用, 1表示立即锁屏，大于2000表示应用时长限制
	6:i64 startTime,	# 规则开始时间
	7:i64 endTime,		# 规则结束时间
	8:i64 dur,			# 能够使用的时长
	9:i32 repeatType,	# 重复
	10:string exceptapp, # 不受规则控制的app
	11:bool on,			# 规则是否打开
	12:i64 creattime,
	13:string controlname, #规则名字
}

struct TKmAppUsage {
	1:i64 id,
	2:i64 appid, 
	3:i64 time, 
	4:i64 duration, 
	5:i64 wifiid, 
	6:i64 positionid
}

struct TKmPosition {
	1:i64 id,
	2:double longitude, 
	3:double latitude,
	4:i64 time;
}

struct TKmWifi {
	1:i64 id,
	2:string wifiname,
	3:string wifissid,
	4:i64 time;
}

struct TKmTimeStatistics {
	1: i64 time,	
	2: i64 avgDuration,
	3: i64 selfDuration,
}

struct TKmAppUsageStatistics {
	1:i64 appid, 
	2:i64 duration,
	3:i32 count,
	4:i64 time, 
}

struct TKmSnapshot {
	1:i64 id, 
	2:string url,
	3:double longitude, 
	4:double latitude,
	5:string addr,
	6:i64 time, 
	7:binary imagedata,
	8:i32 type,
	
}

#08-17 zz 产品和类别字段   # 产品类别字段
struct TKmProductClass {     
	1:i64 id, 
	2:string name,
	3:string imgurl,
	4:string link,
	5:string tags,
	6:i64 time,
	7:list<TKmProduct> tkmProducts,
}

struct TKmProduct{           # 产品字段
	1:i64 id,
	2:i64 cid,                # 产品类别id
	3:string name,
	4:string imgurl,
	5:string link,
	6:double price,
	7:string tags, 
    8:string prodescription,
	9:i64 time,
	10:string prosize,
	11:string taocommand,
	12:string proreamark,
}


#09-07  积分表字段

struct TKmCredit{
    1:i64 id,
	2:i64 cid,                # 用户id
	3:i64 usercredit,         # 用户积分
	4:i64 credittype,         #积分类型 
	5:i64 creditopera,        #是否操作过  
	
}






