namespace java com.kidmate.kmservice
include "kidmate.thrift"

service ParentService {
	# 家长端登录
	kidmate.TKmUser login(1:string authToken, 2:string checksum, 3:i64 timestamp, 4:i32 source, 5:string version) throws (1:kidmate.TKmException e),
	
	kidmate.TKmUser loginV2(1:string authToken, 2:string checksum, 3:i64 timestamp, 4:i32 source, 5:string version, 6:string invitecode) throws (1:kidmate.TKmException e),
	
	# 家长端用户名密码登陆
	string loginWithPw(1:string mobile, 2:string password, 3:i64 timestamp, 4:string checksum) throws (1:kidmate.TKmException e),
	
	#获取系统配置
	map<string, string> getSysConfig();
	
	# 保存孩子信息
	kidmate.TKmChild saveChild(1:kidmate.TKmUser user, 2: kidmate.TKmChild kmChild) throws (1:kidmate.TKmException e),
	# 获取孩子列表
	list<kidmate.TKmChild> getChildList(1: kidmate.TKmUser user) throws (1:kidmate.TKmException e),
	# 删除孩子
	bool delChild(1: kidmate.TKmUser user, 2:i64 childid) throws (1:kidmate.TKmException e),
	# 绑定孩子的设备
	bool bindEquipment(1: kidmate.TKmUser user, 2:i64 childid, 3: i64 equipmentID) throws (1:kidmate.TKmException e),
	# 解绑孩子的设备
	bool unBindEquipment(1: kidmate.TKmUser user, 2:i64 childid, 3: i64 equipmentID) throws (1:kidmate.TKmException e),
	# 删除设备
	bool delEquipment(1: kidmate.TKmUser user, 2: i64 equipmentID) throws (1:kidmate.TKmException e),
	# 获取所有设备
	list<kidmate.TKmEquipment> getAllEquipment(1: kidmate.TKmUser user) throws (1:kidmate.TKmException e),

	# 根据appid获取app信息
	list<kidmate.TKmAppInfo> getAppInfoByIDs(1:kidmate.TKmUser user, 2: list<i64> appids) throws (1:kidmate.TKmException e),
	
	#获取孩子的所有应用
	list<i64> getChildAllAPP(1:kidmate.TKmUser user, 2:i64 childid );
	#获取设备的所有应用
	list<i64> getEquipmentAllAPP(1:kidmate.TKmUser user, 2:i64 equipmentId ) throws (1:kidmate.TKmException e),
	#获取设备受控制的应用
	list<i64> getEquipmentUnderControlAPP(1:kidmate.TKmUser user, 2:i64 equipmentId ) throws (1:kidmate.TKmException e),
	#获取设备不受控制的应用
	list<i64> getEquipmentOutOfControlAPP(1:kidmate.TKmUser user, 2:i64 equipmentId ) throws (1:kidmate.TKmException e),
	
	# 获取所有规则
	list<kidmate.TKmControlRuleInfo> getAllControlRuleInfo(1: kidmate.TKmUser user, 2:i64 childid, 3:i64 equipmentID) throws (1:kidmate.TKmException e),
	# 保存规则
	kidmate.TKmControlRuleInfo saveControlRuleInfo(1: kidmate.TKmUser user, 2:kidmate.TKmControlRuleInfo controlrule ) throws (1:kidmate.TKmException e),
	bool setControlRuleInfoOn(1: kidmate.TKmUser user, 2: i64 ruleid);
	bool setControlRuleInfoOff(1: kidmate.TKmUser user, 2: i64 ruleid);
	bool delControlRuleInfo(1: kidmate.TKmUser user, 2: i64 ruleid);
	
	# 根据应用id下线规则
	bool setControlRuleInfoOffByAppid(1: kidmate.TKmUser user, 2: i64 appid, 3:i64 childid, 4:i64 equipmentID);
	
	# 获取最近X日平均使用情况
	list<kidmate.TKmTimeStatistics> getChildTimeStatistics(1: kidmate.TKmUser user, 2:i64 childid, 3: i32 dayCount)throws (1:kidmate.TKmException e),
	# 获取最近几日使用top
	list<kidmate.TKmAppUsageStatistics> getChildAppUsageStatistics(1: kidmate.TKmUser user, 2:i64 childid, 3:i32 dayCount, 4:i32 topX)throws (1:kidmate.TKmException e),
	# 获取设备最近使用的程序
	kidmate.TKmAppUsage getTheLatestAppUsage(1: kidmate.TKmUser user, 2:i64 equipmentId)throws (1:kidmate.TKmException e),
	
	# 获取使用情况
	list<kidmate.TKmAppUsage> getEquipmentAppUsageStatistics(1: kidmate.TKmUser user, 2:i64 equipmentid, 3:i32 page, 4:i32 size, 5:i32 ordertype);
	
	# 获取位置
	list<kidmate.TKmPosition> getPositionList(1: kidmate.TKmUser user, 2:i64 equipmentid, 3:i32 page, 4:i32 size);
	 
	i32 appStoreRecharge(1:kidmate.TKmUser user, 2:string receipt)throws (1:kidmate.TKmException e),
	
	i64 getVipTime(1: kidmate.TKmUser user);
	# 判断儿童端设备是否被锁定
	bool isEquipmentLocked(1: kidmate.TKmUser user, 2:i64 childid 3:i64 equipmentid) throws (1:kidmate.TKmException e),
	# 获取截屏列表
	list<kidmate.TKmSnapshot> getSnapshots(1: kidmate.TKmUser user, 2:i64 equipmentid, 3:i32 page, 4:i32 size),
	# 根据孩子ID，获取设备列表
	list<kidmate.TKmEquipment> getEquipmentsByChildId(1: kidmate.TKmUser user, 2:i64 childid) throws (1:kidmate.TKmException e),
	# 立即截屏
	void snapshot(1: kidmate.TKmUser user, 2:i64 equipmentid) throws (1:kidmate.TKmException e),
	#通过openid获取用户
	kidmate.TKmUser  getTkmUserByopenId(1:kidmate.TKmUser user,2:string accessToken, 3:string opendId, 4:string unionid, 5:i32 source,
			6:string ip) throws (1:kidmate.TKmException e),
	# 家长端登录
	kidmate.TKmUser loginWx(1:string accessToken,2:string opendId,3:string unionid,4:string checksum,5:i64 timestamp, 6:i32 source, 7:string version) throws (1:kidmate.TKmException e),
   
    # 分享孩子
	bool shareChild(1: kidmate.TKmUser user, 2:i64 timestamp, 3:string code) throws (1:kidmate.TKmException e),
	
	#08-17  zz
	# 获取产品类别
	list<kidmate.TKmProductClass> getProduct_class(1: kidmate.TKmUser user) throws (1:kidmate.TKmException e),
	# 获取类别下面的产品
	list<kidmate.TKmProduct> getProduct(1: kidmate.TKmUser user, 2:i64 productclassid,3:i32 page, 4:i32 size) throws (1:kidmate.TKmException e),
	# 获取多个类别下面的产品
	list<kidmate.TKmProduct> getListProduct(1: kidmate.TKmUser user, 2: list<i64> productclassid,3:i32 page, 4:i32 size) throws (1:kidmate.TKmException e),
	# 获取用户积分  creditType ==1：表示签到
	list<kidmate.TKmCredit> GetCreditScore(1: kidmate.TKmUser user,2: list<i64> creditType) throws (1:kidmate.TKmException e),
	# 操作积分
	list<kidmate.TKmCredit> saveCreditScore(1: kidmate.TKmUser user ,2:i64 creditType,3:i64 userCredit) throws (1:kidmate.TKmException e),
	
}